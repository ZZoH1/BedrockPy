export declare class Iterator {
    #private;
    context: any;
    cache: any[];
    finished: boolean;
    db: any;
    constructor(db: any, options: any);
    /**
     * Seek to a position
     * @param target Key to seek to. Empty string for start or end if reversed.
     */
    seek(target: any): void;
    private _next;
    next(): Promise<any[]>;
    end(): Promise<unknown>;
    [Symbol.asyncIterator](): AsyncGenerator<any[], void, unknown>;
    static readonly rangeOptions: string[];
    static isRangeOption(k: any): boolean;
    static cleanRangeOptions(options: any): {};
    static _setupIteratorOptions(options?: any): void;
}
