/// <reference types="node" />
export declare class ChainedBatch {
    context: any;
    constructor(db: any);
    put(key: Buffer, value: Buffer): void;
    delete(key: Buffer): void;
    clear(): void;
    write(options: any): Promise<unknown>;
}
