import NBT from "prismarine-nbt";
import BiomeData from "./__biome_data__.ts";
import type { LevelDB } from "@8crafter/leveldb-zlib";
import type { NBTSchemas } from "./nbtSchemas.ts";
import type { LooseAutocomplete } from "./types.js";
/**
 * A tuple of length 16.
 *
 * @template T The type of the elements in the tuple.
 */
type TupleOfLength16<T> = [T, T, T, T, T, T, T, T, T, T, T, T, T, T, T, T];
/**
 * Reads the value of the Data3D content type.
 *
 * @param rawvalue The raw value to read.
 * @returns The height map and biome map.
 */
export declare function readData3dValue(rawvalue: Uint8Array | null): {
    /**
     * A height map in the form [x][z].
     */
    heightMap: TupleOfLength16<TupleOfLength16<number>>;
    /**
     * A biome map as an array of 24 or more BiomePalette objects.
     */
    biomes: BiomePalette[];
} | null;
/**
 * Writes the value of the Data3D content type.
 *
 * @param heightMap A height map in the form [x][z].
 * @param biomes A biome map as an array of 24 or more BiomePalette objects.
 * @returns The raw value to write.
 */
export declare function writeData3DValue(heightMap: TupleOfLength16<TupleOfLength16<number>>, biomes: BiomePalette[]): Buffer<ArrayBuffer>;
/**
 * Parses the storage key of an {@link entryContentTypeToFormatMap.ActorPrefix | ActorPrefix}.
 *
 * The storage key is stored as a binary-encoded string in the {@link __JSDocTypeAliases.EntityStorageKeyComponentValue.StorageKey | internalComponents.EntityStorageKeyComponent.StorageKey} property.
 *
 * The value returned from this function is the ID that is used in the ActorPrefix's LevelDB key and in the {@link __JSDocTypeAliases.DigestValue.entityIds | entity IDs list} of {@link entryContentTypeToFormatMap.Digest | Digest} LevelDB entries.
 *
 * @param data The storage key.
 * @returns The ID.
 */
export declare function parseActorPrefixStorageKey(data: Buffer | string): bigint;
/**
 * Parses the storage key of an {@link entryContentTypeToFormatMap.ActorPrefix | ActorPrefix} into high and low parts.
 *
 * The storage key is stored as a binary-encoded string in the {@link __JSDocTypeAliases.EntityStorageKeyComponentValue.StorageKey | internalComponents.EntityStorageKeyComponent.StorageKey} property.
 *
 * The value returned from this function is the ID that is used in the ActorPrefix's LevelDB key and in the {@link __JSDocTypeAliases.DigestValue.entityIds | entity IDs list} of {@link entryContentTypeToFormatMap.Digest | Digest} LevelDB entries.
 *
 * @param data The storage key.
 * @returns The ID.
 */
export declare function parseActorPrefixStorageKeyToParts(data: Buffer | string): [high: number, low: number];
/**
 * Serializes the storage key ID of an {@link entryContentTypeToFormatMap.ActorPrefix | ActorPrefix} into a raw binary-encoded storage key string.
 *
 * The storage key is stored as a binary-encoded string in the {@link __JSDocTypeAliases.EntityStorageKeyComponentValue.StorageKey | internalComponents.EntityStorageKeyComponent.StorageKey} property.
 *
 * The value passed to this function is the ID that is used in the ActorPrefix's LevelDB key and in the {@link __JSDocTypeAliases.DigestValue.entityIds | entity IDs list} of {@link entryContentTypeToFormatMap.Digest | Digest} LevelDB entries.
 *
 * @param data The ID.
 * @returns The storage key.
 */
export declare function serializeActorPrefixStorageKey(data: bigint | [high: number, low: number]): Buffer<ArrayBuffer>;
/**
 * The list of Minecraft dimensions.
 */
export declare const dimensions: readonly ["overworld", "nether", "the_end"];
/**
 * The list of Minecraft game modes, with their indices corresponding to their numeric gamemode IDs.
 */
export declare const gameModes: readonly ["survival", "creative", "adventure", undefined, undefined, "default", "spectator"];
/**
 * The content types for LevelDB entries.
 */
export declare const DBEntryContentTypes: readonly ["Data3D", "Version", "Data2D", "Data2DLegacy", "SubChunkPrefix", "LegacyTerrain", "BlockEntity", "Entity", "PendingTicks", "LegacyBlockExtraData", "BiomeState", "FinalizedState", "ConversionData", "BorderBlocks", "HardcodedSpawners", "RandomTicks", "Checksums", "GenerationSeed", "GeneratedPreCavesAndCliffsBlending", "BlendingBiomeHeight", "MetaDataHash", "BlendingData", "ActorDigestVersion", "LegacyVersion", "AABBVolumes", "VillageDwellers", "VillageInfo", "VillagePOI", "VillagePlayers", "VillageRaid", "Player", "PlayerClient", "ActorPrefix", "ChunkLoadedRequest", "Digest", "Map", "Portals", "SchedulerWT", "StructureTemplate", "TickingArea", "FlatWorldLayers", "LegacyOverworld", "LegacyNether", "LegacyTheEnd", "MVillages", "Villages", "LevelSpawnWasFixed", "PositionTrackingDB", "PositionTrackingLastId", "Scoreboard", "Overworld", "Nether", "TheEnd", "CustomDimension", "AutonomousEntities", "BiomeData", "BiomeIdsTable", "DimensionNameIdTable", "MobEvents", "DynamicProperties", "LevelChunkMetaDataDictionary", "RealmsStoriesData", "LevelDat", "WorldClocks", "ForcedWorldCorruption", "Unknown"];
/**
 * The content types for LevelDB entries that are associated with a specific chunk and use a single byte at the end of the LevelDB key to denote their content type.
 */
export declare const DBChunkKeyEntryContentTypes: ["Data3D", "Version", "Data2D", "Data2DLegacy", "SubChunkPrefix", "LegacyTerrain", "BlockEntity", "Entity", "PendingTicks", "LegacyBlockExtraData", "BiomeState", "FinalizedState", "ConversionData", "BorderBlocks", "HardcodedSpawners", "RandomTicks", "Checksums", "GenerationSeed", "GeneratedPreCavesAndCliffsBlending", "BlendingBiomeHeight", "MetaDataHash", "BlendingData", "ActorDigestVersion", "LegacyVersion", "AABBVolumes"];
/**
 * The content types for LevelDB entries that are associated with a specific chunk, includes both the content types from {@link DBChunkKeyEntryContentTypes} and other keys that are tied to a specific chunk but use a different key format.
 */
export declare const DBChunkLinkedContentTypes: ["Data3D", "Version", "Data2D", "Data2DLegacy", "SubChunkPrefix", "LegacyTerrain", "BlockEntity", "Entity", "PendingTicks", "LegacyBlockExtraData", "BiomeState", "FinalizedState", "ConversionData", "BorderBlocks", "HardcodedSpawners", "RandomTicks", "Checksums", "GenerationSeed", "GeneratedPreCavesAndCliffsBlending", "BlendingBiomeHeight", "MetaDataHash", "BlendingData", "ActorDigestVersion", "LegacyVersion", "AABBVolumes", "Digest"];
/**
 * Maps content types to grouping labels.
 *
 * Most content types are not grouped, only a few are.
 */
export declare const DBEntryContentTypesGrouping: {
    readonly Data3D: "Data3D";
    readonly Version: "Version";
    readonly Data2D: "Data2D";
    readonly Data2DLegacy: "Data2DLegacy";
    readonly SubChunkPrefix: "SubChunkPrefix";
    readonly LegacyTerrain: "LegacyTerrain";
    readonly BlockEntity: "BlockEntity";
    readonly Entity: "Entity";
    readonly PendingTicks: "PendingTicks";
    readonly LegacyBlockExtraData: "LegacyBlockExtraData";
    readonly BiomeState: "BiomeState";
    readonly FinalizedState: "FinalizedState";
    readonly ConversionData: "ConversionData";
    readonly BorderBlocks: "BorderBlocks";
    readonly HardcodedSpawners: "HardcodedSpawners";
    readonly RandomTicks: "RandomTicks";
    readonly Checksums: "Checksums";
    readonly GenerationSeed: "GenerationSeed";
    readonly GeneratedPreCavesAndCliffsBlending: "GeneratedPreCavesAndCliffsBlending";
    readonly BlendingBiomeHeight: "BlendingBiomeHeight";
    readonly MetaDataHash: "MetaDataHash";
    readonly BlendingData: "BlendingData";
    readonly ActorDigestVersion: "ActorDigestVersion";
    readonly LegacyVersion: "LegacyVersion";
    readonly AABBVolumes: "AABBVolumes";
    readonly VillageDwellers: "VillageDwellers";
    readonly VillageInfo: "VillageInfo";
    readonly VillagePOI: "VillagePOI";
    readonly VillagePlayers: "VillagePlayers";
    readonly VillageRaid: "VillageRaid";
    readonly Player: "Player";
    readonly PlayerClient: "PlayerClient";
    readonly ActorPrefix: "ActorPrefix";
    readonly ChunkLoadedRequest: "ChunkLoadedRequest";
    readonly Digest: "Digest";
    readonly Map: "Map";
    readonly Portals: "Portals";
    readonly SchedulerWT: "SchedulerWT";
    readonly StructureTemplate: "StructureTemplate";
    readonly TickingArea: "TickingArea";
    readonly FlatWorldLayers: "FlatWorldLayers";
    readonly LegacyOverworld: "LegacyDimension";
    readonly LegacyNether: "LegacyDimension";
    readonly LegacyTheEnd: "LegacyDimension";
    readonly MVillages: "MVillages";
    readonly Villages: "Villages";
    readonly LevelSpawnWasFixed: "LevelSpawnWasFixed";
    readonly PositionTrackingDB: "PositionTrackingDB";
    readonly PositionTrackingLastId: "PositionTrackingLastId";
    readonly Scoreboard: "Scoreboard";
    readonly Overworld: "Dimension";
    readonly Nether: "Dimension";
    readonly TheEnd: "Dimension";
    readonly CustomDimension: "Dimension";
    readonly AutonomousEntities: "AutonomousEntities";
    readonly BiomeData: "BiomeData";
    readonly BiomeIdsTable: "IdsTable";
    readonly DimensionNameIdTable: "IdsTable";
    readonly MobEvents: "MobEvents";
    readonly DynamicProperties: "DynamicProperties";
    readonly LevelChunkMetaDataDictionary: "LevelChunkMetaDataDictionary";
    readonly RealmsStoriesData: "RealmsStoriesData";
    readonly LevelDat: "LevelDat";
    readonly WorldClocks: "WorldClocks";
    readonly ForcedWorldCorruption: "ForcedWorldCorruption";
    readonly Unknown: "Unknown";
};
/**
 * Maps the chunk versions from the {@link entryContentTypeToFormatMap.LegacyVersion} content type to details of what version they correspond to.
 */
export declare const chunkLegacyVersionDetailsMap: {
    readonly 0: "v0.9.0";
    readonly 1: "v0.9.2";
    readonly 2: "v0.9.5";
    readonly 3: "v0.17.0.1";
    readonly 4: "v1.1.0";
    readonly 5: "Converted from console to v1.1.0";
    readonly 6: "v1.2.0.2";
    readonly 7: "v1.2.0";
    readonly 8: "v1.2.13";
    readonly 9: "v1.8.0";
    readonly 10: "v1.9.0";
    readonly 11: "v1.11.0.1";
    readonly 12: "v1.11.0.3";
    readonly 13: "v1.11.0.4";
    readonly 14: "v1.11.1";
    readonly 15: "v1.12.0.4";
    readonly 16: "v1.14.0";
    readonly 17: "v1.15.0";
    readonly 18: "v1.16.0.51";
    readonly 19: "v1.16.0";
};
/**
 * Maps the chunk versions from the {@link entryContentTypeToFormatMap.Version} content type to details of what version they correspond to.
 */
export declare const chunkVersionDetailsMap: {
    readonly 20: "v1.16.100.52";
    readonly 21: "v1.16.100.57";
    readonly 22: "v1.16.210";
    readonly 23: "v1.16.220.50 (+Caves & Cliffs Experimental Toggle)";
    readonly 24: "v1.16.220.50 (+Caves & Cliffs Experimental Toggle) (internal/developer builds)";
    readonly 25: "v1.16.230.50 (+Caves & Cliffs Experimental Toggle)";
    readonly 26: "v1.16.230.50 (+Caves & Cliffs Experimental Toggle) (internal/developer builds)";
    readonly 27: "v1.17.30.23 (+Caves & Cliffs Experimental Toggle)";
    readonly 28: "v1.17.30.23 (+Caves & Cliffs Experimental Toggle) (internal/developer builds)";
    readonly 29: "v1.17.30.25 (+Caves & Cliffs Experimental Toggle)";
    readonly 30: "v1.17.30.25 (+Caves & Cliffs Experimental Toggle) (internal/developer builds)";
    readonly 31: "v1.17.40.20 (+Caves & Cliffs Experimental Toggle)";
    readonly 32: "v1.17.40.20 (+Caves & Cliffs Experimental Toggle) (internal/developer builds)";
    readonly 33: "v1.18.0.20";
    readonly 34: "v1.18.0.20 (internal/developer builds)";
    readonly 35: "v1.18.0.22";
    readonly 36: "v1.18.0.22 (internal/developer builds)";
    readonly 37: "v1.18.0.24";
    readonly 38: "v1.18.0.24 (internal/developer builds)";
    readonly 39: "v1.18.0.25";
    readonly 40: "v1.18.30 after upgrading entities to independent storage";
    readonly 41: "v1.21.40";
    readonly 42: "v1.21.120";
};
/**
 * This is like {@link NBT.protoLE | protoLE} from the `prismarine-nbt` module, except strings are parsed with a binary encoding instead of UTF-8.
 */
export declare const protoLEBinaryStringEncoding: CompiledProtoDef;
/**
 * The content type to format mapping for LevelDB entries.
 */
export declare const entryContentTypeToFormatMap: {
    /**
     * The Data3D content type contains heightmap and biome data for 16x16x16 chunks of the world.
     *
     * @see {@link NBTSchemas.nbtSchemas.Data3D}
     */
    readonly Data3D: {
        /**
         * The format type of the data.
         */
        readonly type: "custom";
        /**
         * The format type that results from the {@link entryContentTypeToFormatMap.Data3D.parse | parse} method.
         */
        readonly resultType: "JSONNBT";
        /**
         * The function to parse the data.
         *
         * The {@link data} parameter should be the buffer read directly from the file or LevelDB entry.
         *
         * @param data The data to parse, as a buffer.
         * @returns The parsed data.
         *
         * @throws {Error} If the value does not contain at least one subchunk of biome data.
         */
        readonly parse: (data: Buffer) => NBTSchemas.NBTSchemaTypes.Data3D;
        /**
         * The function to serialize the data.
         *
         * This result of this can be written directly to the file or LevelDB entry.
         *
         * @param data The data to serialize.
         * @returns The serialized data, as a buffer.
         */
        readonly serialize: (data: NBTSchemas.NBTSchemaTypes.Data3D) => Buffer<ArrayBuffer>;
    };
    /**
     * The version of a chunk.
     *
     * Deleting this key causes the game to completely regenerate the corresponding chunk.
     *
     * Possible values:
     * - `20`: v1.16.100.52
     * - `21`: v1.16.100.57
     * - `22`: v1.16.210
     * - `23`: v1.16.220.50 (+Caves & Cliffs Experimental Toggle)
     * - `24`: v1.16.220.50 (+Caves & Cliffs Experimental Toggle) (internal/developer builds)
     * - `25`: v1.16.230.50 (+Caves & Cliffs Experimental Toggle)
     * - `26`: v1.16.230.50 (+Caves & Cliffs Experimental Toggle) (internal/developer builds)
     * - `27`: v1.17.30.23 (+Caves & Cliffs Experimental Toggle)
     * - `28`: v1.17.30.23 (+Caves & Cliffs Experimental Toggle) (internal/developer builds)
     * - `29`: v1.17.30.25 (+Caves & Cliffs Experimental Toggle)
     * - `30`: v1.17.30.25 (+Caves & Cliffs Experimental Toggle) (internal/developer builds)
     * - `31`: v1.17.40.20 (+Caves & Cliffs Experimental Toggle)
     * - `32`: v1.17.40.20 (+Caves & Cliffs Experimental Toggle) (internal/developer builds)
     * - `33`: v1.18.0.20
     * - `34`: v1.18.0.20 (internal/developer builds)
     * - `35`: v1.18.0.22
     * - `36`: v1.18.0.22 (internal/developer builds)
     * - `37`: v1.18.0.24
     * - `38`: v1.18.0.24 (internal/developer builds)
     * - `39`: v1.18.0.25
     * - `40`: v1.18.30 after upgrading entities to independent storage
     * - `41`: v1.21.40
     * - `42`: v1.21.120
     *
     * @see {@link chunkVersionDetailsMap}
     *
     * @since v1.16.100
     */
    readonly Version: {
        /**
         * The format type of the data.
         */
        readonly type: "int";
        /**
         * How many bytes this integer is.
         */
        readonly bytes: 1;
        /**
         * The endianness of the data.
         */
        readonly format: "LE";
        /**
         * The signedness of the data.
         */
        readonly signed: false;
        /**
         * The default value to use when initializing a new entry.
         *
         * Bytes:
         * ```json
         * [41]
         * ```
         */
        readonly defaultValue: Buffer<ArrayBuffer>;
    };
    /**
     * The Data2D content type contains heightmap and biome data for 16x128x16 chunks of the world.
     *
     * Unlike {@link entryContentTypeToFormatMap.Data3D | Data3D}, this only stores biome data for xz coordinates, so in this format all y coordinates have the same biome.
     *
     * Only used in versions < 1.18.0, and for worlds using the Old world type or using an older base game version.
     */
    readonly Data2D: {
        /**
         * The format type of the data.
         */
        readonly type: "custom";
        /**
         * The format type that results from the {@link entryContentTypeToFormatMap.Data2D.parse | parse} method.
         */
        readonly resultType: "JSONNBT";
        /**
         * The function to parse the data.
         *
         * The {@link data} parameter should be the buffer read directly from the file or LevelDB entry.
         *
         * @param data The data to parse, as a buffer.
         * @returns The parsed data.
         */
        readonly parse: (data: Buffer) => NBTSchemas.NBTSchemaTypes.Data2D;
        /**
         * The function to serialize the data.
         *
         * This result of this can be written directly to the file or LevelDB entry.
         *
         * @param data The data to serialize.
         * @returns The serialized data, as a buffer.
         */
        readonly serialize: (data: NBTSchemas.NBTSchemaTypes.Data2D) => Buffer<ArrayBuffer>;
    };
    /**
     * The Data2D content type contains heightmap and biome data for 16x128x16 chunks of the world.
     *
     * Unlike {@link entryContentTypeToFormatMap.Data3D | Data3D}, this only stores biome data for xz coordinates, so in this format all y coordinates have the same biome.
     *
     * Unlike both {@link entryContentTypeToFormatMap.Data3D | Data3D} and {@link entryContentTypeToFormatMap.Data2D | Data2D}, this also stores biome color data.
     *
     * @deprecated Only used in versions < 1.0.0.
     */
    readonly Data2DLegacy: {
        /**
         * The format type of the data.
         */
        readonly type: "custom";
        /**
         * The format type that results from the {@link entryContentTypeToFormatMap.Data2DLegacy.parse | parse} method.
         */
        readonly resultType: "JSONNBT";
        /**
         * The function to parse the data.
         *
         * The {@link data} parameter should be the buffer read directly from the file or LevelDB entry.
         *
         * @param data The data to parse, as a buffer.
         * @returns The parsed data.
         */
        readonly parse: (data: Buffer) => NBTSchemas.NBTSchemaTypes.Data2DLegacy;
        /**
         * The function to serialize the data.
         *
         * This result of this can be written directly to the file or LevelDB entry.
         *
         * @param data The data to serialize.
         * @returns The serialized data, as a buffer.
         */
        readonly serialize: (data: NBTSchemas.NBTSchemaTypes.Data2DLegacy) => Buffer<ArrayBuffer>;
    };
    /**
     * The SubChunkPrefix content type contains block data for 16x16x16 subchunks of the world.
     *
     * In older versions, it may also contain sky and block light data.
     *
     * @see {@link NBTSchemas.nbtSchemas.SubChunkPrefix}
     */
    readonly SubChunkPrefix: {
        /**
         * The format type of the data.
         */
        readonly type: "custom";
        /**
         * The format type that results from the {@link entryContentTypeToFormatMap.SubChunkPrefix.parse | parse} method.
         */
        readonly resultType: "JSONNBT";
        /**
         * The function to parse the data.
         *
         * The {@link data} parameter should be the buffer read directly from the file or LevelDB entry.
         *
         * @param data The data to parse, as a buffer.
         * @returns A promise that resolves with the parsed data.
         *
         * @throws {Error} If the SubChunkPrefix version is unknown.
         * @throws {Error} If the storage version is unknown.
         */
        readonly parse: (data: Buffer) => Promise<NBTSchemas.NBTSchemaTypes.SubChunkPrefix>;
        /**
         * The function to serialize the data.
         *
         * This result of this can be written directly to the file or LevelDB entry.
         *
         * @param data The data to serialize.
         * @returns The serialized data, as a buffer.
         */
        readonly serialize: (data: NBTSchemas.NBTSchemaTypes.SubChunkPrefix) => Buffer<ArrayBuffer>;
    };
    /**
     * The LegacyTerrain content type contains block, sky light, block light, dirty columns, and grass color data for 16x16x128 chunks of the world.
     *
     * @deprecated Only used in versions < 1.0.0.
     *
     * @see {@link NBTSchemas.nbtSchemas.LegacyTerrain}
     */
    readonly LegacyTerrain: {
        /**
         * The format type of the data.
         */
        readonly type: "custom";
        /**
         * The format type that results from the {@link entryContentTypeToFormatMap.LegacyTerrain.parse | parse} method.
         */
        readonly resultType: "JSONNBT";
        /**
         * The function to parse the data.
         *
         * The {@link data} parameter should be the buffer read directly from the file or LevelDB entry.
         *
         * @param data The data to parse, as a buffer.
         * @returns The parsed data.
         */
        readonly parse: (data: Buffer) => NBTSchemas.NBTSchemaTypes.LegacyTerrain;
        /**
         * The function to serialize the data.
         *
         * This result of this can be written directly to the file or LevelDB entry.
         *
         * @param data The data to serialize.
         * @returns The serialized data, as a buffer.
         */
        readonly serialize: (data: NBTSchemas.NBTSchemaTypes.LegacyTerrain) => Buffer<ArrayBuffer>;
    };
    /**
     * A list of block entities associated with a chunk.
     *
     * @see {@link NBTSchemas.nbtSchemas.BlockEntity}
     */
    readonly BlockEntity: {
        /**
         * The format type of the data.
         */
        readonly type: "custom";
        /**
         * The format type that results from the {@link entryContentTypeToFormatMap.BlockEntity.parse | parse} method.
         */
        readonly resultType: "JSONNBT";
        /**
         * The function to parse the data.
         *
         * The {@link data} parameter should be the buffer read directly from the file or LevelDB entry.
         *
         * @param data The data to parse, as a buffer.
         * @returns A promise that resolves with the parsed data.
         *
         * @throws {any} If an error occurs while parsing the data.
         */
        readonly parse: (data: Buffer) => Promise<{
            type: "compound";
            value: {
                blockEntities: {
                    type: "list";
                    value: {
                        type: "compound";
                        value: NBTSchemas.NBTSchemaTypes.BlockEntity["value"][];
                    };
                };
            };
        }>;
        /**
         * The function to serialize the data.
         *
         * This result of this can be written directly to the file or LevelDB entry.
         *
         * @param data The data to serialize.
         * @returns The serialized data, as a buffer.
         */
        readonly serialize: (data: {
            type: "compound";
            value: {
                blockEntities: {
                    type: "list";
                    value: {
                        type: "compound";
                        value: NBTSchemas.NBTSchemaTypes.BlockEntity["value"][];
                    };
                };
            };
        }) => Buffer<ArrayBuffer>;
    };
    /**
     * A list of entities associated with a chunk.
     *
     * @deprecated No longer used.
     *
     * @todo Figure out what version this was deprecated in (it exists in v1.16.40 but not in 1.21.51).
     */
    readonly Entity: {
        /**
         * The format type of the data.
         */
        readonly type: "custom";
        /**
         * The format type that results from the {@link entryContentTypeToFormatMap.Entity.parse | parse} method.
         */
        readonly resultType: "JSONNBT";
        /**
         * The function to parse the data.
         *
         * The {@link data} parameter should be the buffer read directly from the file or LevelDB entry.
         *
         * @param data The data to parse, as a buffer.
         * @returns A promise that resolves with the parsed data.
         *
         * @throws {any} If an error occurs while parsing the data.
         */
        readonly parse: (data: Buffer) => Promise<{
            type: "compound";
            value: {
                entities: {
                    type: "list";
                    value: {
                        type: "compound";
                        value: NBTSchemas.NBTSchemaTypes.ActorPrefix["value"][];
                    };
                };
            };
        }>;
        /**
         * The function to serialize the data.
         *
         * This result of this can be written directly to the file or LevelDB entry.
         *
         * @param data The data to serialize.
         * @returns The serialized data, as a buffer.
         */
        readonly serialize: (data: {
            type: "compound";
            value: {
                entities: {
                    type: "list";
                    value: {
                        type: "compound";
                        value: NBTSchemas.NBTSchemaTypes.ActorPrefix["value"][];
                    };
                };
            };
        }) => Buffer<ArrayBuffer>;
    };
    /**
     * @see {@link NBTSchemas.nbtSchemas.PendingTicks}
     *
     * @todo Add a description for this.
     */
    readonly PendingTicks: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
        /**
         * The default value to use when initializing a new entry.
         *
         * @todo Add a link to the object with the default value once it is made.
         */
        readonly defaultValue: Buffer<ArrayBuffer>;
    };
    /**
     * @deprecated Only used in versions < 1.2.3.
     *
     * @todo Figure out how to parse this.
     * @todo Add a description for this.
     *
     * @see https://github.com/yechentide/core-bedrock/blob/77d815439da14b3d0b7d0335b80deb1860aee42a/Analysis/chunk-0x34-legacy-block-extra-data.md
     * @see https://github.com/robofinch/Prismarine-Anchor/blob/main/crates/bedrock/leveldb-entries/src/entries/legacy_extra_block_data.rs
     * @see https://github.com/MiemieMethod/bedrock-docs/blob/8cd37dacbd064f5fb2a4953548739a258b31dd21/.knowledge/wiki%E6%91%98%E5%BD%95/%E4%B8%AD%E6%96%87Minecraft%20Wiki/%E5%9F%BA%E5%B2%A9%E7%89%88LevelDB%E6%A0%BC%E5%BC%8F.wikitext#L331
     */
    readonly LegacyBlockExtraData: {
        /**
         * The format type of the data.
         */
        readonly type: "unknown";
    };
    /**
     * @todo Figure out what this is used for.
     * @todo Add a description for this.
     *
     * @see {@link NBTSchemas.nbtSchemas.BiomeState}
     *
     * @description
     * https://github.com/robofinch/Prismarine-Anchor/blob/6ce90fa2a27c5d81e6cc1cc376e91c757a80e321/crates/bedrock/leveldb-entries/src/entries/biome_state.rs#L103C1-L109C41
     *
     * The above source says the following:
     *
     * > These state values seem to have something to do with snow accumulation level.
     * Maybe the maximum level that snow can accumulate to naturally.
     *
     * > TODO: determine this
     *
     * > Also, note that these could be backed by HashMaps,
     *
     * > but the order of real game data is inconsistent, and have very, very few values.
     *
     * > This makes things easier for testing to be able to round-trip,
     * and is probably more performant, too.
     */
    readonly BiomeState: {
        /**
         * The format type of the data.
         */
        readonly type: "custom";
        /**
         * The format type that results from the {@link entryContentTypeToFormatMap.BiomeState.parse | parse} method.
         */
        readonly resultType: "JSONNBT";
        /**
         * The function to parse the data.
         *
         * The {@link data} parameter should be the buffer read directly from the file or LevelDB entry.
         *
         * @param data The data to parse, as a buffer.
         * @returns The parsed data.
         *
         * @throws {RangeError} If the buffer is empty.
         * @throws {RangeError} If the number of BiomeState entries does is less than the number indicated in buffer.
         * @throws {RangeError} If one of the BiomeState entries does not contain enough bytes.
         * @throws {TypeError} If the BiomeState format is unknown.
         */
        readonly parse: (data: Buffer) => NBTSchemas.NBTSchemaTypes.BiomeState;
        /**
         * The function to serialize the data.
         *
         * This result of this can be written directly to the file or LevelDB entry.
         *
         * @param data The data to serialize.
         * @returns The serialized data, as a buffer.
         *
         * @throws {TypeError} If one of the BiomeState entries are undefined.
         * @throws {TypeError} If the BiomeState format is unknown.
         */
        readonly serialize: (data: NBTSchemas.NBTSchemaTypes.BiomeState) => Buffer<ArrayBuffer>;
    };
    /**
     * A value that indicates the finalization state of a chunk's data.
     *
     * Possible values:
     * - `0`: NeedsInstaticking - Chunk needs to be ticked
     * - `1`: NeedsPopulation - Chunk needs to be populated with mobs
     * - `2`: Done - Chunk generation is fully complete
     */
    readonly FinalizedState: {
        /**
         * The format type of the data.
         */
        readonly type: "int";
        /**
         * How many bytes this integer is.
         */
        readonly bytes: 4;
        /**
         * The endianness of the data.
         */
        readonly format: "LE";
        /**
         * The signedness of the data.
         */
        readonly signed: false;
        /**
         * The default value to use when initializing a new entry.
         *
         * Bytes:
         * ```json
         * [0,0,0,0]
         * ```
         */
        readonly defaultValue: Buffer<ArrayBuffer>;
    };
    /**
     * @deprecated No longer used.
     *
     * @todo Figure out how to parse this.
     * @todo Add a description for this.
     *
     * @see https://github.com/MiemieMethod/bedrock-docs/blob/8cd37dacbd064f5fb2a4953548739a258b31dd21/.knowledge/wiki%E6%91%98%E5%BD%95/%E4%B8%AD%E6%96%87Minecraft%20Wiki/%E5%9F%BA%E5%B2%A9%E7%89%88LevelDB%E6%A0%BC%E5%BC%8F.wikitext#L382
     * @see https://github.com/MiemieMethod/bedrock-docs/blob/8cd37dacbd064f5fb2a4953548739a258b31dd21/.knowledge/wiki%E6%91%98%E5%BD%95/%E4%B8%AD%E6%96%87Minecraft%20Wiki/%E5%9F%BA%E5%B2%A9%E7%89%88LevelDB%E6%A0%BC%E5%BC%8F.wikitext#L1445
     */
    readonly ConversionData: {
        /**
         * The format type of the data.
         */
        readonly type: "unknown";
    };
    /**
     * The border block data for the chunk.
     *
     * @todo Add a better description for this.
     */
    readonly BorderBlocks: {
        /**
         * The format type of the data.
         */
        readonly type: "custom";
        /**
         * The format type that results from the {@link entryContentTypeToFormatMap.BorderBlocks.parse | parse} method.
         */
        readonly resultType: "JSONNBT";
        /**
         * The function to parse the data.
         *
         * The {@link data} parameter should be the buffer read directly from the file or LevelDB entry.
         *
         * @param data The data to parse, as a buffer.
         * @returns The parsed data.
         *
         * @throws {RangeError} If the buffer is empty.
         * @throws {RangeError} If the length of the buffer is not equal to the expected length based on the first byte.
         */
        readonly parse: (data: Buffer) => NBTSchemas.NBTSchemaTypes.BorderBlocks;
        /**
         * The function to serialize the data.
         *
         * This result of this can be written directly to the file or LevelDB entry.
         *
         * @param data The data to serialize.
         * @returns The serialized data, as a buffer.
         *
         * @throws {TypeError} If one of the BorderBlocks entries are undefined.
         */
        readonly serialize: (data: NBTSchemas.NBTSchemaTypes.BorderBlocks) => Buffer<ArrayBuffer>;
    };
    /**
     * Bounding boxes for structure spawns, such as a Nether Fortress or Pillager Outpost.
     *
     * @deprecated Replaced with {@link entryContentTypeToFormatMap.AABBVolumes | AABBVolumes} in either 1.21.10 or one of the 1.21.10 previews.
     */
    readonly HardcodedSpawners: {
        /**
         * The format type of the data.
         */
        readonly type: "custom";
        /**
         * The format type that results from the {@link entryContentTypeToFormatMap.HardcodedSpawners.parse | parse} method.
         */
        readonly resultType: "JSONNBT";
        /**
         * The function to parse the data.
         *
         * The {@link data} parameter should be the buffer read directly from the file or LevelDB entry.
         *
         * @param data The data to parse, as a buffer.
         * @returns The parsed data.
         *
         * @throws {RangeError} If the buffer is less than 4 bytes.
         * @throws {RangeError} If the length of the buffer is not equal to the expected length based on the first four bytes.
         */
        readonly parse: (data: Buffer) => NBTSchemas.NBTSchemaTypes.HardcodedSpawners;
        /**
         * The function to serialize the data.
         *
         * This result of this can be written directly to the file or LevelDB entry.
         *
         * @param data The data to serialize.
         * @returns The serialized data, as a buffer.
         *
         * @throws {TypeError} If one of the HardcodedSpawners entries are undefined.
         */
        readonly serialize: (data: NBTSchemas.NBTSchemaTypes.HardcodedSpawners) => Buffer<ArrayBuffer>;
    };
    /**
     * @see {@link NBTSchemas.nbtSchemas.RandomTicks}
     *
     * @todo Add a description for this.
     */
    readonly RandomTicks: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
        /**
         * The default value to use when initializing a new entry.
         *
         * @todo Add a link to the object with the default value once it is made.
         */
        readonly defaultValue: Buffer<ArrayBuffer>;
    };
    /**
     * The low segment of the 4 byte halves of the seed value used to generate the chunk.
     *
     * The low segment can also be found by reading the first 4 bytes of the seed as a little-endian signed integer when it is encoded as a little-endian 64-bit signed integer.
     *
     * @todo Check if this still exists (I have only seen it in a world from a 1.19.60.22 dev build).
     */
    readonly GenerationSeed: {
        /**
         * The format type of the data.
         */
        readonly type: "int";
        /**
         * How many bytes this integer is.
         */
        readonly bytes: 4;
        /**
         * The endianness of the data.
         */
        readonly format: "LE";
        /**
         * The signedness of the data.
         */
        readonly signed: true;
    };
    /**
     * xxHash64 checksums of `SubChunkPrefix`, `BlockEntity`, `Entity`, and `Data2D` values.
     *
     * @deprecated Only used in versions < 1.18.0.
     *
     * @todo Figure out how to parse this.
     */
    readonly Checksums: {
        /**
         * The format type of the data.
         */
        readonly type: "unknown";
    };
    /**
     * UNDOCUMENTED.
     *
     * Possible values:
     * - `0`: False
     * - `1`: True
     *
     * @todo Try to get a world with this to see how it works.
     * @todo Add a description for this.
     *
     * @see https://github.com/MiemieMethod/bedrock-docs/blob/8cd37dacbd064f5fb2a4953548739a258b31dd21/.knowledge/wiki%E6%91%98%E5%BD%95/%E4%B8%AD%E6%96%87Minecraft%20Wiki/%E5%9F%BA%E5%B2%A9%E7%89%88LevelDB%E6%A0%BC%E5%BC%8F.wikitext?plain=1#L481
     *
     * @see https://github.com/MiemieMethod/bedrock-docs/blob/8cd37dacbd064f5fb2a4953548739a258b31dd21/.knowledge/wiki%E6%91%98%E5%BD%95/%E4%B8%AD%E6%96%87Minecraft%20Wiki/%E5%9F%BA%E5%B2%A9%E7%89%88LevelDB%E6%A0%BC%E5%BC%8F.wikitext#L1470
     * One of the sources seem to indicate this was added in 1.17.30.25. (Verify this, then add the \@since tag.)
     */
    readonly GeneratedPreCavesAndCliffsBlending: {
        /**
         * The format type of the data.
         */
        readonly type: "int";
        /**
         * How many bytes this integer is.
         */
        readonly bytes: 1;
        /**
         * The endianness of the data.
         */
        readonly format: "LE";
        /**
         * The signedness of the data.
         */
        readonly signed: false;
        /**
         * The default value to use when initializing a new entry.
         *
         * Bytes:
         * ```json
         * [0]
         * ```
         */
        readonly defaultValue: Buffer<ArrayBuffer>;
    };
    /**
     * @todo Figure out how to parse this.
     * @todo Add a description for this.
     *
     * @see https://github.com/MiemieMethod/bedrock-docs/blob/8cd37dacbd064f5fb2a4953548739a258b31dd21/.knowledge/wiki%E6%91%98%E5%BD%95/%E4%B8%AD%E6%96%87Minecraft%20Wiki/%E5%9F%BA%E5%B2%A9%E7%89%88LevelDB%E6%A0%BC%E5%BC%8F.wikitext#L1471
     * One of the sources seem to indicate this was added in 1.17.30.25.
     */
    readonly BlendingBiomeHeight: {
        /**
         * The format type of the data.
         */
        readonly type: "unknown";
    };
    /**
     * A hash which is the key in the `LevelChunkMetaDataDictionary` record
     * for the NBT metadata of this chunk. Seems like it might default to something dependent
     * on the current game or chunk version.
     *
     * This is an unsigned 64-bit hex value (16 digits, 8 bytes).
     */
    readonly MetaDataHash: {
        /**
         * The format type of the data.
         */
        readonly type: "hex";
        /**
         * The default value to use when initializing a new entry.
         *
         * Bytes:
         * ```json
         * [0, 0, 0, 0, 0, 0, 0, 0]
         * ```
         */
        readonly defaultValue: Buffer<ArrayBuffer>;
        /**
         * The minimum length of the data in bytes (if the hex data is a string of hexadecimal characters, two characters is one byte).
         */
        readonly minLength: 8;
        /**
         * The maximum length of the data in bytes (if the hex data is a string of hexadecimal characters, two characters is one byte).
         */
        readonly maxLength: 8;
    };
    /**
     * @todo Figure out how to parse this.
     * @todo Add a description for this.
     *
     * @see https://github.com/robofinch/Prismarine-Anchor/blob/main/crates/bedrock/leveldb-entries/src/entries/blending_data.rs#L10
     * @see https://github.com/MiemieMethod/bedrock-docs/blob/8cd37dacbd064f5fb2a4953548739a258b31dd21/.knowledge/wiki%E6%91%98%E5%BD%95/%E4%B8%AD%E6%96%87Minecraft%20Wiki/%E5%9F%BA%E5%B2%A9%E7%89%88LevelDB%E6%A0%BC%E5%BC%8F.wikitext#L526
     *
     * @see https://github.com/MiemieMethod/bedrock-docs/blob/8cd37dacbd064f5fb2a4953548739a258b31dd21/.knowledge/wiki%E6%91%98%E5%BD%95/%E4%B8%AD%E6%96%87Minecraft%20Wiki/%E5%9F%BA%E5%B2%A9%E7%89%88LevelDB%E6%A0%BC%E5%BC%8F.wikitext#L1475
     * One of the sources seem to indicate this was added in 1.17.30.
     */
    readonly BlendingData: {
        /**
         * The format type of the data.
         */
        readonly type: "unknown";
    };
    /**
     * The version of the actor digest data.
     *
     * Current known versions:
     * - `0`: 1.18.30 Format
     */
    readonly ActorDigestVersion: {
        /**
         * The format type of the data.
         */
        readonly type: "int";
        /**
         * How many bytes this integer is.
         */
        readonly bytes: 1;
        /**
         * The endianness of the data.
         */
        readonly format: "LE";
        /**
         * The signedness of the data.
         */
        readonly signed: false;
        /**
         * The default value to use when initializing a new entry.
         *
         * Bytes:
         * ```json
         * [0]
         * ```
         */
        readonly defaultValue: Buffer<ArrayBuffer>;
    };
    /**
     * The version of a chunk for versions < 1.16.100.
     *
     * Deleting this key causes the game to completely regenerate the corresponding chunk.
     *
     * Possible values:
     * - `0`: v0.9.0
     * - `1`: v0.9.2
     * - `2`: v0.9.5
     * - `3`: v0.17.0.1
     * - `4`: v1.1.0
     * - `5`: Converted from console to v1.1.0
     * - `6`: v1.2.0.2
     * - `7`: v1.2.0
     * - `8`: v1.2.13
     * - `9`: v1.8.0
     * - `10`: v1.9.0
     * - `11`: v1.11.0.1
     * - `12`: v1.11.0.3
     * - `13`: v1.11.0.4
     * - `14`: v1.11.1
     * - `15`: v1.12.0.4
     * - `16`: v1.14.0
     * - `17`: v1.15.0
     * - `18`: v1.16.0.51
     * - `19`: v1.16.0
     *
     * @see {@link chunkLegacyVersionDetailsMap}
     *
     * @deprecated Only used in versions < 1.16.100. Later versions use {@link entryContentTypeToFormatMap.Version | Version}
     */
    readonly LegacyVersion: {
        /**
         * The format type of the data.
         */
        readonly type: "int";
        /**
         * How many bytes this integer is.
         */
        readonly bytes: 1;
        /**
         * The endianness of the data.
         */
        readonly format: "LE";
        /**
         * The signedness of the data.
         */
        readonly signed: false;
    };
    /**
     * @deprecated It is unknown when this was removed, it was found in a Windows 10 Edition Beta v0.15.0 world.
     *
     * @todo Add a schema for this.
     * @todo Add a description for this.
     */
    readonly MVillages: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * @deprecated It is unknown when this was removed.
     *
     * @todo Add a schema for this.
     * @todo Add a description for this.
     */
    readonly Villages: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * @see {@link NBTSchemas.nbtSchemas.VillageDwellers}
     *
     * @todo Add a description for this.
     */
    readonly VillageDwellers: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * @see {@link NBTSchemas.nbtSchemas.VillageInfo}
     *
     * @todo Add a description for this.
     */
    readonly VillageInfo: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * @see {@link NBTSchemas.nbtSchemas.VillagePOI}
     *
     * @todo Add a description for this.
     */
    readonly VillagePOI: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * @see {@link NBTSchemas.nbtSchemas.VillagePlayers}
     *
     * @todo Add a description for this.
     */
    readonly VillagePlayers: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * @see {@link NBTSchemas.nbtSchemas.VillageRaid}
     *
     * @todo Add a description for this.
     */
    readonly VillageRaid: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * A player's data.
     *
     * @see {@link NBTSchemas.nbtSchemas.Player}
     */
    readonly Player: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * A player's client data.
     *
     * This includes the key for the player's {@link entryContentTypeToFormatMap.Player | server data}, the player's Microsoft account ID, and the player's self-signed ID.
     *
     * @see {@link NBTSchemas.nbtSchemas.PlayerClient}
     */
    readonly PlayerClient: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * The data for an entity in the world.
     *
     * @see {@link NBTSchemas.nbtSchemas.ActorPrefix}
     */
    readonly ActorPrefix: {
        /**
         * The format type of the data.
         */
        readonly type: "custom";
        /**
         * The format type that results from the {@link entryContentTypeToFormatMap.ActorPrefix.parse | parse} method.
         */
        readonly resultType: "JSONNBT";
        /**
         * The function to parse the data.
         *
         * The {@link data} parameter should be the buffer read directly from the file or LevelDB entry.
         *
         * @param data The data to parse, as a buffer.
         * @returns A promise that resolves with the parsed data.
         *
         * @throws {any} If an error occurs while parsing the data.
         */
        readonly parse: (data: Buffer) => NBTSchemas.NBTSchemaTypes.ActorPrefix & Pick<NBT.NBT, "name">;
        /**
         * The function to serialize the data.
         *
         * This result of this can be written directly to the file or LevelDB entry.
         *
         * @param data The data to serialize.
         * @returns The serialized data, as a buffer.
         *
         * @throws {any} If an error occurs while parsing the data.
         */
        readonly serialize: (data: NBTSchemas.NBTSchemaTypes.ActorPrefix & Partial<Pick<NBT.NBT, "name">>) => Buffer<ArrayBuffer>;
    };
    /**
     * A list of entity IDs in a chunk.
     *
     * These IDs are the ones used in the entities' LevelDB keys.
     *
     * The IDs are 32-bit signed integers.
     */
    readonly Digest: {
        /**
         * The format type of the data.
         */
        readonly type: "custom";
        /**
         * The format type that results from the {@link entryContentTypeToFormatMap.Digest.parse | parse} method.
         */
        readonly resultType: "JSONNBT";
        /**
         * The function to parse the data.
         *
         * The {@link data} parameter should be the buffer read directly from the file or LevelDB entry.
         *
         * @param data The data to parse, as a buffer.
         * @returns A promise that resolves with the parsed data.
         *
         * @throws {any} If an error occurs while parsing the data.
         */
        readonly parse: (data: Buffer) => Promise<NBTSchemas.NBTSchemaTypes.Digest>;
        /**
         * The function to serialize the data.
         *
         * This result of this can be written directly to the file or LevelDB entry.
         *
         * @param data The data to serialize.
         * @returns The serialized data, as a buffer.
         *
         * @throws {any} If an error occurs while parsing the data.
         */
        readonly serialize: (data: NBTSchemas.NBTSchemaTypes.Digest) => Buffer<ArrayBuffer>;
    };
    /**
     * The data for a map.
     *
     * This includes things such as location, image data, and decorations.
     *
     * @see {@link NBTSchemas.nbtSchemas.Map}
     */
    readonly Map: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
        /**
         * The default value to use when initializing a new entry.
         *
         * @todo Add a link to the object with the default level.dat value once it is made.
         */
        readonly defaultValue: Buffer<ArrayBuffer>;
    };
    /**
     * The content type of the `portals` LevelDB key, which stores portal data.
     *
     * @see {@link NBTSchemas.nbtSchemas.Portals}
     */
    readonly Portals: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * The content type of the `schedulerWT` LevelDB key, which stores wandering trader data.
     *
     * @see {@link NBTSchemas.nbtSchemas.SchedulerWT}
     */
    readonly SchedulerWT: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * Date for a structure (the kind saved by a structure block or the [`/structure`](https://minecraft.wiki/w/Commands/structure) command).
     *
     * @see {@link NBTSchemas.nbtSchemas.StructureTemplate}
     */
    readonly StructureTemplate: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
        /**
         * The raw file extension of the data.
         */
        readonly rawFileExtension: "mcstructure";
    };
    /**
     * A ticking area, either from an entity or the [`/tickingarea`](https://minecraft.wiki/w/Commands/tickingarea) command.
     *
     * @see {@link NBTSchemas.nbtSchemas.TickingArea}
     */
    readonly TickingArea: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * @deprecated Only used in versions < 1.5.0.
     *
     * @todo Add a description for this.
     *
     * @see https://github.com/robofinch/Prismarine-Anchor/blob/main/crates/bedrock/leveldb-entries/src/entries/flat_world_layers.rs
     */
    readonly FlatWorldLayers: {
        /**
         * The format type of the data.
         */
        readonly type: "ASCII";
    };
    /**
     * @deprecated It is unknown when this was removed, it was found in a Windows 10 Edition Beta v0.15.0 world.
     *
     * @todo Add a description for this.
     *
     * @see https://github.com/robofinch/Prismarine-Anchor/blob/main/crates/bedrock/leveldb-entries/src/entries/level_spawn_was_fixed.rs
     */
    readonly LevelSpawnWasFixed: {
        /**
         * The format type of the data.
         */
        readonly type: "UTF-8";
        /**
         * The default value to use when initializing a new entry.
         *
         * Value:
         * ```typescript
         * Buffer.from("True", "utf-8")
         * ```
         */
        readonly defaultValue: Buffer<ArrayBuffer>;
    };
    /**
     * Stores the location of a lodestone compass.
     *
     * @see {@link NBTSchemas.nbtSchemas.PositionTrackingDB}
     */
    readonly PositionTrackingDB: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * The last ID used for a lodestone compass.
     *
     * @see {@link NBTSchemas.nbtSchemas.PositionTrackingLastId}
     */
    readonly PositionTrackingLastId: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * The scoreboard data (ex. from the [`/scoreboard`](https://minecraft.wiki/w/Commands/scoreboard) command).
     *
     * @see {@link NBTSchemas.nbtSchemas.Scoreboard}
     */
    readonly Scoreboard: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * The structure data of the Overworld dimension.
     *
     * This content type coexists with the {@link entryContentTypeToFormatMap.Overworld | Overworld} content type in some versions (such as v1.0.0.16 and v1.1.5.0).
     *
     * @deprecated It is unknown when this was removed, it was found in a Windows 10 Edition Beta v0.15.0 world.
     *
     * @see {@link NBTSchemas.nbtSchemas.LegacyOverworld}
     */
    readonly LegacyOverworld: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * The structure data of the Nether dimension.
     *
     * This content type coexists with the {@link entryContentTypeToFormatMap.Nether | Nether} content type in some versions (such as v1.0.0.16 and v1.1.5.0).
     *
     * @deprecated It is unknown when this was removed, it was found in a Windows 10 Edition Beta v0.15.0 world.
     *
     * @see {@link NBTSchemas.nbtSchemas.LegacyNether}
     */
    readonly LegacyNether: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * The structure data of the End dimension.
     *
     * This content type coexists with the {@link entryContentTypeToFormatMap.TheEnd | TheEnd} content type in some versions (such as v1.0.0.16 and v1.1.5.0).
     *
     * @deprecated It is unknown when this was removed, it was found in a Windows 10 Edition Beta v0.15.0 world.
     *
     * @see {@link NBTSchemas.nbtSchemas.LegacyTheEnd}
     */
    readonly LegacyTheEnd: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * The data of the Overworld dimension.
     *
     * @see {@link NBTSchemas.nbtSchemas.Overworld}
     */
    readonly Overworld: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * The data of the Nether dimension.
     *
     * @see {@link NBTSchemas.nbtSchemas.Nether}
     */
    readonly Nether: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * The data of the End dimension.
     *
     * @see {@link NBTSchemas.nbtSchemas.TheEnd}
     */
    readonly TheEnd: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * The data of a custom dimension.
     *
     * @see {@link NBTSchemas.nbtSchemas.CustomDimension}
     */
    readonly CustomDimension: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * The content type of the `AutonomousEntities` LevelDB key, which stores a list of autonomous entities.
     *
     * @see {@link NBTSchemas.nbtSchemas.AutonomousEntities}
     *
     * @todo Add a better description for this, that includes what an autonomous entity is.
     */
    readonly AutonomousEntities: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * The content type of the `BiomeData` LevelDB key, which stores data for certain biome types.
     *
     * @see {@link NBTSchemas.nbtSchemas.BiomeData}
     */
    readonly BiomeData: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * The content type of the `BiomeIdsTable` LevelDB key, which stores the numeric ID mappings for custom biomes.
     *
     * @see {@link NBTSchemas.nbtSchemas.BiomeIdsTable}
     */
    readonly BiomeIdsTable: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * The content type of the `DimensionNameIdTable` LevelDB key, which stores the numeric ID mappings for custom biomes.
     *
     * @see {@link NBTSchemas.nbtSchemas.DimensionNameIdTable}
     */
    readonly DimensionNameIdTable: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * The content type of the `mobevents` LevelDB key, which stores what mob events are enabled or disabled.
     *
     * @see {@link NBTSchemas.nbtSchemas.MobEvents}
     */
    readonly MobEvents: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * The content type of the `level.dat` and `level.dat_old` files.
     *
     * This stores all the world settings.
     *
     * @see {@link NBTSchemas.nbtSchemas.LevelDat}
     */
    readonly LevelDat: {
        /**
         * The format type of the data.
         */
        readonly type: "custom";
        /**
         * The format type that results from the {@link entryContentTypeToFormatMap.LevelDat.parse | parse} method.
         */
        readonly resultType: "JSONNBT";
        /**
         * The function to parse the data.
         *
         * The {@link data} parameter should be the buffer read directly from the file or LevelDB entry.
         *
         * @param data The data to parse, as a buffer.
         * @returns A promise that resolves with the parsed data.
         *
         * @throws {any} If an error occurs while parsing the data.
         */
        readonly parse: (data: Buffer) => Promise<NBTSchemas.NBTSchemaTypes.LevelDat>;
        /**
         * The function to serialize the data.
         *
         * This result of this can be written directly to the file or LevelDB entry.
         *
         * @param data The data to serialize.
         * @returns The serialized data, as a buffer.
         *
         * @throws {TypeError} If {@link data} has a name property at the top level that is not of type string.
         */
        readonly serialize: (data: NBTSchemas.NBTSchemaTypes.LevelDat) => Buffer<ArrayBuffer>;
        /**
         * The default value to use when initializing a new entry.
         *
         * @todo Add a link to the object with the default level.dat value once it is made.
         */
        readonly defaultValue: Buffer<ArrayBuffer>;
        /**
         * The raw file extension of the data.
         */
        readonly rawFileExtension: "dat";
    };
    /**
     * The content type of the `WorldClocks` LevelDB key, which serves an unknown purpose.
     *
     * @see {@link NBTSchemas.nbtSchemas.WorldClocks}
     *
     * @since 1.26.10 (maybe 1.26.0)
     *
     * @todo Figure out that this is used for.
     * @todo Figure out what preview and full release this was actually added in.
     */
    readonly WorldClocks: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
        /**
         * The default value to use when initializing a new entry.
         *
         * Value:
         * ```json
         * {
         *     type: "compound",
         *     name: "",
         *     value: {
         *         clocks: {
         *             type: "list",
         *             value: {
         *                 type: "end",
         *                 value: [],
         *             },
         *         },
         *     },
         * }
         * ```
         */
        readonly defaultValue: Buffer<ArrayBufferLike>;
    };
    /**
     * Bounding boxes for structures, including structure spawns (such as a Pillager Outpost)
     * and volumes where mobs cannot spawn through the normal biome-based means (such as
     * Trial Chambers).
     *
     * @see {@link NBTSchemas.nbtSchemas.AABBVolumes}
     *
     * @since 1.21.20 (or some 1.21.20 preview)
     */
    readonly AABBVolumes: {
        /**
         * The format type of the data.
         */
        readonly type: "custom";
        /**
         * The format type that results from the {@link entryContentTypeToFormatMap.AABBVolumes.parse | parse} method.
         */
        readonly resultType: "JSONNBT";
        /**
         * The function to parse the data.
         *
         * The {@link data} parameter should be the buffer read directly from the file or LevelDB entry.
         *
         * @param data The data to parse, as a buffer.
         * @returns The parsed data.
         *
         * @throws {RangeError} If the buffer is less than 4 bytes.
         * @throws {unknown} If an error occurs while parsing the data.
         */
        readonly parse: (data: Buffer) => NBTSchemas.NBTSchemaTypes.AABBVolumes;
        /**
         * The function to serialize the data.
         *
         * This result of this can be written directly to the file or LevelDB entry.
         *
         * @param data The data to serialize.
         * @returns The serialized data, as a buffer.
         *
         * @throws {TypeError} If one of the StructureTypes entries are undefined.
         * @throws {TypeError} If one of the ChunkBoundingBoxes entries are undefined.
         * @throws {TypeError} If one of the DynamicSpawnAreas entries are undefined.
         * @throws {TypeError} If one of the StaticSpawnAreas entries are undefined.
         * @throws {unknown} If an error occurs while serializing the data.
         */
        readonly serialize: (data: NBTSchemas.NBTSchemaTypes.AABBVolumes) => Buffer<ArrayBuffer>;
    };
    /**
     * The content type of the `DynamicProperties` LevelDB key, which stores dynamic properties data for add-ons.
     *
     * @see {@link NBTSchemas.nbtSchemas.DynamicProperties}
     */
    readonly DynamicProperties: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
        /**
         * The default value to use when initializing a new entry.
         *
         * Value:
         * ```json
         * { "name": "", "type": "compound", "value": {} }
         * ```
         */
        readonly defaultValue: Buffer<ArrayBufferLike>;
    };
    /**
     * Stores the NBT metadata of all chunks. Maps the xxHash64 hash of NBT data
     * to that NBT data, so that each chunk need only store 8 bytes instead of the entire
     * NBT; most chunks have the same metadata.
     *
     * The first 4 bytes represent the number of entries as a 32-bit little-endian integer (it is unknown if it is signed or not).
     *
     * The first 4 bytes are followed by multiple chunks of data formatted as the 8 byte hash of the NBT data plus the NBT compound.
     *
     * ```
     * {BYTEx4}{BYTEx8}{NBTCompound}{BYTEx8}{NBTCompound}{BYTEx8}{NBTCompound}{BYTEx8}{NBTCompound}
     * ```
     *
     * @see {@link NBTSchemas.nbtSchemas.LevelChunkMetaDataDictionary}
     */
    readonly LevelChunkMetaDataDictionary: {
        /**
         * The format type of the data.
         */
        readonly type: "custom";
        readonly resultType: "JSONNBT";
        readonly parse: (data: Buffer) => Promise<NBTSchemas.NBTSchemaTypes.LevelChunkMetaDataDictionary>;
        readonly serialize: (data: NBTSchemas.NBTSchemaTypes.LevelChunkMetaDataDictionary) => Buffer<ArrayBuffer>;
    };
    /**
     * @todo Figure out how to parse this. (It seems that each one just has a value of 1 (`0x31`). It also seems that the data is actually based on the key, which has an id that can be used with the realms API to get the corresponding data.)
     * @todo Add a description for this.
     */
    readonly RealmsStoriesData: {
        /**
         * The format type of the data.
         */
        readonly type: "unknown";
    };
    /**
     * The content type used for LevelDB keys that are used for the forced world corruption feature of the developer version of Bedrock Edition.
     *
     * These keys are normally only found when the [`/corruptworld`](https://minecraft.wiki/w/Commands/corruptworld) command is used.
     *
     * Removing these keys fixes the forced world corruption.
     */
    readonly ForcedWorldCorruption: {
        /**
         * The format type of the data.
         */
        readonly type: "UTF-8";
        /**
         * The default value to use when initializing a new entry.
         *
         * Value:
         * ```typescript
         * Buffer.from("true", "utf-8")
         * ```
         */
        readonly defaultValue: Buffer<ArrayBuffer>;
    };
    /**
     * @todo Add a description for this.
     *
     * @see {@link NBTSchemas.nbtSchemas.ChunkLoadedRequest}
     *
     * @see https://github.com/MiemieMethod/bedrock-docs/blob/main/.knowledge/wiki%E6%91%98%E5%BD%95/%E4%B8%AD%E6%96%87Minecraft%20Wiki/%E5%9F%BA%E5%B2%A9%E7%89%88LevelDB%E6%A0%BC%E5%BC%8F.wikitext#L1175
     */
    readonly ChunkLoadedRequest: {
        /**
         * The format type of the data.
         */
        readonly type: "NBT";
    };
    /**
     * All data that has a key that is not recognized.
     */
    readonly Unknown: {
        /**
         * The format type of the data.
         */
        readonly type: "unknown";
    };
};
/**
 * The format data for an entry content type.
 *
 * Use this type if you want to have support for content type formats that aren't currently is use but may be in the future.
 *
 * This is used in the {@link entryContentTypeToFormatMap} object.
 */
export type EntryContentTypeFormatData = ({
    /**
     * The format type of the data.
     */
    readonly type: "JSON" | "SNBT" | "unknown";
} | {
    /**
     * The format type of the data.
     */
    readonly type: "ASCII" | "binary" | "binaryPlainText" | "UTF-8";
    /**
     * The minimum length of the data.
     *
     * If not present, `0` should be assumed.
     *
     * @default 0
     */
    readonly minLength?: number;
    /**
     * The maximum length of the data.
     *
     * If not present, `Infinity` should be assumed.
     *
     * @default Infinity
     */
    readonly maxLength?: number;
} | {
    /**
     * The format type of the data.
     */
    readonly type: "hex";
    /**
     * The minimum length of the data in bytes (if the hex data is a string of hexadecimal characters, two characters is one byte).
     *
     * If not present, `0` should be assumed.
     *
     * @default 0
     */
    readonly minLength?: number;
    /**
     * The maximum length of the data in bytes (if the hex data is a string of hexadecimal characters, two characters is one byte).
     *
     * If not present, `Infinity` should be assumed.
     *
     * @default Infinity
     */
    readonly maxLength?: number;
} | {
    /**
     * The format type of the data.
     */
    readonly type: "NBT";
    /**
     * The endianness of the data.
     *
     * If not present, `"LE"` should be assumed.
     *
     * - `"BE"`: Big Endian
     * - `"LE"`: Little Endian
     * - `"LEV"`: Little Varint
     *
     * @default "LE"
     */
    readonly format?: "BE" | "LE" | "LEV";
} | {
    /**
     * The format type of the data.
     */
    readonly type: "int";
    /**
     * How many bytes this integer is.
     */
    readonly bytes: number;
    /**
     * The endianness of the data.
     */
    readonly format: "BE" | "LE";
    /**
     * The signedness of the data.
     */
    readonly signed: boolean;
} | {
    /**
     * The format type of the data.
     */
    readonly type: "custom";
    /**
     * The format type that results from the {@link parse} method.
     */
    readonly resultType: "JSONNBT";
    /**
     * The function to parse the data.
     *
     * The {@link data} parameter should be the buffer read directly from the file or LevelDB entry.
     *
     * @param data The data to parse, as a buffer.
     * @returns The parsed data.
     */
    parse(data: Buffer): NBT.Compound | Promise<NBT.Compound>;
    /**
     * The function to serialize the data.
     *
     * This result of this can be written directly to the file or LevelDB entry.
     *
     * @param data The data to serialize.
     * @returns The serialized data, as a buffer.
     */
    serialize(data: NBT.Compound): Buffer | Promise<Buffer>;
} | {
    /**
     * The format type of the data.
     */
    readonly type: "custom";
    /**
     * The format type that results from the {@link parse} method.
     */
    readonly resultType: "SNBT";
    /**
     * The function to parse the data.
     *
     * The {@link data} parameter should be the buffer read directly from the file or LevelDB entry.
     *
     * @param data The data to parse, as a buffer.
     * @returns The parsed data.
     */
    parse(data: Buffer): string | Promise<string>;
    /**
     * The function to serialize the data.
     *
     * This result of this can be written directly to the file or LevelDB entry.
     *
     * @param data The data to serialize.
     * @returns The serialized data, as a buffer.
     */
    serialize(data: string): Buffer | Promise<Buffer>;
} | {
    /**
     * The format type of the data.
     */
    readonly type: "custom";
    /**
     * The format type that results from the {@link parse} method.
     */
    readonly resultType: "buffer";
    /**
     * The function to parse the data.
     *
     * The {@link data} parameter should be the buffer read directly from the file or LevelDB entry.
     *
     * @param data The data to parse, as a buffer.
     * @returns The parsed data.
     */
    parse(data: Buffer): Buffer | Promise<Buffer>;
    /**
     * The function to serialize the data.
     *
     * This result of this can be written directly to the file or LevelDB entry.
     *
     * @param data The data to serialize.
     * @returns The serialized data, as a buffer.
     */
    serialize(data: Buffer): Buffer | Promise<Buffer>;
} | {
    /**
     * The format type of the data.
     */
    readonly type: "custom";
    /**
     * The format type that results from the {@link parse} method.
     */
    readonly resultType: "unknown";
    /**
     * The function to parse the data.
     *
     * The {@link data} parameter should be the buffer read directly from the file or LevelDB entry.
     *
     * @param data The data to parse, as a buffer.
     * @returns The parsed data.
     */
    parse(data: Buffer): any | Promise<any>;
    /**
     * The function to serialize the data.
     *
     * This result of this can be written directly to the file or LevelDB entry.
     *
     * @param data The data to serialize.
     * @returns The serialized data, as a buffer.
     */
    serialize(data: any): Buffer | Promise<Buffer>;
}) & {
    /**
     * The raw file extension of the data.
     *
     * If not present, `"bin"` should be assumed.
     *
     * @default "bin"
     */
    readonly rawFileExtension?: string;
    /**
     * The default value to use when initializing a new entry.
     *
     * @default undefined
     */
    readonly defaultValue?: Buffer;
};
/**
 * Represents a two-directional vector.
 */
export interface Vector2 {
    /**
     * X component of this vector.
     */
    x: number;
    /**
     * Y component of this vector.
     */
    y: number;
}
/**
 * Represents a two-directional vector with X and Z components.
 */
export interface VectorXZ {
    /**
     * X component of this vector.
     */
    x: number;
    /**
     * Z component of this vector.
     */
    z: number;
}
/**
 * Represents a three-directional vector.
 */
export interface Vector3 {
    /**
     * X component of this vector.
     */
    x: number;
    /**
     * Y component of this vector.
     */
    y: number;
    /**
     * Z component of this vector.
     */
    z: number;
}
/**
 * An ID of a Minecraft dimension.
 */
export type Dimension = (typeof dimensions)[number];
/**
 * Represents a three-directional vector with an associated dimension.
 */
export interface DimensionLocation extends Vector3 {
    /**
     * Dimension that this coordinate is associated with.
     */
    dimension: Dimension | number;
}
/**
 * Represents a two-directional vector with an associated dimension.
 */
export interface DimensionVector2 extends Vector2 {
    /**
     * Dimension that this coordinate is associated with.
     */
    dimension: Dimension | number;
}
/**
 * Represents a two-directional vector with X and Z components and an associated dimension.
 */
export interface DimensionVectorXZ extends VectorXZ {
    /**
     * Dimension that this coordinate is associated with.
     */
    dimension: Dimension | number;
}
/**
 * Represents a two-directional vector with X and Z components and an associated dimension and a sub-chunk index.
 */
export interface SubChunkIndexDimensionVectorXZ extends DimensionVectorXZ {
    /**
     * The index of this sub-chunk.
     *
     * Should be between 0 and 15 (inclusive).
     */
    subChunkIndex: number;
}
/**
 * @todo
 */
export interface StructureSectionData extends NBT.Compound {
    /**
     * The size of the structure, as a tuple of 3 integers.
     */
    size: NBTSchemas.NBTSchemaTypes.StructureTemplate["value"]["size"];
    /**
     * The block indices.
     *
     * These are two arrays of indices in the block palette.
     *
     * The first layer is the block layer.
     *
     * The second layer is the waterlog layer, even though it is mainly used for waterlogging, other blocks can be put here to,
     * which allows for putting two blocks in the same location, or creating ghost blocks (as blocks in this layer cannot be interacted with,
     * however when the corresponding block in the block layer is broken, this block gets moved to the block layer).
     */
    block_indices: {
        type: `${NBT.TagType.List}`;
        value: {
            type: `${NBT.TagType.List}`;
            value: [
                blockLayer: {
                    type: `${NBT.TagType.Int}`;
                    value: number[];
                },
                waterlogLayer: {
                    type: `${NBT.TagType.Int}`;
                    value: number[];
                }
            ];
        };
    };
    /**
     * The block palette.
     */
    palette: {
        type: `${NBT.TagType.List}`;
        value: {
            type: `${NBT.TagType.Compound}`;
            value: NBTSchemas.NBTSchemaTypes.Block["value"][];
        };
    };
}
/**
 * Biome palette data.
 */
export interface BiomePalette {
    /**
     * The data for the individual blocks, `null` if this sub-chunk has no biome data and should not be written, or an empty array if this sub-chunk has no biome data and should be written.
     *
     * The values of this map to the index of the biome in the palette.
     */
    values: number[] | null;
    /**
     * The palette of biomes as a list of biome numeric IDs, or an empty array if this sub-chunk has no biome data.
     */
    palette: number[];
}
/**
 * The content type of a LevelDB entry.
 */
export type DBEntryContentType = (typeof DBEntryContentTypes)[number];
/**
 * A content type of a LevelDB chunk key entry (entries that use the key format of appending a byte representing the content type to the end of the key).
 */
export type DBChunkKeyEntryContentType = (typeof DBChunkKeyEntryContentTypes)[number];
/**
 * A content type of a LevelDB entry that is associated with a specific chunk.
 *
 * This includes the content types from {@link DBChunkKeyEntryContentType} as well as other content types that use different key formats but are still tied to a specific chunk.
 */
export type DBChunkLinkedContentType = (typeof DBChunkLinkedContentTypes)[number];
/**
 * The a grouping type of LevelDB entry content types.
 */
export type DBEntryContentTypeGroup = (typeof DBEntryContentTypesGrouping)[DBEntryContentType];
/**
 * Parses an integer from a buffer gives the number of bytes, endianness, signedness and offset.
 *
 * @param buffer The buffer to read from.
 * @param bytes The number of bytes to read.
 * @param format The endianness of the data.
 * @param signed The signedness of the data. Defaults to `false`.
 * @param offset The offset to read from. Defaults to `0`.
 * @returns The parsed integer.
 *
 * @throws {RangeError} If the byte length is less than 1.
 * @throws {RangeError} If the buffer does not contain enough data at the specified offset.
 */
export declare function parseSpecificIntType(buffer: Buffer, bytes: number, format: "BE" | "LE", signed?: boolean, offset?: number): bigint;
/**
 * Options for {@link writeSpecificIntType}.
 */
export interface WriteSpecificIntTypeOptions {
    /**
     * Whether to wrap the value if it is out of range.
     *
     * If `false`, an error will be thrown if the value is out of range.
     *
     * @default false
     */
    wrap?: boolean;
}
/**
 * Writes an integer to a buffer.
 *
 * @template TArrayBuffer The type of the buffer.
 * @param buffer The buffer to write to.
 * @param value The integer to write.
 * @param bytes The number of bytes to write.
 * @param format The endianness of the data.
 * @param signed The signedness of the data. Defaults to `false`.
 * @param offset The offset to write to. Defaults to `0`.
 * @param options The options to use.
 * @returns The buffer from the {@link buffer} parameter.
 *
 * @throws {RangeError} If the byte length is less than 1.
 * @throws {RangeError} If the buffer does not have enough space at the specified offset.
 * @throws {RangeError} If the value is out of range and {@link WriteSpecificIntTypeOptions.wrap | options.wrap} is `false`.
 */
export declare function writeSpecificIntType<TArrayBuffer extends ArrayBufferLike = ArrayBufferLike>(buffer: Buffer<TArrayBuffer>, value: bigint, bytes: number, format: "BE" | "LE", signed?: boolean, offset?: number, options?: WriteSpecificIntTypeOptions): Buffer<TArrayBuffer>;
/**
 * Sanitizes a filename.
 *
 * @param filename The filename to sanitize.
 * @returns The sanitized filename.
 */
export declare function sanitizeFilename(filename: string): string;
/**
 * Sanitizes a display key.
 *
 * @param key The key to sanitize.
 * @returns The sanitized key.
 */
export declare function sanitizeDisplayKey(key: string): string;
/**
 * Converts a chunk block index to an offset from the minimum corner of the chunk.
 *
 * @param index The chunk block index.
 * @returns The offset from the minimum corner of the chunk.
 */
export declare function chunkBlockIndexToOffset(index: number): Vector3;
/**
 * Converts an offset from the minimum corner of the chunk to a chunk block index.
 *
 * @param offset The offset from the minimum corner of the chunk.
 * @returns The chunk block index.
 */
export declare function offsetToChunkBlockIndex(offset: Vector3): number;
/**
 * Reads a 32-bit integer value from a Buffer at the given offset (little-endian).
 *
 * @param data The Buffer to read from.
 * @param offset The offset to read from.
 * @returns The 32-bit integer value.
 */
export declare function getInt32Val(data: Buffer, offset: number): number;
/**
 * Writes a 32-bit integer value into a Buffer at the given offset (little-endian).
 *
 * @param buffer The Buffer to write into.
 * @param offset The offset to write into.
 * @param value The 32-bit integer value to write.
 */
export declare function setInt32Val(buffer: Buffer, offset: number, value: number): void;
/**
 * Splits a range into smaller ranges of a given size.
 *
 * @param param0 The range to split.
 * @param size The size of each range.
 * @returns The split ranges.
 */
export declare function splitRange([min, max]: [min: number, max: number], size: number): [from: number, to: number][];
/**
 * Packs block indices into the buffer using the same scheme as the read loop.
 *
 * @param buffer The buffer to write into.
 * @param blockDataOffset The offset where block data begins in the buffer.
 * @param block_indices The list of block indices to pack.
 * @param bitsPerBlock The number of bits used per block.
 * @param blocksPerWord How many blocks fit inside one 32-bit integer.
 */
export declare function writeBlockIndices(buffer: Buffer, blockDataOffset: number, block_indices: number[], bitsPerBlock: number, blocksPerWord: number): void;
/**
 * Converts the dimension of a dimension vector to a numeric ID.
 *
 * @param dimension The dimension to convert.
 * @returns The numeric ID of the dimension.
 */
export declare function dimensionVectorDimensionToInt(dimension: Dimension | number): number;
/**
 * Converts the dimension of a dimension vector to a ID.
 *
 * Vanilla dimensions will not include a namespace.
 *
 * @param dimension The dimension to convert.
 * @param db The LevelDB to use.
 * @returns The ID of the dimension.
 *
 * @throws {ReferenceError} If the DimensionNameIdTable is not found.
 * @throws {ReferenceError} If the dimension is not found in the DimensionNameIdTable.
 */
export declare function dimensionVectorDimensionToId(dimension: Dimension | number, db: LevelDB): Promise<LooseAutocomplete<Dimension>>;
/**
 * Converts the dimension of a dimension vector to a ID synchronously.
 *
 * Vanilla dimensions will not include a namespace.
 *
 * @param dimension The dimension to convert.
 * @param dimensionNameIdTable The DimensionNameIdTable to use.
 * @returns The ID of the dimension.
 *
 * @throws {ReferenceError} If the dimension is not found in the DimensionNameIdTable.
 */
export declare function dimensionVectorDimensionToIdSync(dimension: Dimension | number, dimensionNameIdTable: NBTSchemas.NBTSchemaTypes.DimensionNameIdTable): LooseAutocomplete<Dimension>;
/**
 * Converts the ID of a dimension of a dimension vector.
 *
 * Vanilla dimensions do not require a namespace.
 *
 * @param dimension The dimension to convert. Case-sensitive.
 * @param db The LevelDB to use.
 * @returns The ID of the dimension.
 *
 * @throws {ReferenceError} If the DimensionNameIdTable is not found.
 * @throws {ReferenceError} If the dimension is not found in the DimensionNameIdTable.
 */
export declare function dimensionIdToDimensionVectorDimension(dimension: LooseAutocomplete<Dimension>, db: LevelDB): Promise<Dimension | number>;
/**
 * Converts the ID of a dimension of a dimension vector synchronously.
 *
 * Vanilla dimensions do not require a namespace.
 *
 * @param dimension The dimension to convert. Case-sensitive.
 * @param dimensionNameIdTable The DimensionNameIdTable to use.
 * @returns The ID of the dimension.
 *
 * @throws {ReferenceError} If the dimension is not found in the DimensionNameIdTable.
 */
export declare function dimensionIdToDimensionVectorDimensionSync(dimension: LooseAutocomplete<Dimension>, dimensionNameIdTable: NBTSchemas.NBTSchemaTypes.DimensionNameIdTable): Dimension | number;
/**
 * Converts a dimension's numeric ID to a dimension vector dimension.
 *
 * @param dimension The numeric ID of the dimension.
 * @returns The dimension vector dimension.
 */
export declare function intToDimensionVectorDimension(dimension: number): Dimension | number;
/**
 * Gets the dimension types from the DimensionNameIdTable.
 *
 * @param db The LevelDB to use.
 * @returns The dimension types.
 *
 * @throws {ReferenceError} If the DimensionNameIdTable is not found.
 */
export declare function getDimensionTypes(db: LevelDB): Promise<Record<Dimension | `${string}:${string}`, number>>;
/**
 * Gets the dimension types from the DimensionNameIdTable synchronously.
 *
 * @param dimensionNameIdTable The DimensionNameIdTable to use.
 * @returns The dimension types.
 */
export declare function getDimensionTypesSync(dimensionNameIdTable: NBTSchemas.NBTSchemaTypes.DimensionNameIdTable): Record<Dimension | `${string}:${string}`, number>;
/**
 * Gets the dimension IDs from the DimensionNameIdTable.
 *
 * @param db The LevelDB to use.
 * @returns The dimension IDs.
 *
 * @throws {ReferenceError} If the DimensionNameIdTable is not found.
 */
export declare function getDimensionIds(db: LevelDB): Promise<(Dimension | `${string}:${string}`)[]>;
/**
 * Gets the dimension IDs from the DimensionNameIdTable synchronously.
 *
 * @param dimensionNameIdTable The DimensionNameIdTable to use.
 * @returns The dimension IDs.
 */
export declare function getDimensionIdsSync(dimensionNameIdTable: NBTSchemas.NBTSchemaTypes.DimensionNameIdTable): (Dimension | `${string}:${string}`)[];
/**
 * Gets the dimension numeric IDs from the DimensionNameIdTable.
 *
 * @param db The LevelDB to use.
 * @returns The dimension numeric IDs.
 *
 * @throws {ReferenceError} If the DimensionNameIdTable is not found.
 */
export declare function getDimensionNumericIds(db: LevelDB): Promise<number[]>;
/**
 * Gets the dimension numeric IDs from the DimensionNameIdTable synchronously.
 *
 * @param dimensionNameIdTable The DimensionNameIdTable to use.
 * @returns The dimension numeric IDs.
 */
export declare function getDimensionNumericIdsSync(dimensionNameIdTable: NBTSchemas.NBTSchemaTypes.DimensionNameIdTable): number[];
/**
 * Gets the chunk indices from a LevelDB key.
 *
 * The key must be a [chunk key](https://minecraft.wiki/w/Bedrock_Edition_level_format#Chunk_key_format) or one of the following content types:
 * - {@link entryContentTypeToFormatMap.Digest | Digest}
 *
 * @param key The key to get the chunk indices for, as a Buffer.
 * @returns The chunk indices.
 */
export declare function getChunkKeyIndices(key: Buffer): SubChunkIndexDimensionVectorXZ | DimensionVectorXZ;
/**
 * Generates a raw chunk key from chunk indices.
 *
 * @param indices The chunk indices.
 * @param chunkKeyType The chunk key type.
 * @returns The raw chunk key.
 */
export declare function generateChunkKeyFromIndices(indices: SubChunkIndexDimensionVectorXZ | DimensionVectorXZ, chunkKeyType: DBChunkLinkedContentType): Buffer<ArrayBuffer>;
/**
 * Gets a human-readable version of a LevelDB key.
 *
 * @param key The key to get the display name for, as a Buffer.
 * @returns A human-readable version of the key.
 */
export declare function getKeyDisplayName(key: Buffer): string;
/**
 * Gets the content type of a LevelDB key.
 *
 * @param key The key to get the content type for, as a Buffer.
 * @returns The content type of the key.
 */
export declare function getContentTypeFromDBKey(key: Buffer): DBEntryContentType;
/**
 * Gets the biome type from its ID.
 *
 * Only works with vanilla biomes.
 *
 * @param id The ID of the biome.
 * @returns The biome type.
 */
export declare function getBiomeTypeFromID(id: number): keyof (typeof BiomeData)["int_map"] | undefined;
/**
 * Gets the biome ID from its type.
 *
 * Only works with vanilla biomes.
 *
 * @param type The type of the biome.
 * @returns The biome ID.
 */
export declare function getBiomeIDFromType(type: keyof (typeof BiomeData)["int_map"]): number | undefined;
/**
 * @todo
 */
export declare class Structure {
    /**
     * @todo
     */
    target?: {
        /**
         * The type of the target structure data.
         */
        type: "LevelDBEntry";
        /**
         * The LevelDB containing the target structure data.
         */
        db: LevelDB;
        /**
         * The key of the target structure data in the LevelDB.
         */
        key: Buffer;
    } | {
        /**
         * The type of the target structure data.
         */
        type: "File";
        /**
         * The absolute path to the target structure data.
         */
        path: string;
    } | undefined;
    /**
     * @todo
     */
    constructor(options: {
        target?: Structure["target"];
    });
    /**
     * @todo
     */
    fillBlocks(from: Vector3, to: Vector3, block: NBTSchemas.NBTSchemaTypes.Block): any;
    /**
     * @todo
     */
    saveChanges(): any;
    /**
     * @todo
     */
    delete(): any;
    /**
     * @todo
     */
    expand(min: Vector3, max: Vector3): any;
    /**
     * @todo
     */
    shrink(min: Vector3, max: Vector3): any;
    /**
     * @todo
     */
    move(min: Vector3, max: Vector3): any;
    /**
     * @todo
     */
    scale(scale: Vector3 | number): any;
    /**
     * @todo
     */
    rotate(angle: 0 | 90 | 180 | 270, axis?: "x" | "y" | "z"): any;
    /**
     * @todo
     */
    mirror(axis: "x" | "y" | "z"): any;
    /**
     * @todo
     */
    clear(): any;
    /**
     * @todo
     */
    clearSectionData(from: Vector3, to: Vector3): any;
    /**
     * @todo
     */
    getSectionData(from: Vector3, to: Vector3): StructureSectionData;
    /**
     * @todo
     */
    replaceSectionData(offset: Vector3, data: StructureSectionData, options?: StructureReplaceSectionDataOptions): any;
    /**
     * @todo
     */
    exportPrismarineNBT(): NBTSchemas.NBTSchemaTypes.StructureTemplate;
}
/**
 * Options for {@link Structure.replaceSectionData}.
 */
export interface StructureReplaceSectionDataOptions {
    /**
     * Whether to automatically expand the structure to fit the data if necessary, instead of cropping it.
     *
     * @default false
     */
    autoExpand?: boolean;
}
export {};
