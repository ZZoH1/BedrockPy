# v1.21.0

## Critical Fixes

-   Fixed many issues where the parser and serializer for the `SubChunkPrefix` content type did not work properly in certain situations.

## Breaking Changes

-   The `SubChunkPrefixLayer` NBT schema and the `layers` field of the `SubChunkPrefix` parser/serializer no longer include a `storageVersion` field.

## Additions

-   Added a default value for the `Map` content type.

# v1.20.1

## Critical Fixes

-   Fixed an issue where the serializer for the `ActorPrefix` content type would always throw an error because the `name` property of the input object was not copied over to the reencoded object.

# v1.20.0

## Critical Fixes

-   Added a custom serializer and parser for the `ActorPrefix` content type as it contains a property with a binary-encoded string value, and the regular NBT parser parses and serializes as UTF-8, so it could end up corrupting that property, and that property is very critical and changing it changes the LevelDB key the game writes the entity to, resulting in the entity no longer being loaded in the world.
-   Fixed a bug where the `getKeyDisplayName` function did not work properly for the `Digest` content type, it would incorrectly always return the Overworld as the dimension.

## Additions

-   The `getChunkKeyIndices` function now supports `Digest` keys.
-   The `generateChunkKeyFromIndices` function now supports `Digest` keys.
-   Added the following functions:
    -   `parseActorPrefixStorageKey`
    -   `parseActorPrefixStorageKeyToParts`
    -   `serializeActorPrefixStorageKey`
-   Added the following constants:
    -   `DBChunkLinkedContentTypes`
    -   `chunkLegacyVersionDetailsMap`
    -   `chunkVersionDetailsMap`
    -   `protoLEBinaryStringEncoding`
-   Added the following types:
    -   `DBChunkLinkedContentType`
-   Documented the following properties of the `ActorPrefix` NBT schema:
    -   `internalComponents`
    -   `internalComponents.EntityStorageKeyComponent`
    -   `internalComponents.EntityStorageKeyComponent.StorageKey`
-   The package now has the [`protodef`](https://www.npmjs.com/package/protodef) package as a dependency (this package was already required by `prismarine-nbt`).

## Fixes

-   Overloaded a misconfigured type for the `parseAs` function in the [`prismarine-nbt`](https://www.npmjs.com/package/prismarine-nbt) package to fix several errors.

## Performance Improvements

-   Optimizations to the `getChunkKeyIndices` function.
-   Optimizations to the `generateChunkKeyFromIndices` function.

# v1.19.0

## Critical Fixes

-   Fixed a bug where the parser for the `Data3D` content type did not work when there were subchunks with storage types of `3`, `5`, or `6`.
-   Fixed a bug where the serializer for the `Data3D` content type could not write storage types of `3`, `5`, or `6`, and instead rounded them up to the nearest storage type it supported, which may or may not have caused crashes in some Minecraft worlds.
-   Fixed a bug where `getContentTypeFromDBKey` wouldn't be able to determine the content type for the following content types in some older worlds where the dimension was not part of the key:
    -   `VillagePOI`
    -   `VillageInfo`
    -   `VillageDwellers`
    -   `VillagePlayers`
    -   `VillageRaid`

## Additions

-   Added the `DBChunkKeyEntryContentTypes` constant.
-   Added the `DBChunkKeyEntryContentType` type.

## Fixes

-   Fixed some misinformation that said that `Data2D` format version 2 was used in `v1.18.0+`, when it was actually added some time later than that.

# v1.18.0

## Breaking Changes

-   The `dirty_columns` field of the `LegacyTerrain` NBT schema and parser/serializer has been renamed to `height_map`.
-   The `Data2D` NBT schema and parser/serializer now includes a `version` field.

## Additions

-   Added the `Item_ItemStackBase` NBT schema, which is equivalent to the old `Item_ItemStack` NBT schema.
-   The `Item_ItemStack` NBT schema now references the `Item_GeneralTags` and `Item_EnchantmentTags` NBT schemas.
-   Added the `Item_GeneralTags` NBT schema.
-   Added the `Item_EnchantmentTags` NBT schema, which includes autocomplete and validation for enchantment IDs.
-   The NBT schema to TypeScript interface converter now supports `anyOf`.
-   Added support for the newer `Data2D` format version used in `v1.18.0+` which uses 16-bit little-endian integers for biome IDs instead of 8-bit integers.
-   The package now has the [`type-fest`](https://www.npmjs.com/package/type-fest) package as a dependency.

## Changes

-   Updated the `BiomeData` from `v1.21.110` to `v1.26.30` (also manually added definitions for the dappled forest, since that is not in `v1.26.30` and there is no newer definitions file available).
-   The NBT schema to TypeScript interface converter now wraps generated `oneOf` types in the `ExclusifyUnion` generic type from the [`type-fest`](https://www.npmjs.com/package/type-fest) package, this makes the typings more accurate.
-   The `Data2D` content type is no longer marked as deprecated as it is actually still written by the game for worlds using the Old world type or an older base game version.

## Fixes

-   Fixed a bug where many properties of NBT schemas that were items did not have a reference to the `Item_ItemStack` NBT schema.
-   Many fixes for the NBT schema to JSON schema converter.

# v1.17.0

## Additions

-   Added support for the "Bedrock World Editor - Player Name Saver" behavior pack for getting player's names from their UUIDs from the dynamic properties.

## Changes

-   The `playerUUIDToNameDynamicPropertyParsers` constant is now exported.

## Fixes

-   Fixed a bug where the TypeScript type version of the `LevelDat` NBT schema was missing many of the properties added in v1.16.0.
-   Fixed a bug where the following fields of the `PlayerClient` NBT schema were marked as optional:
    -   `MsaId`
    -   `SelfSignedId`
    -   `ServerId`

# v1.16.0

## Additions

-   Added a custom serializer and parser for the `BiomeState` content type.
-   Added the `BiomeState` NBT schema.
-   Added a custom serializer and parser for the `BorderBlocks` content type.
-   Added the `BorderBlocks` NBT schema.
-   Added a custom serializer and parser for the `HardcodedSpawners` content type.
-   Added the `HardcodedSpawners` NBT schema.
-   Added a custom serializer and parser for the `AABBVolumes` content type.
-   Added the `AABBVolumes` NBT schema.
-   Added the format type for the following content types:
    -   `GeneratedPreCavesAndCliffsBlending`
    -   `MetaDataHash`
    -   `ActorDigestVersion`
-   Added default values for the following content types:
    -   `GeneratedPreCavesAndCliffsBlending`
    -   `MetaDataHash`
    -   `ActorDigestVersion`
-   Documented the possible values for the following content types:
    -   `Version`
    -   `LegacyVersion`
    -   `FinalizedState`
    -   `GeneratedPreCavesAndCliffsBlending`
    -   `ActorDigestVersion`
-   Added/Updated documentation for several content types.
-   Added enum descriptions to the `version` fields of the versioned `SubChunkPrefix` NBT schemas.
-   Added the following properties to the `experiments` property of the `LevelDat` NBT schema:
    -   `data_driven_items`
    -   `data_driven_vanilla_blocks_and_items`
    -   `experimental_molang_features`
    -   `next_major_update`
    -   `vanilla_experiments`
-   Added the following properties to the `LevelDat` NBT schema:
    -   `allowAnonymousBlockDropsInEditorWorlds`
    -   `cheatsEnabled`
    -   `daylightCycle`
    -   `PlayerHasDied`
    -   `permissionsLevel`
    -   `playerPermissionsLevel`
    -   `playerssleepingpercentage`
    -   `playerwaypoints`
    -   `serverEditorConnectionPolicy`
    -   `WorldVersion`

## Fixes

-   Fixed a typo where the `doentitydrops` property of the `LevelDat` NBT schema was incorrectly named `doentitiydrops`.
-   Many fixes for the NBT schema to JSON schema converter.
-   Fixes for the NBT schema to TypeScript interface converter.

# v1.15.0

## Additions

-   Added autocomplete and validation for vanilla biome IDs in the `Data3D` NBT schema.

## Changes

-   The `Utils.Conversion.ToJSONSchema.ConvertOptions.resolveSchemaRefName` function is now exported.

## Fixes

-   Many fixes for the NBT schema to JSON schema converter.

# v1.14.2

## Critical Fixes

-   Fixed a bug where the serializer for the `Data3D` content type deleted all empty sub-chunks, resulting in sub-chunks that were supposed to have empty sub-chunks in between them all being moved to the bottom of the world without any empty gaps in between them, and also resulting in chunks with larger sub-chunk counts having their sub-chunk counts culled. This fix is backwards compatible, older versions of the module can read the serialized data as it is in the same format as Minecraft puts it.

## Fixes

-   Removed an unused `node:fs` `appendFileSync` import from `LevelUtils.ts` (the module now correctly no longer imports any built-in Node.js modules (for compatibility reasons)).

# v1.14.1

## Fixes

-   Fixed an invalid import.

# v1.14.0

## Additions

-   Added custom dimension support for chunk keys, and the `getChunkKeyIndices` and `generateChunkKeyFromIndices` functions.
-   Added the following functions:
    -   `dimensionVectorDimensionToInt`
    -   `dimensionVectorDimensionToId`
    -   `dimensionVectorDimensionToIdSync`
    -   `dimensionIdToDimensionVectorDimension`
    -   `dimensionIdToDimensionVectorDimensionSync`
    -   `intToDimensionVectorDimension`
    -   `getDimensionTypes`
    -   `getDimensionTypesSync`
    -   `getDimensionIds`
    -   `getDimensionIdsSync`
    -   `getDimensionNumericIds`
    -   `getDimensionNumericIdsSync`

## Changes

-   The `dimension` field of dimension vectors is now a union of `Dimension` and `number` instead of just `Dimension`.

## Fixes

-   Fixed a bug where the `entries` field of the `DimensionNameIdTable` NBT schema was marked as optional.

# v1.13.1

## Fixes

-   Fixed a bug where the mapping in the `getContentTypeFromDBKey` function for the `DimensionNameIdTable` content type was missing.

# v1.13.0

## Additions

-   Added the `DimensionNameIdTable` content type.
-   Added the `DimensionNameIdTable` NBT schema.
-   Added the `CustomDimension` content type.
-   Added the `CustomDimension` NBT schema.
-   Added in the rest of the `WorldClocks` NBT schema.
-   Added examples to the `BiomeOverride` field of the `LevelDat` NBT schema.

## Changes

-   The `DBEntryContentTypesGrouping` for the `BiomeIdTable` content type as been changed to `IdTable` to group it with the `DimensionNameIdTable` content type.
-   The boolean properties of the `abilities` field of the `Abilities` NBT schema now have enums.

# v1.12.0

## Additions

-   Added the `WorldClocks` content type.
-   Added the `WorldClocks` NBT schema.

# v1.11.0

## Additions

-   Added a generator variant of the `getKeysOfTypes` function: `getKeysOfTypesG`.

# v1.10.2

## Fixes

-   Fixed many markdown links in the NBT schemas that had spaces instead of underscores.

# v1.10.1

## Additions

-   Added the `y_2026_drop_1` property to the `experiments` property of the `LevelDat` NBT schema.

# v1.10.0

## Breaking Changes

-   The `Dimension` content type and corresponding NBT schema have been split up into three new content types and NBT schemas:
    -   `Overworld`
    -   `Nether`
    -   `TheEnd`
-   The `LegacyDimension` content type has been split up into three new content types:
    -   `LegacyOverworld`
    -   `LegacyNether`
    -   `LegacyTheEnd`
-   All NBT schemas have been updated to have descriptions specified on the `markdownDescription` property instead of the `description` property.
-   All NBT schemas have been updated to have enum descriptions specified on the `markdownEnumDescriptions` property instead of the `enumDescriptions` property.

## Additions

-   Added a custom serializer and parser for the `LegacyTerrain` content type.
-   Added the `LegacyTerrain` NBT schema.
-   Added a custom serializer and parser for the `Data2D` content type.
-   Added the `Data2D` NBT schema.
-   Added a custom serializer and parser for the `Data2DLegacy` content type.
-   Added the `Data2DLegacy` NBT schema.
-   Added support for `SubChunkPrefix` versions `0x00`, `0x01`, `0x02`, `0x03`, `0x04`, `0x05`, `0x06`, and `0x07`.
-   Split the `SubChunkPrefix` NBT schema into three versioned schemas, the `SubChunkPrefix` NBT schema now is a union of the three versioned schemas:
    -   `SubChunkPrefix_v0` (versions 0, 2, 3, 4, 5, 6, and 7)
    -   `SubChunkPrefix_v1` (version 1)
    -   `SubChunkPrefix_v8` (versions 8 and 9, the same as the previous `SubChunkPrefix` NBT schema)
-   Added the `LegacyOverworld` NBT schema.
-   Added the `LegacyNether` NBT schema.
-   Added the `LegacyTheEnd` NBT schema.
-   Added the `PositionTrackingLastId` NBT schema.
-   Added the `PositionTrackingDB` NBT schema.
-   Added examples for the `InventoryVersion` property of the `LevelDat` NBT schema.
-   Added the `DBEntryContentTypesGrouping` constant.
-   Added the `DBEntryContentTypeGroup` type.
-   Added the `tileID` property to the `PendingTicks` NBT schema.
-   Added default values for the following content types:
    -   `PendingTicks`
    -   `RandomTicks`
-   Added an enum to the `storageVersion` property of the `SubChunkPrefixLayer` NBT schema.
-   Added min and max item count values to several properties of various NBT schemas.
-   Added the `package.json` file to the `package.json` file's `exports` field.

## Fixes

-   The `currentTick` property of the `PendingTicks` NBT schema is now marked as optional as in older versions it doesn't exist.
-   The `time`, `x`, `y`, and `z` properties of the `PendingTicks` and `RandomTicks` NBT schemas are now marked as required.
-   The `blockState` property of the `RandomTicks` NBT schema is now marked as required.
-   Fixed over 100 markdown links in the NBT schemas that were missing a `https://minecraft.wiki/w/` prefix.

# v1.9.1

## Critical Fixes

-   Fixed an issue where the Data3D serializer could corrupt the data by serializing it with a number of bits per block that 32 was not divisible by (also made the parser able to parse those corrupted sub-chunks, though the referenced palette indices in the values arrays will likely be incorrect for those corrupted sub-chunks).

## Additions

-   Added the optional `name` property to the `GenericPrismarineJSONNBTSchema` JSON schema.
-   Made many types `exactOptionalPropertyTypes` friendly.

# v1.9.0

## Additions

-   Added the `LevelChunkMetaDataDictionary` NBT schema.
-   Added the `Digest` NBT schema.

## Changes

-   Changed the custom data structure of the `Digest` content type.

## Fixes

-   `prettyPrintSNBT` no longer inserts newlines when the `indent` option is set to `0`.

# v1.8.0

## Critical Fixes

-   Fixed a bug that has been around since the first version of this module where `MetaDataHash` keys were detected as `BlendingBiomeHeight` keys, `GeneratedPreCavesAndCliffsBlending` keys were detected as `MetaDataHash` keys, and `BlendingBiomeHeight` keys were detected as `GeneratedPreCavesAndCliffsBlending` keys.

## Additions

-   Added a custom serializer and parser for the `LevelChunkMetaDataDictionary` content type.
-   Added the `BiomeIdsTable` content type.
-   Added the `BiomeIdsTable` NBT schema.
-   Added the `VillageRaid` content type.
-   Added the `VillageRaid` NBT schema.
-   Added the `PositionTrackingDB` content type.
-   Added the `PositionTrackingLastId` content type.
-   Added the `GenerationSeed` content type.
-   Added the `LegacyDimension` content type.
-   Added the `MVillages` content type.
-   Added the `Villages` content type.
-   Added the `LevelSpawnWasFixed` content type.
-   Added a default value to the following properties of the following NBT schemas:
    -   `Map`
        -   `unlimitedTracking`
        -   `scale`
    -   `Scoreboard`
        -   `DisplayObjectives[number].SortOrder`
    -   `LevelDat`
        -   `functioncommandlimit`
        -   `maxcommandchainlength`
        -   `prid`
    -   `ActorPrefix`
        -   `Color`
        -   `Color2`
        -   `MarkVariant`
        -   `OwnerNew`
        -   `SkinID`
        -   `Strength`
        -   `StrengthMax`
        -   `Variant`
    -   `Entity_ItemEntity`
        -   `OwnerID`
    -   `Block_Piston`
        -   `NewState`
-   Added enums to the following non-boolean properties of the following NBT schemas (added enums on boolean properties are not being listed in the changelog):
    -   `Scoreboard`
        -   `DisplayObjectives[number].SortOrder`
        -   `Objectives[number].Criteria`
-   Added enums to many boolean NBT schema properties.
-   Added descriptions and titles to many NBT schema properties.
-   Added the `verticalFlySpeed` property to the `abilities` property of the `LevelDat` NBT schema.
-   Added the `isRandomSeedAllowed` property to the `LevelDat` NBT schema.
-   Added the `projectilescanbreakblocks` property to the `LevelDat` NBT schema.
-   Added the `showrecipemessages` property to the `LevelDat` NBT schema.
-   Added the `tntexplosiondropdecay` property to the `LevelDat` NBT schema.
-   Documented the `InventoryVersion` property of the `LevelDat` NBT schema.
-   Added more information to the documentation of the `texturePacksRequired` property of the `LevelDat` NBT schema.

## Changes

-   Documentation refactor to replace `Unknown.` in documentation entries of NBT schemas with one of:
    -   `UNKNOWN.`: If the schema for that tag is incomplete or completely empty as it is unknown what properties it has.
    -   `UNDOCUMENTED.`: If the tag with that description has not been documented yet or it is unknown what it does.
-   Updated the `BiomeData` from `v1.21.80` to `v1.21.110` (the update has zero actual changes).
-   Many properties of the `VillageDwellers`, `VillageInfo`, `VillagePOI`, and `VillagePlayers` NBT schemas are now marked as required.

## Fixes

-   Fixed a bug where the `list[number].id` property of the `BiomeData` NBT schema was of type `byte` instead of `short`.
-   Fixed an incorrect TypeScript type version of the `Scoreboard` NBT schema.
-   Fixed a bug where empty object types in the TypeScript type versions of NBT schemas were generated as `{}` instead of `object`.
-   Fixed a bug where a few optional properties of the `VibrationListener` property of the `Entity_Allay` NBT schema were incorrectly marked as required.
-   Fixed an incorrect NBT schema for the `decorations[number].key` property of the `Map` NBT schema.
-   Removed a `minimum` value from the list items of the `structure_world_origin` property of the `StructureTemplate` NBT schema that should not have been there.
-   Fixed the descriptions of the list items of the `structure_world_origin` property of the `StructureTemplate` NBT schema.
-   Fixed an incorrect NBT schema for the `structure.palette.default.block_position_data` property of the `StructureTemplate` NBT schema.
-   Fixed incorrect NBT schemas for following properties of the `LevelDat` NBT schema:
    -   `editorWorldType`
    -   `eduOffer`
    -   `functioncommandlimit`
    -   `spawnradius`
-   Fixed a bug where the `LevelDat` NBT schema had the `limitedWorldDepth` property incorrectly capitalized as `LimitedWorldDepth`.
-   Fixed a bug where the `LevelDat` NBT schema had the `limitedWorldWidth` property incorrectly capitalized as `LimitedWorldWidth`.
-   Fixed an incorrectly structured default value for the `LevelName` property of the `LevelDat` NBT schema.
-   Fixed incorrect documentation for the `NetworkVersion` property of the `LevelDat` NBT schema.
-   Fixed a bug where a the following optional properties of the `ActorPrefix` NBT schema were incorrectly marked as required:
    -   `CustomNameVisible`
    -   `Fire`
    -   `Persistent`
-   Minor whitespace fixes with some instances of the following in the documentation:
    -   `*needs testing*`
    -   `*info needed*`

# v1.7.3

## Fixes

-   Fixed a bug where the `LevelDat` NBT schema had the `isSingleUseWorld` property incorrectly capitalized as `IsSingleUseWorld`.

# v1.7.2

## Fixes

-   Fixed an incorrect `Entries` field in the NBT schema for the `Scoreboard` content type.

# v1.7.1

## Fixes

-   Fixed an incorrect NBT schema for the `Scoreboard` content type.

# v1.7.0

## Additions

-   Added a custom serializer and parser for the `Digest` content type.

# v1.6.0

## Additions

-   Added the `ChunkLoadedRequest` content type.
-   Added the `ChunkLoadedRequest` NBT schema.

## Fixes

-   Fixed a bug where the enum descriptions of the NBT schemas and NBT schema types for boolean byte values had `1` mapped to `false` and `0` mapped to `true`.
-   Fixed a bug where the following properties were missing from the type version of the NBT schema for `LevelDat`:
    -   `editorWorldType`
    -   `HasUncompleteWorldFileOnDisk`

# v1.5.7/v1.5.10

## Critical Fixes

-   Overloaded several misconfigured types in the [`prismarine-nbt`](https://www.npmjs.com/package/prismarine-nbt) package to fix several errors.

# v1.5.6

## Changes

-   Updated the `LevelDat` NBT schema to include the following properties:
    -   `editorWorldType`
    -   `HasUncompleteWorldFileOnDisk`
    -   `locatorbar`

# v1.5.4

## Critical Fixes

-   Fixed a bug where the custom parser for the `LevelDat` content type returned an empty compound instead of the expected NBT data.

# v1.5.3

## Fixes

-   Fixed a bug where the format type of the `HardcodedSpawners` content type was `NBT` instead of `unknown`.
-   Fixed a bug where the `type` property of a few of the content types was undocumented.

## Development Changes

-   JSON files generated by the test scripts now use the `CRLF` line ending instead of the `LF` line ending.

# v1.5.2

## Additions

-   Added two new NBT schemas:
    -   `PendingTicks`
    -   `RandomTicks`

# v1.5.1

## Fixes

-   Reverted the following content types back to use the regular NBT format type instead of a custom parser and serializer due to them actually being a single NBT compound and not a list of them (contrary to what the Minecraft Wiki says):
    -   `PendingTicks`
    -   `RandomTicks`

# v1.5.0

## Additions

-   Added custom serializers and parsers for the following content types:
    -   `BlockEntity`
    -   `Entity`
    -   `PendingTicks`
    -   `RandomTicks`

## Changes

-   Marked the following content types as deprecated:
    -   `FlatWorldLayers`
    -   `Entity`

# v1.4.0

## Critical fixes

-   Fixed a bug where if the object passed into the `indices` parameter of the `generateChunkKeyFromIndices` function had a `subChunkIndex` property with a value of `undefined`, then the function would return the chunk key with the sub-chunk index set to `0` instead of not including the sub-chunk index in the key, which would result in incorrect chunk keys.

## Additions

-   Added the format type for the following content types:
    -   `ForcedWorldCorruption`
-   Added default values for the following content types:
    -   `Version`
    -   `FinalizedState`
    -   `LevelDat`
    -   `DynamicProperties`
    -   `ForcedWorldCorruption`
-   Added the `rawFileExtension` property to the following content types:
    -   `StructureTemplate`
    -   `LevelDat`
-   Added a custom serializer and parser for the `LevelDat` content type as it was actually not just pure NBT, as there was 8 bytes of important extra data before the NBT data.
-   Added/Updated documentation for several content types.
-   Added the `DynamicProperties` NBT schema.

## Changes

-   Changed the return type of the `serialize` method for the `Data3D` and `SubChunkPrefix` content types from `Buffer<ArrayBufferLike>` to `Buffer<ArrayBuffer>`.
-   Changed many types to use the more explicit `Buffer<ArrayBuffer>` type instead of `Buffer` (i.e. `Buffer<ArrayBufferLike>`).
-   The properties of the `EntryContentTypeFormatData` type are now read-only.

## Fixes

-   Fixed a bug where the `getChunkKeyIndices` function return an object containing a `subChunkIndex` property with a value of `undefined` when the key had no sub-chunk index, instead of not including that property at all.

## Performance Improvements

-   Performance improvements to the `getKeysOfTypes` function when passing buffers to it (it now only gets the content type of each key once instead of twice).

# v1.3.4

## Critical Fixes

-   Fixed a bug where the SNBT stringifier did not escape control characters (`\x00-\x1F`), characters in the `\uD800-\uDFFF` range, or characters `\u2028` or `\u2029`.

# v1.3.3

## Fixes

-   Fixed a bug where the `getKeyDisplayName` function did not include the sub-chunk index in the display name if it was 0.

# v1.3.2

## Critical Fixes

-   Fixed the parser and serializer for the `Data3D` content type.

# v1.3.1

## Fixes

-   Fixed the `StructureTemplate` NBT schema.

# v1.3.0

## Additions

-   Added the `generateChunkKeyFromIndices` function.
-   Added the `getIntFromChunkKeyType` function.
-   Added the `DBChunkKeyEntryContentType` type.

# v1.2.4

## Fixes

-   The `getChunkKeyIndices` function now correctly converts the sub-chunk index to a signed integer instead of an unsigned integer.

# v1.2.3

## Fixes

-   Fixed the `chunkBlockIndexToOffset` and `offsetToChunkBlockIndex` mixing up the Y and Z axes.

# v1.2.2

## Changes

-   Updated the `TickingArea` NBT schema.

# v1.2.1

## Additions

-   Documented a lot more of the module.

## Fixes

-   Fixed the `Entity` NBT schemas and the `world_policies` property of the `LevelDat` NBT schema.

# v1.2.0

## Changes

-   Replaced the [`leveldb-zlib`](https://www.npmjs.com/package/leveldb-zlib) package with the [`@8crafter/leveldb-zlib`](https://www.npmjs.com/package/@8crafter/leveldb-zlib) package.

# v1.1.0

## Additions

-   Added a Changelog file.
-   Added two new NBT schemas:
    -   `SubChunkPrefix`
    -   `SubChunkPrefixLayer`
-   Added some more NBT schema aliases.

## Fixes

-   Fixed many bugs where the NBT schema to TypeScript type converter, and used it to fix some major issues with the types in the `NBTSchemas.NBTSchemaTypes` namespace.

## Development Changes

-   Updated the list of unwanted VSCode extension recommendations.

# v1.0.1

## Additions

-   Added a README file.

# v1.0.0

-   Initial Release
