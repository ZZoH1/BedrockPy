import NBT, {} from "prismarine-nbt";
function toPrimitive(tag) {
    switch (tag.type) {
        case "byte":
        case "short":
        case "int":
        case "float":
        case "double":
            return tag.value;
        case "long":
            return Number(toLong(tag.value));
        default:
            throw new SyntaxError("Cannot convert to primitive: " + tag.type);
    }
}
function uuidToIntArray(uuidStr) {
    const hex = uuidStr.replace(/-/g, "");
    if (hex.length !== 32)
        throw new SyntaxError("Invalid UUID: " + uuidStr, {
            cause: {
                position: 0,
                stack: [
                    {
                        input: uuidStr,
                        positionInInput: 0,
                        function: "uuidToIntArray",
                        error: { type: "InvalidUUID", uuid: uuidStr },
                    },
                ],
            },
        });
    const arr = [];
    for (let i = 0; i < 16; i += 4) {
        arr.push((parseInt(hex.slice(i, i + 4), 16) << 16) >> 16); // 32-bit signed chunks
    }
    return arr;
}
/**
 * Maps SNBT parse error types to error codes.
 */
export const SNBTParseErrorTypeToCode = {
    /**
     * An error that occurred because a disallowed type was found in a typed array.
     */
    DisallowedTypeInTypedArray: "disallowed-type-in-typed-array",
    /**
     * An error that occurred because an expected compound or list was not found.
     */
    ExpectedCompoundOrList: "expected-compound-or-list",
    /**
     * An error that occurred because an argument to a function was invalid.
     */
    InvalidArgumentToFunction: "invalid-argument-to-function",
    /**
     * An error that occurred because an SNBT key was invalid.
     */
    InvalidSNBTKey: "invalid-snbt-key",
    /**
     * An error that occurred because an SNBT string was invalid.
     */
    InvalidSNBTString: "invalid-snbt-string",
    /**
     * An error that occurred because a UUID was invalid.
     */
    InvalidUUID: "invalid-uuid",
    /**
     * An error that occurred because an unsupported function was called.
     */
    UnsupportedFunction: "unsupported-function",
    /**
     * An error that occurred because an unsupported SNBT primitive was found.
     */
    UnsupportedSNBTPrimitive: "unsupported-snbt-primitive",
    /**
     * An error that occurred because a list contained multiple types.
     */
    MixedListTypesNotAllowed: "mixed-list-types-not-allowed",
    /**
     * An error that occurred because an unsupported type was found in a typed array.
     */
    UnsupportedTypeInTypedArray: "unsupported-type-in-typed-array",
    /**
     * An error that occurred because the end of the input was expected.
     */
    ExpectedEndOfInput: "expected-end-of-input",
};
/**
 * The namespace of SNBT parse errors.
 */
export const SNBTParseErrorDisplayNamespace = "mcbe-leveldb";
/**
 * An SNBT parse error.
 */
export var SNBTParseError = new Proxy(
/**
 * An SNBT parse error.
 */
class SNBTParseError extends Error {
    isResolved = false;
    originalInput = null;
    constructor(message, options) {
        if (arguments.length !== 2)
            throw new TypeError(`Incorrect number of arguments to constructor, expected 2 but got ${arguments.length} instead.`);
        if (typeof message !== "string")
            throw new TypeError(`Expected args[0] (message) to be a string but got ${typeof message} instead.`);
        if (typeof options !== "object" || options === null)
            throw new TypeError(`Expected args[1] (options) to be an object but got ${options === null ? "null" : typeof options} instead.`);
        if (typeof options.cause !== "object" || options.cause === null)
            throw new TypeError(`Expected options.cause to be an object but got ${options === null ? "null" : typeof options.cause} instead.`);
        super(message, options);
        this.isResolved = options.resolved ?? false;
        this.originalInput = options.originalInput ?? null;
    }
    getErrorPosition() {
        if (!this.isResolved || this.originalInput === null)
            return null;
        const cause = this.cause;
        const position = cause.position;
        const input = this.originalInput;
        return [input.slice(0, position).split("\n").length, position - input.slice(0, position).lastIndexOf("\n") + 1];
    }
    getErrorEndPosition() {
        if (!this.isResolved || this.originalInput === null)
            return null;
        const cause = this.cause;
        let offset = 0;
        const stackItem = cause.stack[0];
        stackItemFunctionSwitcher: switch (stackItem.function) {
            case "extractSNBT":
                switch (stackItem.error?.type) {
                    case "InvalidSNBTKey":
                        offset = stackItem.error.raw.length;
                        break stackItemFunctionSwitcher;
                    default:
                        offset = stackItem.input.length - stackItem.positionInInput;
                        break stackItemFunctionSwitcher;
                }
            case "parseList":
                switch (stackItem.error?.type) {
                    case "MixedListTypesNotAllowed":
                        offset = stackItem.inputItem.length - stackItem.positionInInputItem;
                        break stackItemFunctionSwitcher;
                    default:
                        offset = stackItem.inputItem.length - stackItem.positionInInputItem;
                        break stackItemFunctionSwitcher;
                }
            case "parseSNBTCompoundString":
                switch (stackItem.error?.type) {
                    case "InvalidSNBTKey":
                        offset = stackItem.error.raw.length;
                        break stackItemFunctionSwitcher;
                    default:
                        offset = stackItem.input.length - stackItem.positionInInput;
                        break stackItemFunctionSwitcher;
                }
            case "parseSNBTPrimitive":
                switch (stackItem.error?.type) {
                    case "InvalidArgumentToFunction":
                        offset = stackItem.error.argument.length;
                        break stackItemFunctionSwitcher;
                    case "UnsupportedFunction":
                        offset = stackItem.error.functionName.length;
                        break stackItemFunctionSwitcher;
                    case "UnsupportedSNBTPrimitive":
                        offset = stackItem.error.raw.length;
                        break stackItemFunctionSwitcher;
                    case "InvalidSNBTString":
                        offset = stackItem.error.raw.length;
                        break stackItemFunctionSwitcher;
                    default:
                        offset = stackItem.input.length - stackItem.positionInInput;
                        break stackItemFunctionSwitcher;
                }
            case "parseTypedArray":
                switch (stackItem.error?.type) {
                    case "DisallowedTypeInTypedArray":
                        offset = stackItem.inputItem.length - stackItem.positionInInputItem;
                        break stackItemFunctionSwitcher;
                    case "UnsupportedTypeInTypedArray":
                        offset = stackItem.inputItem.length - stackItem.positionInInputItem;
                        break stackItemFunctionSwitcher;
                    default:
                        offset = stackItem.inputItem.length - stackItem.positionInInputItem;
                        break stackItemFunctionSwitcher;
                }
            case "uuidToIntArray":
                offset = stackItem.error.uuid.length;
                break;
        }
        const position = cause.position + offset;
        const input = this.originalInput;
        return [input.slice(0, position).split("\n").length, position - input.slice(0, position).lastIndexOf("\n") + 1];
    }
    getErrorPositionWithOffset(offset) {
        if (!this.isResolved || this.originalInput === null)
            return null;
        const cause = this.cause;
        const position = cause.position + offset;
        const input = this.originalInput;
        return [input.slice(0, position).split("\n").length, position - input.slice(0, position).lastIndexOf("\n") + 1];
    }
    getErrorPositionForStackItem(stackItem) {
        const input = "input" in stackItem ? stackItem.input : stackItem.inputItem;
        const position = "positionInInput" in stackItem ? stackItem.positionInInput : stackItem.positionInInputItem;
        return [input.slice(0, position).split("\n").length, position - input.slice(0, position).lastIndexOf("\n") + 1];
    }
}, {
    apply(target, thisArg, argumentsList) {
        return new target(...argumentsList);
    },
});
function parseSNBTPrimitive(raw, options = {}) {
    const errors = [];
    function structureResult(val) {
        if (options.keepGoingAfterError)
            return { value: val, errors };
        return val;
    }
    try {
        if (typeof raw === "string") {
            const originalInput = raw;
            raw = raw.trim();
            const funcMatch = raw.match(/^(\w+)\((.*)\)$/s);
            if (funcMatch) {
                const fn = funcMatch[1];
                const arg = funcMatch[2].trim();
                switch (fn) {
                    case "bool": {
                        const baseVal = parseSNBTPrimitive(arg, options);
                        if ("errors" in baseVal) {
                            baseVal.errors.forEach((err) => {
                                err.cause.stack.push({
                                    input: originalInput,
                                    positionInInput: originalInput.indexOf(raw) + fn.length + 1,
                                    function: "parseSNBTPrimitive",
                                });
                                err.cause.position += originalInput.indexOf(raw) + fn.length + 1;
                            });
                            errors.push(...baseVal.errors);
                        }
                        const val = "errors" in baseVal ? baseVal.value : baseVal;
                        if (!val)
                            return structureResult();
                        if (val.type === "short" || val.type === "int" || val.type === "long" || val.type === "float" || val.type === "double") {
                            const num = Number(toPrimitive(val));
                            return structureResult(NBT.byte(num === 0 ? 0 : 1));
                        }
                        if (val.type === "byte")
                            return val;
                        throw new SNBTParseError(`Invalid argument to bool(): ${arg}`, {
                            cause: {
                                position: originalInput.indexOf(raw) + fn.length + 1,
                                stack: [
                                    {
                                        input: originalInput,
                                        positionInInput: originalInput.indexOf(raw) + fn.length + 1,
                                        function: "parseSNBTPrimitive",
                                        error: { type: "InvalidArgumentToFunction", functionName: "bool", argument: arg },
                                    },
                                ],
                            },
                        });
                    }
                    case "uuid": {
                        const uuidStr = arg.replace(/^["']|["']$/g, "");
                        try {
                            const uuidIntArray = uuidToIntArray(uuidStr);
                            return structureResult(NBT.intArray(uuidIntArray));
                        }
                        catch (e) {
                            if (e instanceof Error && e.cause) {
                                e.cause.stack.push({
                                    positionInInput: originalInput.indexOf(raw) + fn.length + 1,
                                    input: originalInput,
                                    function: "parseSNBTPrimitive",
                                    error: {
                                        type: "InvalidArgumentToFunction",
                                        functionName: "uuid",
                                        argument: arg,
                                    },
                                });
                                e.cause.position += originalInput.indexOf(raw) + fn.length + 1;
                            }
                            throw e;
                        }
                    }
                    default:
                        throw (new ReferenceError(`Unsupported SNBT function: ${fn}`),
                            {
                                cause: {
                                    position: originalInput.indexOf(raw) + fn.length + 1,
                                    stack: [
                                        {
                                            input: originalInput,
                                            positionInInput: originalInput.indexOf(raw) + fn.length + 1,
                                            function: "parseSNBTPrimitive",
                                            error: { type: "UnsupportedFunction", functionName: fn },
                                        },
                                    ],
                                },
                            });
                }
            }
            const arrMatch = raw.match(/^\[(B|S|I|L);\s*(.*?)\]$/is);
            if (arrMatch) {
                const type = arrMatch[1].toUpperCase();
                const items = arrMatch[2].split(/\s*,\s*/).filter(Boolean);
                const baseVal = parseTypedArray(type, items, options);
                if ("errors" in baseVal) {
                    baseVal.errors.forEach((err) => {
                        const lastStackItem = err.cause.stack.at(-1);
                        const baseOffset = arrMatch[2].match(new RegExp(`^(.*?\\s*(,\\s*|$)){${lastStackItem.inputItemIndex}}`))?.[0]?.length ?? 0;
                        err.cause.stack.push({
                            input: originalInput,
                            positionInInput: originalInput.indexOf(raw) + raw.indexOf(arrMatch[2]) + baseOffset,
                            function: "parseSNBTPrimitive",
                        });
                        err.cause.position += originalInput.indexOf(raw) + raw.indexOf(arrMatch[2]) + baseOffset;
                    });
                    errors.push(...baseVal.errors);
                }
                return structureResult("errors" in baseVal ? baseVal.value : baseVal);
            }
            const listMatch = raw.match(/^\[\s*(.*?)\]$/is);
            if (listMatch) {
                const baseVal = extractSNBT(raw, options);
                if ("errors" in baseVal) {
                    baseVal.errors.forEach((err) => {
                        err.cause.stack.push({
                            input: originalInput,
                            positionInInput: originalInput.indexOf(raw),
                            function: "parseSNBTPrimitive",
                        });
                        err.cause.position += originalInput.indexOf(raw);
                    });
                    errors.push(...baseVal.errors);
                }
                return structureResult("errors" in baseVal ? baseVal.value : baseVal.value);
            }
            const match = raw.match(/^([-+]?0x[\da-fA-F]+|0b[01]+|[-+]?\d*\.?\d*(?:[eE][-+]?\d+)?)([bsilfdBSILFD])?$/i);
            if (match) {
                const numStr = match[1];
                const suffix = match[2]?.toLowerCase();
                let value;
                if (numStr.startsWith("0x"))
                    value = parseInt(numStr, 16);
                else if (numStr.startsWith("0b"))
                    value = parseInt(numStr.slice(2), 2);
                else if (suffix === "l")
                    value = BigInt(numStr);
                else
                    value = Number(numStr);
                switch (suffix) {
                    case "b":
                        return structureResult(NBT.byte(Number(value)));
                    case "s":
                        return structureResult(NBT.short(Number(value)));
                    case "i":
                        return structureResult(NBT.int(Number(value)));
                    case "l":
                        return structureResult(NBT.long(toLongParts(BigInt(value))));
                    case "f":
                        return structureResult(NBT.float(Number(value)));
                    case "d":
                        return structureResult(NBT.double(Number(value)));
                    default:
                        if (typeof value === "bigint")
                            return structureResult(NBT.long(toLongParts(value)));
                        if (Number.isInteger(value))
                            return structureResult(NBT.int(value));
                        return structureResult(NBT.double(value));
                }
            }
            if (["true", "false"].includes(raw))
                return structureResult(NBT.byte(+(raw === "true")));
            try {
                return structureResult({
                    type: "string",
                    value: parseFormattedString(raw),
                });
            }
            catch {
                const error = new SNBTParseError("Invalid SNBT string: " + raw, {
                    cause: {
                        position: originalInput.indexOf(raw),
                        stack: [
                            {
                                function: "parseSNBTPrimitive",
                                input: originalInput,
                                positionInInput: originalInput.indexOf(raw),
                                error: {
                                    type: "InvalidSNBTString",
                                    raw,
                                },
                            },
                        ],
                    },
                });
                if (options.keepGoingAfterError)
                    errors.push(error);
                else
                    throw error;
                return structureResult();
            }
        }
        if (typeof raw === "number") {
            if (raw % 1 !== 0)
                return structureResult(NBT.double(raw));
            return structureResult(NBT.int(raw));
        }
        if (typeof raw === "bigint")
            return structureResult(NBT.long(toLongParts(raw)));
        if (typeof raw === "boolean")
            return structureResult(NBT.byte(+raw));
        throw new SNBTParseError("Unsupported SNBT primitive: " + raw, {
            cause: {
                position: 0,
                stack: [
                    {
                        function: "parseSNBTPrimitive",
                        input: raw,
                        positionInInput: 0,
                        error: {
                            type: "UnsupportedSNBTPrimitive",
                            raw,
                        },
                    },
                ],
            },
        });
    }
    catch (e) {
        if (options.keepGoingAfterError && e instanceof SNBTParseError)
            errors.push(e);
        else
            throw e;
        return structureResult();
    }
}
/**
 * The letter types of typed arrays.
 *
 * @internal
 */
var TypedArrayLetterTypes;
(function (TypedArrayLetterTypes) {
    /**
     * A byte array.
     */
    TypedArrayLetterTypes["B"] = "byte";
    /**
     * A short array.
     */
    TypedArrayLetterTypes["S"] = "short";
    /**
     * An integer array.
     */
    TypedArrayLetterTypes["I"] = "int";
    /**
     * A long array.
     */
    TypedArrayLetterTypes["L"] = "long";
})(TypedArrayLetterTypes || (TypedArrayLetterTypes = {}));
function parseTypedArray(type, items, options = {}) {
    const errors = [];
    const values = [];
    let i = 0;
    for (const x of items) {
        try {
            if (/^-?\d+b$/i.test(x)) {
                const n = Number(x.slice(0, -1));
                if (type === "L")
                    values.push(toLongParts(BigInt(n)));
                else if (!["B", "S", "I", "L"].includes(type))
                    throw new SNBTParseError(`Byte value not allowed in ${TypedArrayLetterTypes[type]} array: ${x}`, {
                        cause: {
                            position: 0,
                            stack: [
                                {
                                    function: "parseTypedArray",
                                    inputItems: items,
                                    inputItem: x,
                                    inputItemIndex: i,
                                    positionInInputItem: 0,
                                    arrayType: TypedArrayLetterTypes[type],
                                    error: {
                                        type: "DisallowedTypeInTypedArray",
                                        allowedTypes: [TypedArrayLetterTypes.B, TypedArrayLetterTypes.S, TypedArrayLetterTypes.I, TypedArrayLetterTypes.L],
                                        itemType: NBT.TagType.Byte,
                                    },
                                },
                            ],
                        },
                    });
                else
                    values.push(n);
            }
            else if (/^-?\d+s$/i.test(x)) {
                const n = Number(x.slice(0, -1));
                if (type === "L")
                    values.push(toLongParts(BigInt(n)));
                else if (!["S", "I", "L"].includes(type))
                    throw new SNBTParseError(`Short value not allowed in ${TypedArrayLetterTypes[type]} array: ${x}`, {
                        cause: {
                            position: 0,
                            stack: [
                                {
                                    function: "parseTypedArray",
                                    inputItems: items,
                                    inputItem: x,
                                    inputItemIndex: i,
                                    positionInInputItem: 0,
                                    arrayType: TypedArrayLetterTypes[type],
                                    error: {
                                        type: "DisallowedTypeInTypedArray",
                                        allowedTypes: [TypedArrayLetterTypes.B, TypedArrayLetterTypes.S, TypedArrayLetterTypes.I, TypedArrayLetterTypes.L],
                                        itemType: NBT.TagType.Short,
                                    },
                                },
                            ],
                        },
                    });
                else
                    values.push(n);
            }
            else if (/^-?\d+l$/i.test(x)) {
                if (type !== "L")
                    throw new SNBTParseError(`Long value not allowed in ${TypedArrayLetterTypes[type]} array: ${x}`, {
                        cause: {
                            position: 0,
                            stack: [
                                {
                                    function: "parseTypedArray",
                                    inputItems: items,
                                    inputItem: x,
                                    inputItemIndex: i,
                                    positionInInputItem: 0,
                                    arrayType: TypedArrayLetterTypes[type],
                                    error: {
                                        type: "DisallowedTypeInTypedArray",
                                        allowedTypes: [TypedArrayLetterTypes.B, TypedArrayLetterTypes.S, TypedArrayLetterTypes.I, TypedArrayLetterTypes.L],
                                        itemType: NBT.TagType.Long,
                                    },
                                },
                            ],
                        },
                    });
                values.push(parseLong(x));
            }
            else if (/^-?\d+i?$/.test(x)) {
                const n = x.toLowerCase().endsWith("i") ? Number(x.slice(0, -1)) : Number(x);
                if (type === "L")
                    values.push(toLongParts(BigInt(n)));
                else if (!["I", "L"].includes(type))
                    throw new SNBTParseError(`Int value not allowed in ${TypedArrayLetterTypes[type]} array: ${x}`, {
                        cause: {
                            position: 0,
                            stack: [
                                {
                                    function: "parseTypedArray",
                                    inputItems: items,
                                    inputItem: x,
                                    inputItemIndex: i,
                                    positionInInputItem: 0,
                                    arrayType: TypedArrayLetterTypes[type],
                                    error: {
                                        type: "DisallowedTypeInTypedArray",
                                        allowedTypes: [TypedArrayLetterTypes.B, TypedArrayLetterTypes.S, TypedArrayLetterTypes.I, TypedArrayLetterTypes.L],
                                        itemType: NBT.TagType.Int,
                                    },
                                },
                            ],
                        },
                    });
                else
                    values.push(n);
            }
            else if (["true", "false"].includes(x)) {
                values.push(+(x === "true"));
            }
            else {
                throw new SNBTParseError(`Unsupported value in ${TypedArrayLetterTypes[type]} array: ${x}`, {
                    cause: {
                        position: 0,
                        stack: [
                            {
                                function: "parseTypedArray",
                                inputItems: items,
                                inputItem: x,
                                inputItemIndex: i,
                                positionInInputItem: 0,
                                arrayType: TypedArrayLetterTypes[type],
                                error: {
                                    type: "UnsupportedTypeInTypedArray",
                                    itemType: (() => {
                                        try {
                                            return parseSNBTPrimitive(x).type;
                                        }
                                        catch {
                                            return undefined;
                                        }
                                    })(),
                                },
                            },
                        ],
                    },
                });
            }
        }
        catch (e) {
            if (options.keepGoingAfterError && e instanceof SNBTParseError)
                errors.push(e);
            else
                throw e;
        }
        i++;
    }
    let result;
    switch (type) {
        case "B":
            result = NBT.byteArray(values);
            break;
        case "S":
            result = NBT.shortArray(values);
            break;
        case "I":
            result = NBT.intArray(values);
            break;
        case "L":
            result = NBT.longArray(values);
            break;
    }
    return options.keepGoingAfterError ? { value: result, errors } : result;
}
function parseList(items, options = {}) {
    console.log(items, items.length);
    const errors = [];
    let values = [];
    let valueIndices = [];
    let i = 0;
    for (const x of items) {
        try {
            if (x.trim().startsWith("{")) {
                const baseVal = parseSNBTCompoundString(x, options);
                if ("errors" in baseVal) {
                    baseVal.errors.forEach((err) => {
                        err.cause.stack.push({
                            inputItem: x,
                            inputItemIndex: i,
                            inputItems: items,
                            positionInInputItem: 0,
                            function: "parseList",
                        });
                        err.cause.position += 0;
                    });
                    errors.push(...baseVal.errors);
                }
                values.push("errors" in baseVal ? baseVal.value : baseVal);
            }
            else {
                const baseVal = parseSNBTPrimitive(x, options);
                if ("errors" in baseVal) {
                    baseVal.errors.forEach((err) => {
                        err.cause.stack.push({
                            inputItem: x,
                            inputItemIndex: i,
                            inputItems: items,
                            positionInInputItem: 0,
                            function: "parseList",
                        });
                        err.cause.position += 0;
                    });
                    errors.push(...baseVal.errors);
                }
                const val = "errors" in baseVal ? baseVal.value : baseVal;
                if (val !== undefined)
                    values.push(val);
            }
            valueIndices.push(i);
        }
        catch (e) {
            if (options.keepGoingAfterError && e instanceof SNBTParseError)
                errors.push(e);
            else
                throw e;
        }
        i++;
    }
    let type = values[0]?.type;
    if (type &&
        !values.every((v, i) => {
            if (v.type === type) {
                return true;
            }
            if (!(options.mixedListsAllowed ?? true)) {
                if (!options.keepGoingAfterError)
                    throw new SNBTParseError("Mixed list types not allowed.", {
                        cause: {
                            position: 0,
                            stack: [
                                {
                                    function: "parseList",
                                    inputItems: items,
                                    inputItem: items[i],
                                    inputItemIndex: valueIndices[i],
                                    positionInInputItem: 0,
                                    error: {
                                        type: "MixedListTypesNotAllowed",
                                        itemType: v.type,
                                        item: v,
                                        detectedArrayType: type,
                                    },
                                },
                            ],
                        },
                    });
            }
            return false;
        })) {
        if (!(options.mixedListsAllowed ?? true) && options.keepGoingAfterError) {
            const numOfEachType = values.reduce((acc, v) => ({ ...acc, [v.type]: (acc[v.type] ?? 0) + 1 }), {});
            const mostCommonType = Object.entries(numOfEachType).reduce((a, b) => (a[1] > b[1] ? a : b))[0];
            for (let i = 0; i < values.length; i++) {
                if (values[i].type === mostCommonType)
                    continue;
                errors.push(new SNBTParseError("Mixed list types not allowed.", {
                    cause: {
                        position: 0,
                        stack: [
                            {
                                function: "parseList",
                                inputItems: items,
                                inputItem: items[i],
                                inputItemIndex: valueIndices[i],
                                positionInInputItem: 0,
                                error: {
                                    type: "MixedListTypesNotAllowed",
                                    itemType: values[i].type,
                                    item: values[i],
                                    detectedArrayType: type,
                                },
                            },
                        ],
                    },
                }));
            }
        }
        if (options.convertMixedListsToCompoundLists ?? true)
            values = values.map((v, i) => ({ type: NBT.TagType.Compound, value: { "": v } }));
    }
    const result = NBT.list({ type: values[0]?.type ?? "end", value: values.map((v) => v.value) });
    return options.keepGoingAfterError ? { value: result, errors } : result;
}
export function parseSNBTCompoundString(input, options = {}) {
    const errors = [];
    const originalInput = input;
    input = input.trim();
    if (input.startsWith("{")) {
        input = input.slice(1);
    }
    const result = {};
    let depth = 0;
    let currentValuePos = -1;
    let currentKey = "";
    let currentValue = "";
    let inString = null;
    function commitPair() {
        if (!currentKey)
            return;
        result[currentKey.trim()] = parseValue(currentValue.trim(), currentKey, currentValuePos);
        currentKey = "";
        currentValue = "";
        currentValuePos = -1;
    }
    function parseValue(val, key, pos) {
        const originalVal = val;
        val = val.trim();
        if (!val)
            return NBT.comp({});
        if (val.startsWith("{") && val.endsWith("}")) {
            const baseVal = parseSNBTCompoundString(val, { ...options, isInnerStack: true });
            if ("errors" in baseVal) {
                baseVal.errors.forEach((err) => {
                    err.cause.stack.push({
                        input: originalInput,
                        positionInInput: originalInput.indexOf(input) + pos + originalVal.indexOf(val),
                        key,
                        function: "extractSNBT",
                    });
                    err.cause.position += originalInput.indexOf(input) + pos + originalVal.indexOf(val);
                });
                errors.push(...baseVal.errors);
            }
            return "errors" in baseVal ? baseVal.value : baseVal;
        }
        if (val.startsWith("[") && val.endsWith("]")) {
            const baseVal = parseSNBTPrimitive(val, { ...options, isInnerStack: true });
            if ("errors" in baseVal) {
                baseVal.errors.forEach((err) => {
                    err.cause.stack.push({
                        input: originalInput,
                        positionInInput: originalInput.indexOf(input) + pos + originalVal.indexOf(val),
                        key,
                        function: "extractSNBT",
                    });
                    err.cause.position += originalInput.indexOf(input) + pos + originalVal.indexOf(val);
                });
                errors.push(...baseVal.errors);
            }
            return "errors" in baseVal ? baseVal.value : baseVal;
        }
        const baseVal = parseSNBTPrimitive(val, { ...options, isInnerStack: true });
        if ("errors" in baseVal) {
            baseVal.errors.forEach((err) => {
                err.cause.stack.push({
                    input: originalInput,
                    positionInInput: originalInput.indexOf(input) + pos + originalVal.indexOf(val),
                    key,
                    function: "extractSNBT",
                });
                err.cause.position += originalInput.indexOf(input) + pos + originalVal.indexOf(val);
            });
            errors.push(...baseVal.errors);
        }
        return "errors" in baseVal ? baseVal.value : baseVal;
    }
    let readingKey = true;
    for (let i = 0; i < input.length; i++) {
        if (depth < 0)
            break;
        const c = input[i];
        if (c === '"' || c === "'") {
            if (inString === c)
                inString = null;
            else if (!inString)
                inString = c;
        }
        if (!inString) {
            if (c === ":" && readingKey) {
                readingKey = false;
                continue;
            }
            else if (c === "," && depth === 0) {
                commitPair();
                readingKey = true;
                continue;
            }
            else if (c === "{" || c === "[") {
                depth++;
            }
            else if (c === "}" || c === "]") {
                depth--;
                if (depth === -1) {
                    commitPair();
                    readingKey = true;
                    continue;
                }
                if ((options.stopAtNegativeDepth ?? true) && depth < 0) {
                    i++;
                    break;
                }
            }
        }
        if (readingKey)
            currentKey += c;
        else {
            currentValue += c;
            if (currentValuePos === -1 && depth === 0)
                currentValuePos = i;
        }
    }
    commitPair();
    const val = NBT.comp(Object.fromEntries(Object.entries(result)
        .map(([k, v]) => [
        (() => {
            try {
                return parseFormattedKey(k.trim());
            }
            catch {
                const error = new SNBTParseError("Invalid SNBT key: " + k.trim(), {
                    cause: {
                        position: k.indexOf(k.trim()),
                        stack: [
                            {
                                function: "parseSNBTCompoundString",
                                input: k,
                                positionInInput: k.indexOf(k.trim()),
                                key: k.trim(),
                                error: {
                                    type: "InvalidSNBTKey",
                                    raw: k.trim(),
                                },
                            },
                        ],
                    },
                });
                if (options.keepGoingAfterError)
                    errors.push(error);
                else
                    throw error;
                return undefined;
            }
        })(),
        v,
    ])
        .filter((v) => v[0] !== undefined)));
    return options.keepGoingAfterError ? { value: val, errors } : val;
}
export function extractSNBT(input, options = {}) {
    const errors = [];
    const originalInput = input;
    input = input.trim();
    let resultType = "compound";
    if (input.startsWith("{")) {
        input = input.slice(1);
        resultType = "compound";
    }
    else if (input.startsWith("[")) {
        input = input.slice(1);
        resultType = "list";
    }
    const result = {};
    const listResult = [];
    let depth = 0;
    let currentKey = "";
    let currentValue = "";
    let currentValuePos = -1;
    let inString = null;
    function commitPair() {
        if (resultType === "compound") {
            if (!currentKey)
                return;
            result[currentKey.trim()] = parseValue(currentValue.trim(), currentKey, currentValuePos);
            currentKey = "";
            currentValue = "";
            currentValuePos = -1;
        }
        else if (resultType === "list") {
            listResult.push([currentValue.trim(), currentValuePos + currentValue.indexOf(currentValue.trim())]);
            currentValue = "";
            currentValuePos = -1;
        }
    }
    function parseValue(val, key, pos) {
        const originalVal = val;
        val = val.trim();
        if (!val)
            return NBT.comp({});
        if (val.startsWith("{") && val.endsWith("}")) {
            const baseVal = parseSNBTCompoundString(val, { ...options, isInnerStack: true });
            if ("errors" in baseVal) {
                baseVal.errors.forEach((err) => {
                    err.cause.stack.push({
                        input: originalInput,
                        positionInInput: originalInput.indexOf(input) + pos + originalVal.indexOf(val),
                        key,
                        function: "extractSNBT",
                    });
                    err.cause.position += originalInput.indexOf(input) + pos + originalVal.indexOf(val);
                });
                errors.push(...baseVal.errors);
            }
            return "errors" in baseVal ? baseVal.value : baseVal;
        }
        if (val.startsWith("[") && val.endsWith("]")) {
            const baseVal = parseSNBTPrimitive(val, { ...options, isInnerStack: true });
            if ("errors" in baseVal) {
                baseVal.errors.forEach((err) => {
                    err.cause.stack.push({
                        input: originalInput,
                        positionInInput: originalInput.indexOf(input) + pos + originalVal.indexOf(val),
                        key,
                        function: "extractSNBT",
                    });
                    err.cause.position += originalInput.indexOf(input) + pos + originalVal.indexOf(val);
                });
                errors.push(...baseVal.errors);
            }
            return "errors" in baseVal ? baseVal.value : baseVal;
        }
        const baseVal = parseSNBTPrimitive(val, { ...options, isInnerStack: true });
        if ("errors" in baseVal) {
            baseVal.errors.forEach((err) => {
                err.cause.stack.push({
                    input: originalInput,
                    positionInInput: originalInput.indexOf(input) + pos + originalVal.indexOf(val),
                    key,
                    function: "extractSNBT",
                });
                err.cause.position += originalInput.indexOf(input) + pos + originalVal.indexOf(val);
            });
            errors.push(...baseVal.errors);
        }
        return "errors" in baseVal ? baseVal.value : baseVal;
    }
    let readingKey = resultType === "list" ? false : true;
    let bracketTypeStack = [resultType];
    let i = 0;
    for (i; i < input.length; i++) {
        const c = input[i];
        if (c === '"' || c === "'") {
            if (inString === c)
                inString = null;
            else if (!inString)
                inString = c;
        }
        if (!inString) {
            if (c === ":" && readingKey) {
                readingKey = false;
                continue;
            }
            else if (c === "," && depth === 0) {
                if (resultType !== "list" || currentValue.trim() !== "") {
                    commitPair();
                }
                else {
                    currentKey = "";
                    currentValue = "";
                    currentValuePos = -1;
                }
                if (resultType === "compound")
                    readingKey = true;
                continue;
            }
            else if (c === "{" || c === "[") {
                bracketTypeStack.push(c === "{" ? "compound" : "list");
                depth++;
            }
            else if (c === "}" || c === "]") {
                bracketTypeStack.pop();
                depth--;
                if ((options.stopAtNegativeDepth ?? true) && depth < 0) {
                    i++;
                    break;
                }
            }
        }
        if (readingKey)
            currentKey += c;
        else {
            currentValue += c;
            if (currentValuePos === -1 && depth === 0)
                currentValuePos = i;
        }
    }
    if (resultType !== "list" || currentValue.trim() !== "") {
        commitPair();
    }
    else {
        currentKey = "";
        currentValue = "";
        currentValuePos = -1;
    }
    if (resultType === "list") {
        const baseVal = parseList(listResult.map(([v]) => v), { ...options, isInnerStack: true });
        if ("errors" in baseVal) {
            baseVal.errors.forEach((err) => {
                const lastStackItem = err.cause.stack.at(-1);
                // console.log(listResult, lastStackItem, lastStackItem.inputItemIndex, err);
                const baseOffset = listResult[lastStackItem.inputItemIndex][1];
                err.cause.stack.push({
                    input: originalInput,
                    positionInInput: originalInput.indexOf(input) + baseOffset,
                    function: "extractSNBT",
                });
                err.cause.position += originalInput.indexOf(input) + baseOffset;
            });
            errors.push(...baseVal.errors);
        }
        if (!options.isInnerStack) {
            errors.forEach((err) => {
                err.isResolved = true;
                err.originalInput = originalInput;
            });
        }
        return {
            value: "errors" in baseVal ? baseVal.value : baseVal,
            remaining: originalInput.slice(i + originalInput.indexOf(input)),
            startPos: originalInput.indexOf(input),
            endPos: i + originalInput.indexOf(input),
            ...(options.keepGoingAfterError ? { errors } : undefined),
        };
    }
    if (!options.isInnerStack) {
        errors.forEach((err) => {
            err.isResolved = true;
            err.originalInput = originalInput;
        });
    }
    return {
        value: NBT.comp(Object.fromEntries(Object.entries(result)
            .map(([k, v]) => [
            (() => {
                try {
                    return parseFormattedKey(k.trim());
                }
                catch {
                    const error = new SNBTParseError("Invalid SNBT key: " + k.trim(), {
                        cause: {
                            position: k.indexOf(k.trim()),
                            stack: [
                                {
                                    function: "parseSNBTCompoundString",
                                    input: k,
                                    positionInInput: k.indexOf(k.trim()),
                                    key: k.trim(),
                                    error: {
                                        type: "InvalidSNBTKey",
                                        raw: k.trim(),
                                    },
                                },
                            ],
                        },
                    });
                    if (options.keepGoingAfterError)
                        errors.push(error);
                    else
                        throw error;
                    return undefined;
                }
            })(),
            v,
        ])
            .filter((v) => v[0] !== undefined))),
        remaining: originalInput.slice(i + originalInput.indexOf(input)),
        startPos: originalInput.indexOf(input),
        endPos: i + originalInput.indexOf(input),
        ...(options.keepGoingAfterError ? { errors } : undefined),
    };
}
// console.log(
//     parseSNBTCompoundString(`{
//     id: SculkCatalyst,
//     isMovable: 1b,
//     x: -345,
//     y: -40,
//     z: 449
// }`)
// );
// console.log(
//     prismarineToSNBT(
//         parseSNBTCompoundString(`{
//     "id": SculkCatalyst,
//     "isMovable": 1b,
//     "x": -345,
//     "y": -40,
//     "z": 449
// }`)
//     )
// );
// console.log(
//     snbtToPrismarine(
//         prismarineToSNBT(
//             parseSNBTCompoundString(`{
//     "id": SculkCatalyst,
//     "isMovable": 1b,
//     "x": -345,
//     "y": -40,
//     "z": 449
// }`)
//         )
//     )
// );
// console.log(
//     prettyPrintSNBT(
//         prismarineToSNBT(
//             parseSNBTCompoundString(`{
//     "id": SculkCatalyst,
//     "isMovable": 1b,
//     "x": -345,
//     "y": -40,
//     "z": 449
// }`)
//         ),
//         { indent: 4, inlineArrays: false }
//     )
// );
/**
 * Converts SNBT-like JSON into Prismarine-NBT JSON.
 *
 * @param snbt The SNBT-like JSON to convert.
 * @returns The Prismarine-NBT JSON.
 */
export function snbtToPrismarine(snbt) {
    const value = {};
    for (const [key, raw] of Object.entries(snbt)) {
        if (Array.isArray(raw)) {
            if (raw.length > 0 && typeof raw[0] === "object" && !Array.isArray(raw[0])) {
                value[key] = {
                    type: "list",
                    value: {
                        type: "compound",
                        value: raw.map((entry) => {
                            const inner = {};
                            for (const [k, v] of Object.entries(entry)) {
                                inner[k] = snbtToPrismarine({ [k]: v });
                            }
                            return inner;
                        }),
                    },
                };
            }
            else {
                const parsed = raw.map((v) => parseSNBTPrimitive(v));
                const types = new Set(parsed.map((p) => p.type));
                if (types.size === 1) {
                    const type = [...types][0];
                    switch (type) {
                        case "byte":
                            value[key] = NBT.byteArray(parsed.map((p) => p.value));
                            continue;
                        case "short":
                            value[key] = NBT.shortArray(parsed.map((p) => p.value));
                            continue;
                        case "int":
                            value[key] = NBT.intArray(parsed.map((p) => p.value));
                            continue;
                        case "long":
                            value[key] = NBT.longArray(parsed.map((p) => p.value));
                            continue;
                    }
                }
                value[key] = {
                    type: "list",
                    value: {
                        type: parsed[0]?.type ?? "int",
                        value: parsed.map((p) => p.value),
                    },
                };
            }
        }
        else if (typeof raw === "object" && raw !== null) {
            if ("__typed" in raw && "value" in raw) {
                value[key] = parseTypedArray(raw.__typed, raw.value.map((v) => (typeof v === "string" ? v : String(v))));
            }
            else {
                value[key] = snbtToPrismarine(raw);
            }
        }
        else {
            value[key] = parseSNBTPrimitive(raw);
        }
    }
    return NBT.comp(value);
}
function formatString(s) {
    const unquotedPattern = /^[A-Za-z_][A-Za-z0-9_\-+.]*$/;
    if (unquotedPattern.test(s))
        return s;
    let quote = '"';
    if (!s.includes("'") && s.includes('"')) {
        quote = "'";
    }
    const escaped = s
        .replace(/\\/g, "\\\\")
        .replace(new RegExp(quote, "g"), "\\" + quote)
        .replace(/\n/g, "\\n")
        .replace(/\r/g, "\\r")
        .replace(/\t/g, "\\t")
        .replace(/\x08/g, "\\b")
        .replace(/\f/g, "\\f")
        .replaceAll(/([\0-\x1f\u2028\u2029\ud800-\udfff])/g, (string) => {
        return `\\u${string.codePointAt(0).toString(16).padStart(4, "0")}`;
    });
    return `${quote}${escaped}${quote}`;
}
function formatKey(key) {
    const unquotedPattern = /^[A-Za-z0-9_\-+.]+$/;
    if (unquotedPattern.test(key))
        return key;
    return formatString(key);
}
function parseFormattedString(string) {
    return (string.startsWith('"') && string.endsWith('"') ? JSON.parse(string)
        : string.startsWith("'") && string.endsWith("'") ? JSON.parse('"' + string.replaceAll('"', '\\"').slice(1, -1) + '"')
            : /^[A-Za-z_][A-Za-z0-9_\-+.]*$/.test(string) ? string
                : (() => {
                    throw new SyntaxError("Invalid SNBT string: " + string);
                })());
}
function parseFormattedKey(key) {
    return (/^[A-Za-z0-9_\-+.]+$/.test(key) ? key
        : key.startsWith('"') && key.endsWith('"') ? JSON.parse(key)
            : key.startsWith("'") && key.endsWith("'") ? JSON.parse('"' + key.replaceAll('"', '\\"').slice(1, -1) + '"')
                : /^[A-Za-z_][A-Za-z0-9_\-+.]*$/.test(key) ? key
                    : (() => {
                        throw new SyntaxError("Invalid SNBT key: " + key);
                    })());
}
/**
 * The tag types of SNBT-like JSON.
 */
export var SNBTLikeJSONTagType;
(function (SNBTLikeJSONTagType) {
    /**
     * A byte.
     */
    SNBTLikeJSONTagType["Byte"] = "byte";
    /**
     * A short.
     */
    SNBTLikeJSONTagType["Short"] = "short";
    /**
     * An integer.
     */
    SNBTLikeJSONTagType["Int"] = "int";
    /**
     * A long.
     */
    SNBTLikeJSONTagType["Long"] = "long";
    /**
     * A float.
     */
    SNBTLikeJSONTagType["Float"] = "float";
    /**
     * A double.
     */
    SNBTLikeJSONTagType["Double"] = "double";
    /**
     * A string.
     */
    SNBTLikeJSONTagType["String"] = "string";
    /**
     * A list.
     */
    SNBTLikeJSONTagType["List"] = "list";
    /**
     * A compound.
     */
    SNBTLikeJSONTagType["Compound"] = "compound";
    /**
     * An array of bytes.
     */
    SNBTLikeJSONTagType["ByteArray"] = "byteArray";
    /**
     * An array of shorts.
     */
    SNBTLikeJSONTagType["ShortArray"] = "shortArray";
    /**
     * An array of integers.
     */
    SNBTLikeJSONTagType["IntArray"] = "intArray";
    /**
     * An array of longs.
     */
    SNBTLikeJSONTagType["LongArray"] = "longArray";
})(SNBTLikeJSONTagType || (SNBTLikeJSONTagType = {}));
/**
 * Converts Prismarine-NBT JSON to SNBT-like JSON.
 *
 * @param nbt The Prismarine-NBT JSON to convert.
 * @returns The resulting SNBT-like JSON.
 */
export function prismarineToSNBT(nbt) {
    if (nbt.type === "compound") {
        const obj = {};
        for (const [key, val] of Object.entries(nbt.value)) {
            obj[key] = prismarineToSNBT(val);
        }
        return obj;
    }
    if (nbt.type === "list") {
        if (nbt.value.type === "compound") {
            return nbt.value.value.map((entry) => {
                const obj = {};
                for (const [k, v] of Object.entries(entry)) {
                    obj[k] = prismarineToSNBT(v);
                }
                return obj;
            });
        }
        else {
            return nbt.value.value.map((v) => prismarineToSNBT({ type: nbt.value.type, value: v }));
        }
    }
    switch (nbt.type) {
        case "byteArray":
            return { __typed: "B", value: nbt.value.map((v) => `${v}b`) };
        case "shortArray":
            return { __typed: "S", value: nbt.value.map((v) => `${v}s`) };
        case "intArray":
            return { __typed: "I", value: nbt.value.map((v) => `${v}`) };
        case "longArray":
            return { __typed: "L", value: nbt.value.map((v) => `${toLong(v)}L`) };
    }
    switch (nbt.type) {
        case "byte":
            return `${nbt.value}b`;
        case "short":
            return `${nbt.value}s`;
        case "int":
            return nbt.value;
        case "long":
            return `${toLong(nbt.value).toString()}L`;
        case "float":
            return `${nbt.value}f`;
        case "double":
            return `${nbt.value}d`;
        case "string":
            return formatString(nbt.value);
    }
    return nbt.value;
}
/**
 * Converts a long in bigint format to tuple form of two signed 32-bit integers.
 *
 * @param longVal The long as a bigint.
 * @returns The long as a tuple.
 */
export function toLongParts(longVal) {
    const low = Number(longVal & 0xffffffffn) | 0;
    const high = Number((longVal >> 32n) & 0xffffffffn) | 0;
    return [high, low];
}
/**
 * Converts a long as a string to a tuple of two signed 32-bit integers.
 *
 * The string would be formatted like `"0n"`.
 *
 * @param literal A long as a string.
 * @returns The long as a tuple.
 */
export function parseLong(literal) {
    const numStr = literal.slice(0, -1);
    const value = BigInt(numStr);
    return toLongParts(value);
}
/**
 * Converts a long in tuple form (two signed 32-bit integers) to bigint form.
 *
 * @param param0 The long as a tuple.
 * @returns The long as a bigint.
 */
export function toLong([high, low]) {
    const lo = BigInt(low) & 0xffffffffn;
    const hi = BigInt(high);
    return (hi << 32n) | lo;
}
/**
 * Pretty-prints SNBT.
 *
 * @param obj The SNBT-like JSON to pretty-print.
 * @param options The options to use.
 * @returns The pretty-printed SNBT.
 *
 * @example
 * ```typescript
 * prettyPrintSNBT(prismarineToSNBT({
 *     type: "compound",
 *     value: {
 *         enabled: {
 *             type: "byte",
 *             value: 1
 *         }
 *     }
 * }))
 * ```
 */
export function prettyPrintSNBT(obj, options = {}) {
    const { indent = 2, inlineArrays = true, maxInlineLength = 40 } = options;
    const nl = options.indent === 0 ? "" : "\n";
    function format(value, level) {
        const pad = " ".repeat(level * indent);
        if (value && typeof value === "object" && value.__typed) {
            const type = value.__typed;
            const inner = value.value.join(", ");
            return `[${type}; ${inner}]`;
        }
        if (Array.isArray(value)) {
            if (value.length === 0)
                return "[]";
            const inline = `[${value.map((v) => format(v, 0)).join(", ")}]`;
            if (inlineArrays && inline.length <= maxInlineLength && !value.some((v) => typeof v === "object")) {
                return inline;
            }
            return "[" + nl + value.map((v) => pad + " ".repeat(indent) + format(v, level + 1)).join("," + nl) + nl + pad + "]";
        }
        if (typeof value === "object" && value !== null) {
            const entries = Object.entries(value);
            if (entries.length === 0)
                return "{}";
            return ("{" +
                nl +
                entries.map(([k, v]) => pad + " ".repeat(indent) + `${formatKey(k)}: ${format(v, level + 1)}`).join("," + nl) +
                nl +
                pad +
                "}");
        }
        return String(value);
    }
    return format(obj, 0);
}
//# sourceMappingURL=SNBTUtils.js.map