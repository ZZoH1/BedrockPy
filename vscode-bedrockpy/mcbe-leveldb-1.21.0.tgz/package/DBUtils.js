import { getContentTypeFromDBKey } from "./LevelUtils.js";
import NBT from "prismarine-nbt";
import { JSONB } from "./utils/JSONB.js";
export function getKeysOfType(dbOrDBKeys, type) {
    if (Array.isArray(dbOrDBKeys))
        return dbOrDBKeys.filter((key) => getContentTypeFromDBKey(key) === type);
    return new Promise((resolve) => void (async () => {
        const foundKeys = [];
        for await (const [rawKey, _value] of dbOrDBKeys.getIterator({ keys: true, keyAsBuffer: true, values: false })) {
            if (getContentTypeFromDBKey(rawKey) === type)
                foundKeys.push(rawKey);
        }
        resolve(foundKeys);
    })());
}
export function getKeysOfTypes(dbOrDBKeys, types) {
    const results = {};
    types.forEach((contentType) => {
        results[contentType] = [];
    });
    if (Array.isArray(dbOrDBKeys)) {
        for (const key of dbOrDBKeys) {
            const contentType = getContentTypeFromDBKey(key);
            if (types.includes(contentType))
                results[contentType].push(key);
        }
        return results;
    }
    return new Promise((resolve) => void (async () => {
        for await (const [rawKey, _value] of dbOrDBKeys.getIterator({ keys: true, keyAsBuffer: true, values: false })) {
            const contentType = getContentTypeFromDBKey(rawKey);
            if (types.includes(contentType))
                results[contentType].push(rawKey);
        }
        resolve(results);
    })());
}
export function getKeysOfTypesG(dbOrDBKeys, types) {
    const results = {};
    var count = 0;
    types.forEach((contentType) => {
        results[contentType] = [];
    });
    if (Array.isArray(dbOrDBKeys)) {
        return (function* getKeysOfTypesGInner() {
            for (const key of dbOrDBKeys) {
                const contentType = getContentTypeFromDBKey(key);
                if (types.includes(contentType)) {
                    results[contentType].push(key);
                    count++;
                }
                yield { count, results };
            }
            return results;
        })();
    }
    return (async function* getKeysOfTypesGInner() {
        for await (const [rawKey, _value] of dbOrDBKeys.getIterator({ keys: true, keyAsBuffer: true, values: false })) {
            const contentType = getContentTypeFromDBKey(rawKey);
            if (types.includes(contentType)) {
                results[contentType].push(rawKey);
                count++;
            }
            yield { count, results };
        }
        return results;
    })();
}
/**
 * Gets a player's name from their UUID.
 *
 * Only works if the player's name was stored in an add-on's dynamic properties with their ID linked to it, and it only works for a hardcoded list of add-ons,
 * if you have your own add-on that you would like this to be able to read the player's names from, {@link https://www.8crafter.com/main/contact | contact 8Crafter},
 * or make a pull request.
 *
 * @param db The LevelDB. Should match the type of the {@link LevelDB} class from the {@link https://www.npmjs.com/package/@8crafter/leveldb-zlib | @8crafter/leveldb-zlib} package. It does not have to be the one from that package, as long as the types match.
 * @param uuid The UUID of the play to get the name of.
 * @returns The name of the player, or `null` if the player's name cannot be found or the world has no dynamic properties.
 *
 * @throws {any} If there was an error reading the DynamicProperties from the DB.
 */
export async function getPlayerNameFromUUID(db, uuid) {
    const dynamicProperties = await db
        .get("DynamicProperties")
        .then((data) => data ? NBT.parse(data).then((data) => data.parsed) : null);
    if (!dynamicProperties)
        return null;
    return getPlayerNameFromUUIDSync(dynamicProperties, uuid);
}
/**
 * Gets a player's name from their UUID using the provided dynamic properties data.
 *
 * Only works if the player's name was stored in an add-on's dynamic properties with their ID linked to it, and it only works for a hardcoded list of add-ons,
 * if you have your own add-on that you would like this to be able to read the player's names from, {@link https://www.8crafter.com/main/contact | contact 8Crafter},
 * or make a pull request.
 *
 * @param dynamicProperties The dynamic properties data, should be the data from the `DynamicProperties` LevelDB key.
 * @param uuid The UUID of the play to get the name of.
 * @returns The name of the player, or `null` if the player's name cannot be found .
 */
export function getPlayerNameFromUUIDSync(dynamicProperties, uuid) {
    const UUIDString = uuid.toString();
    for (const parser of playerUUIDToNameDynamicPropertyParsers) {
        const name = parser(dynamicProperties, UUIDString);
        if (name !== null)
            return name;
    }
    return null;
}
/**
 * The list of functions that can be used to get a player's name from their UUID from the dynamic properties.
 *
 * These will be called in order until one of them returns a non-null value.
 */
export const playerUUIDToNameDynamicPropertyParsers = [
    function parseBWEPlayerNameSaver(dynamicProperties, uuid) {
        const addOnUUIDs = ["9736e748-93a5-4306-ba68-ac6af30c44b2"];
        for (const addOnUUID of addOnUUIDs) {
            const addonDynamicProperties = dynamicProperties.value[addOnUUID]?.type === "compound" ? dynamicProperties.value[addOnUUID].value : null;
            if (!addonDynamicProperties)
                continue;
            for (const key in addonDynamicProperties) {
                if (key !== `playerName:${uuid}`)
                    continue;
                const dynamicPropertyValue = addonDynamicProperties[key];
                if (dynamicPropertyValue.type !== "string")
                    continue;
                return dynamicPropertyValue.value;
            }
        }
        return null;
    },
    function parse8CraftersServerUtilities(dynamicProperties, uuid) {
        const addOnUUIDs = [
            // Internal development version
            "53170125-3e79-4659-9bba-e49eb90b6ded",
            // Release version
            "53170125-3e79-4659-9bba-e49eb90b6dea",
        ];
        for (const addOnUUID of addOnUUIDs) {
            const addonDynamicProperties = dynamicProperties.value[addOnUUID]?.type === "compound" ? dynamicProperties.value[addOnUUID].value : null;
            if (!addonDynamicProperties)
                continue;
            for (const key in addonDynamicProperties) {
                if (key !== `player:${uuid}`)
                    continue;
                const dynamicPropertyValue = addonDynamicProperties[key];
                if (dynamicPropertyValue.type !== "string")
                    continue;
                try {
                    const data = JSONB.parse(dynamicPropertyValue.value);
                    if (typeof data === "object" && data !== null && typeof data.name === "string")
                        return data.name;
                }
                catch (e) {
                    continue;
                }
            }
        }
        return null;
    },
];
//# sourceMappingURL=DBUtils.js.map