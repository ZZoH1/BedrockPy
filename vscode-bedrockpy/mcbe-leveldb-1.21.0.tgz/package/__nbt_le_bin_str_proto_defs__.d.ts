/**
 * The protodef definitions for NBT LE with binary string encoding.
 *
 * @internal
 */
export declare const __NBT_LE_binary_string_encoding_proto_defs__: {
    readonly void: "native";
    readonly container: "native";
    readonly i8: "native";
    readonly switch: "native";
    readonly compound: "native";
    readonly nbtTagName: "native";
    readonly li16: "native";
    readonly lu16: "native";
    readonly li32: "native";
    readonly li64: "native";
    readonly lf32: "native";
    readonly lf64: "native";
    readonly pstring: "native";
    readonly shortString: readonly ["pstring", {
        readonly countType: "lu16";
    }];
    readonly shortStringBinary: readonly ["pstring", {
        readonly countType: "lu16";
        readonly encoding: "binary";
    }];
    readonly byteArray: readonly ["array", {
        readonly countType: "li32";
        readonly type: "i8";
    }];
    readonly list: readonly ["container", readonly [{
        readonly name: "type";
        readonly type: "nbtMapper";
    }, {
        readonly name: "value";
        readonly type: readonly ["array", {
            readonly countType: "li32";
            readonly type: readonly ["nbtSwitch", {
                readonly type: "type";
            }];
        }];
    }]];
    readonly intArray: readonly ["array", {
        readonly countType: "li32";
        readonly type: "li32";
    }];
    readonly longArray: readonly ["array", {
        readonly countType: "li32";
        readonly type: "li64";
    }];
    readonly nbtMapper: readonly ["mapper", {
        readonly type: "i8";
        readonly mappings: {
            readonly "0": "end";
            readonly "1": "byte";
            readonly "2": "short";
            readonly "3": "int";
            readonly "4": "long";
            readonly "5": "float";
            readonly "6": "double";
            readonly "7": "byteArray";
            readonly "8": "string";
            readonly "9": "list";
            readonly "10": "compound";
            readonly "11": "intArray";
            readonly "12": "longArray";
        };
    }];
    readonly nbtSwitch: readonly ["switch", {
        readonly compareTo: "$type";
        readonly fields: {
            readonly end: "void";
            readonly byte: "i8";
            readonly short: "li16";
            readonly int: "li32";
            readonly long: "li64";
            readonly float: "lf32";
            readonly double: "lf64";
            readonly byteArray: "byteArray";
            readonly string: "shortStringBinary";
            readonly list: "list";
            readonly compound: "compound";
            readonly intArray: "intArray";
            readonly longArray: "longArray";
        };
    }];
    readonly nbt: readonly ["container", readonly [{
        readonly name: "type";
        readonly type: "nbtMapper";
    }, {
        readonly name: "name";
        readonly type: "nbtTagName";
    }, {
        readonly name: "value";
        readonly type: readonly ["nbtSwitch", {
            readonly type: "type";
        }];
    }]];
    readonly anonymousNbt: readonly ["container", readonly [{
        readonly name: "type";
        readonly type: "nbtMapper";
    }, {
        readonly name: "value";
        readonly type: readonly ["nbtSwitch", {
            readonly type: "type";
        }];
    }]];
    readonly anonOptionalNbt: readonly ["optionalNbtType", {
        readonly tagType: "anonymousNbt";
    }];
    readonly optionalNbt: readonly ["optionalNbtType", {
        readonly tagType: "nbt";
    }];
};
