import { dimensions } from "./LevelUtils.js";
import * as NBT from "prismarine-nbt";
import { toLongParts } from "./SNBTUtils.js";
import __biome_data__ from "./__biome_data__.js";
/**
 * Types, constants, and functions related to NBT schemas.
 */
export var NBTSchemas;
(function (NBTSchemas) {
    /**
     * Used for the {@link nbtSchemas} constant to define NBT schema aliases.
     *
     * @param schemas The NBT schemas.
     * @param mappings The alias mappings.
     * @returns The schemas with the aliases added.
     *
     * @internal
     */
    function defineNBTSchemasMapping(schemas, mappings) {
        return {
            ...schemas,
            ...Object.fromEntries(Object.entries(mappings).map(([k, v]) => [
                k,
                {
                    ...schemas[v.key],
                    id: k,
                    markdownDescription: "markdownDescription" in v && v.markdownDescription ? v.markdownDescription : schemas[v.key].markdownDescription,
                    $aliasOf: v.key,
                },
            ])),
        };
    }
    /**
     * The NBT schemas.
     *
     * Note:
     * - A description of `UNDOCUMENTED.` means the tag with that description has not been documented yet or it is unknown what it does.
     * - A description of `UNKNOWN.` means that the schema for that tag is incomplete or completely empty as it is unknown what properties it has.
     *
     * @caution Many of these NBT schemas were auto-generated from the Minecraft wiki and have not been verified to be correct, many issues have been found with these schemas, so please verify the accuracy of these schemas. Fully verified NBT schemas will have a "NOTE: Verified." line comment above their definition in the code.
     */
    NBTSchemas.nbtSchemas = defineNBTSchemasMapping({
        //#region Top-Level Schemas
        // NOTE: Verified.
        // FIXME: This is used for the Entity content type event though the entities in that type do not include the internalComponents property.
        ActorPrefix: {
            id: "ActorPrefix",
            title: "The ActorPrefix schema.",
            markdownDescription: "All entities share this base.",
            type: "compound",
            required: [
                "Chested",
                "Color",
                "Color2",
                "FallDistance",
                "identifier",
                "internalComponents",
                "Invulnerable",
                "IsAngry",
                "IsAutonomous",
                "IsBaby",
                "IsEating",
                "IsGliding",
                "IsGlobal",
                "IsIllagerCaptain",
                "IsOrphaned",
                "IsOutOfControl",
                "IsRoaring",
                "IsScared",
                "IsStunned",
                "IsSwimming",
                "IsTamed",
                "IsTrusting",
                "LootDropped",
                "MarkVariant",
                "OnGround",
                "OwnerNew",
                "PortalCooldown",
                "Pos",
                "Rotation",
                "Saddled",
                "Sheared",
                "ShowBottom",
                "Sitting",
                "SkinID",
                "Strength",
                "StrengthMax",
                "UniqueID",
                "Variant",
            ],
            properties: {
                Chested: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity is chested. Used by donkey, llama, and mule.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                Color: {
                    markdownDescription: "The main color value of the entity. Used by sheep, llama, shulker, tropical fish, etc. Defaults to 0.",
                    type: "byte",
                    default: {
                        type: "byte",
                        value: 0,
                    },
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                Color2: {
                    markdownDescription: "The entity's second color value. Used by tropical fish. Defaults to 0.",
                    type: "byte",
                    default: {
                        type: "byte",
                        value: 0,
                    },
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                // REVIEW: Check if this property actually ever exists.
                CustomName: {
                    markdownDescription: "(May not exist) The custom name of this entity.",
                    type: "string",
                },
                // REVIEW: Check if this property actually ever exists.
                CustomNameVisible: {
                    markdownDescription: "1 or 0 (true/false) - (may not exist) if true, and this entity has a custom name, the name always appears above the entity, regardless of where the cursor points. If the entity does not have a custom name, a default name is shown.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                definitions: {
                    markdownDescription: "(May not exist) The namespaced ID of this entity and its current and previous component groups.",
                    type: "list",
                    items: {
                        markdownDescription: "UNDOCUMENTED.",
                        type: "string",
                    },
                },
                FallDistance: {
                    markdownDescription: "Distance the entity has fallen. Larger values cause more damage when the entity lands.",
                    type: "float",
                },
                // REVIEW: Check if this property actually ever exists.
                Fire: {
                    markdownDescription: "Number of ticks until the fire is put out. Default 0 when not on fire.",
                    type: "short",
                },
                identifier: {
                    markdownDescription: "The namespaced ID of this entity.",
                    type: "string",
                },
                internalComponents: {
                    markdownDescription: "Internal components containing critical storage information for the entity.",
                    type: "compound",
                    required: ["EntityStorageKeyComponent"],
                    properties: {
                        EntityStorageKeyComponent: {
                            markdownDescription: "A component containing the StorageKey. The StorageKey is a binary-encoded string containing the ID that is used in the ActorPrefix's LevelDB key and in the entity IDs list of Digest LevelDB entries.",
                            type: "compound",
                            required: ["StorageKey"],
                            properties: {
                                StorageKey: {
                                    markdownDescription: "The ID that is used in the ActorPrefix's LevelDB key and in the entity IDs list of Digest LevelDB entries. If this is changed, the game will write this ActorPrefix to a different LevelDB key that corresponds to the value here, the game will **not** automatically update the Digest LevelDB entries to reflect this.",
                                    type: "string",
                                },
                            },
                        },
                    },
                },
                Invulnerable: {
                    markdownDescription: "1 or 0 (true/false) - true if the entity should not take damage. This applies to living and nonliving entities alike: mobs should not take damage from any source (including potion effects), and cannot be moved by fishing rods, attacks, explosions, or projectiles, and objects such as vehicles cannot be destroyed. Invulnerable player entities are also ignored by any hostile mobs. Note that these entities can be damaged by players in Creative mode. *needs testing*",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                IsAngry: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity is angry. Used by wolf and bee.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                IsAutonomous: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity is an autonomous entity.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                IsBaby: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity is a baby.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                IsEating: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity is eating.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                IsGliding: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity is gliding.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                IsGlobal: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity is a global entity (e.g. lightning bolt, ender dragon, arrow).",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                IsIllagerCaptain: {
                    markdownDescription: "1 or 0 (true/false) - true if the entity is an illager captain. Used by pillager and vindicator.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                IsOrphaned: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity is not spawn from its parents. Used by all the mobs that can breed.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                IsOutOfControl: {
                    markdownDescription: "1 or 0 (true/false) - true if the entity is out of control. Used by boat.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                IsRoaring: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity is roaring. Used by ravager.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                IsScared: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity is scared.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                IsStunned: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity is stunned. Used by ravager.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                IsSwimming: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity is swimming.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                IsTamed: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity is tamed.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                IsTrusting: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity is trusting a player. Used by fox and ocelot.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                LastDimensionId: {
                    markdownDescription: "(May not exist) UNDOCUMENTED.",
                    type: "int",
                },
                LinksTag: {
                    markdownDescription: "(May not exist) UNDOCUMENTED.",
                    type: "compound",
                    required: ["entityID", "LinkID"],
                    properties: {
                        entityID: {
                            markdownDescription: "The Unique ID of an entity.",
                            type: "long",
                        },
                        LinkID: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "int",
                        },
                    },
                },
                LootDropped: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity can drop [loot](https://minecraft.wiki/w/Drops#Mob_drops) when died.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                MarkVariant: {
                    markdownDescription: "The ID of the mark variant. Used by villager, horse, bee etc. Defaults to 0.",
                    type: "int",
                    default: {
                        type: "int",
                        value: 0,
                    },
                },
                Motion: {
                    markdownDescription: "(May not exist) Three TAG_Floats describing the current dX, dY and dZ velocity of the entity in meters per tick.",
                    type: "list",
                    items: [
                        {
                            markdownDescription: "dX",
                            type: "float",
                        },
                        {
                            markdownDescription: "dY",
                            type: "float",
                        },
                        {
                            markdownDescription: "dZ",
                            type: "float",
                        },
                    ],
                },
                OnGround: {
                    markdownDescription: "1 or 0 (true/false) - true if the entity is touching the ground.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                OwnerNew: {
                    markdownDescription: "UNDOCUMENTED. Defaults to -1.",
                    type: "long",
                    default: {
                        type: "long",
                        value: -1n,
                    },
                },
                Persistent: {
                    markdownDescription: "1 or 0 (true/false) - true if an entity should be [persistent](https://minecraft.wiki/w/Mob_spawning#Despawning) in the world.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                PortalCooldown: {
                    markdownDescription: "The number of ticks before which the entity may be teleported back through a nether portal. Initially starts at 300 ticks (15 seconds) after teleportation and counts down to 0.",
                    type: "int",
                },
                Pos: {
                    markdownDescription: "Three TAG_Floats describing the current X, Y and Z position of the entity.",
                    type: "list",
                    items: [
                        {
                            markdownDescription: "X",
                            type: "float",
                        },
                        {
                            markdownDescription: "Y",
                            type: "float",
                        },
                        {
                            markdownDescription: "Z",
                            type: "float",
                        },
                    ],
                },
                Rotation: {
                    markdownDescription: "Two TAG_Floats representing rotation in degrees.",
                    type: "list",
                    items: [
                        {
                            markdownDescription: "The entity's rotation clockwise around the Y axis (called yaw). Due south is 0. Does not exceed 360 degrees.",
                            type: "float",
                        },
                        {
                            markdownDescription: "The entity's declination from the horizon (called pitch). Horizontal is 0. Positive values look downward. Does not exceed positive or negative 90 degrees.",
                            type: "float",
                        },
                    ],
                },
                Saddled: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity is saddled.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                Sheared: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity is sheared. Used by sheep and snow golem.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                ShowBottom: {
                    markdownDescription: "1 or 0 (true/false) - true if the End Crystal shows the bedrock slate underneath. *needs testing*",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                Sitting: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity is sitting.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                SkinID: {
                    markdownDescription: "The entity's Skin ID value. Used by villager and zombified villager. Defaults to 0.",
                    type: "int",
                    default: {
                        type: "int",
                        value: 0,
                    },
                },
                Strength: {
                    markdownDescription: "Determines the number of items the entity can carry (items = 3 × strength). Used by llama. Defaults to 0.",
                    type: "int",
                    default: {
                        type: "int",
                        value: 0,
                    },
                },
                StrengthMax: {
                    markdownDescription: "Determines the maximum number of items the entity can carry (items = 3 × strength). Defaults to 0.",
                    type: "int",
                    default: {
                        type: "int",
                        value: 0,
                    },
                },
                Tags: {
                    markdownDescription: "(May not exist) List of [scoreboard tags](https://minecraft.wiki/w/Scoreboard) of this entity.",
                    type: "list",
                    items: {
                        markdownDescription: "A tag.",
                        type: "string",
                    },
                },
                UniqueID: {
                    markdownDescription: "The Unique ID of this entity.",
                    type: "long",
                },
                Variant: {
                    markdownDescription: "The ID of the variant. Used by cat, villager, horse, etc. Defaults to 0.",
                    type: "int",
                    default: {
                        type: "int",
                        value: 0,
                    },
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        AutonomousEntities: {
            id: "AutonomousEntities",
            title: "The AutonomousEntities schema.",
            markdownDescription: "The autonomous entities data.",
            type: "compound",
            required: ["AutonomousEntityList"],
            properties: {
                AutonomousEntityList: {
                    markdownDescription: "UNKNOWN.",
                    type: "list",
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        BiomeData: {
            id: "BiomeData",
            title: "The BiomeData schema.",
            markdownDescription: "The [biome](https://minecraft.wiki/w/biome) data.",
            type: "compound",
            required: ["list"],
            properties: {
                list: {
                    markdownDescription: "A list of compound tags representing biomes.",
                    type: "list",
                    items: {
                        markdownDescription: "A biome.",
                        type: "compound",
                        required: ["id", "snowAccumulation"],
                        properties: {
                            id: {
                                markdownDescription: "The numerical [biome ID](https://minecraft.wiki/w/Biome).",
                                type: "short",
                            },
                            snowAccumulation: {
                                markdownDescription: "The biome's snow accumulation. Eg. `0.125`.",
                                type: "float",
                            },
                        },
                    },
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        BiomeIdsTable: {
            id: "BiomeIdsTable",
            title: "The BiomeIdsTable schema.",
            markdownDescription: "Biome numeric ID mappings for custom biomes.",
            type: "compound",
            required: ["list"],
            properties: {
                list: {
                    markdownDescription: "A list of compound tags representing custom biome types.",
                    type: "list",
                    items: {
                        markdownDescription: "A custom biome type.",
                        type: "compound",
                        required: ["id", "name"],
                        properties: {
                            id: {
                                markdownDescription: "The numerical [biome ID](https://minecraft.wiki/w/Biome) for this custom biome. Starts at 30,000.",
                                type: "short",
                                minimum: 30_000,
                            },
                            name: {
                                markdownDescription: "The custom biome's namespaced ID.",
                                type: "string",
                            },
                        },
                    },
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        BlockEntity: {
            id: "BlockEntity",
            title: "The BlockEntity schema.",
            markdownDescription: "All block entities share this base.",
            type: "compound",
            required: ["id", "isMovable", "x", "y", "z"],
            properties: {
                CustomName: {
                    markdownDescription: "(May not exist) The custom name of the block entity.",
                    type: "string",
                },
                id: {
                    markdownDescription: "The savegame ID of the block entity.",
                    type: "string",
                },
                isMovable: {
                    markdownDescription: "1 or 0 (true/false) - true if the block entity is movable with a piston.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                x: {
                    markdownDescription: "X coordinate of the block entity.",
                    type: "int",
                },
                y: {
                    markdownDescription: "Y coordinate of the block entity.",
                    type: "int",
                },
                z: {
                    markdownDescription: "Z coordinate of the block entity.",
                    type: "int",
                },
            },
        },
        // NOTE: Verified.
        ChunkLoadedRequest: {
            id: "ChunkLoadedRequest",
            title: "The ChunkLoadedRequest schema.",
            markdownDescription: "UNDOCUMENTED.",
            type: "compound",
            properties: {
                ActionType: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "byte", value: 2 }],
                },
                AllowNonTickingChunks: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                AnimatePlacement: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                AnimationMode: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "byte", value: 0 }],
                },
                AnimationSeconds: {
                    type: "float",
                    markdownDescription: "UNDOCUMENTED.",
                },
                AreaType: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "byte", value: 0 }],
                },
                BlocksPlaced: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "int", value: 0 }],
                },
                ChunkRequestListType: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "byte", value: 1 }],
                },
                IncludeBlocks: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                IncludeEntities: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                Integrity: {
                    type: "float",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "float", value: 100 }],
                },
                IntegritySeed: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "int", value: 0 }],
                },
                MaxX: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "int", value: -1 }],
                },
                MaxZ: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "int", value: -1 }],
                },
                MinX: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "int", value: -2 }],
                },
                MinZ: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "int", value: -2 }],
                },
                Mirror: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "byte", value: 0 }],
                },
                Name: {
                    type: "string",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "string", value: "mystructure:Tree1" }],
                },
                OffsetX: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "int", value: 0 }],
                },
                OffsetY: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "int", value: 0 }],
                },
                OffsetZ: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "int", value: 0 }],
                },
                PosX: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "int", value: -20 }],
                },
                PosY: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "int", value: -1 }],
                },
                PosZ: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "int", value: -22 }],
                },
                Rotation: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "byte", value: 0 }],
                },
                SizeX: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "int", value: 8 }],
                },
                SizeY: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "int", value: 100 }],
                },
                SizeZ: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "int", value: 7 }],
                },
                TickQueued: {
                    type: "long",
                    markdownDescription: "UNDOCUMENTED.",
                    examples: [{ type: "long", value: [0, 0] }],
                },
            },
        },
        // NOTE: Verified.
        DimensionNameIdTable: {
            id: "DimensionNameIdTable",
            title: "The DimensionNameIdTable schema.",
            markdownDescription: "Dimension numeric ID mappings for custom dimensions.",
            type: "compound",
            required: ["entries"],
            properties: {
                entries: {
                    title: "Entries",
                    markdownDescription: "A mapping of custom dimension namespaced IDs to numeric IDs, starting at 1,000.",
                    type: "compound",
                    patternProperties: {
                        "^[\\u0001-\\u0008\\u000b-\\u000c\\u000e-\\u001f\\u0021-\\u0039\\u003b-\\uffff]+:[\\u0001-\\u0008\\u000b-\\u000c\\u000e-\\u001f\\u0021-\\u0039\\u003b-\\uffff]+$": {
                            title: "Custom Dimension",
                            markdownDescription: "The numerical [dimension ID](https://minecraft.wiki/w/Dimension) for this custom dimension. Starts at 1,000.",
                            type: "int",
                            minimum: 1_000,
                        },
                    },
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        Overworld: {
            id: "Overworld",
            title: "The Overworld schema.",
            markdownDescription: "The data of the overworld dimension, seems to currently just include the LimboEntities data.",
            type: "compound",
            properties: {},
            $ref: "LimboEntities",
        },
        // NOTE: Verified.
        Nether: {
            id: "Nether",
            title: "The Nether schema.",
            markdownDescription: "The data of the nether dimension, seems to currently just include the LimboEntities data.",
            type: "compound",
            properties: {},
            $ref: "LimboEntities",
        },
        // NOTE: Verified.
        TheEnd: {
            id: "TheEnd",
            title: "The TheEnd schema.",
            markdownDescription: "The data of the end dimension.",
            type: "compound",
            required: ["data"],
            properties: {
                data: {
                    title: "Data",
                    markdownDescription: "The data of the end dimension.",
                    type: "compound",
                    properties: {
                        DragonFight: {
                            title: "Dragon Fight",
                            markdownDescription: "UNDOCUMENTED.",
                            type: "compound",
                            // REVIEW: Figure out if these properties are actually required.
                            properties: {
                                DragonKilled: {
                                    title: "Dragon Killed",
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "byte",
                                    markdownEnumDescriptions: ["false", "true"],
                                    enum: [
                                        { type: "byte", value: 0 },
                                        { type: "byte", value: 1 },
                                    ],
                                },
                                DragonSpawned: {
                                    title: "Dragon Spawned",
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "byte",
                                    markdownEnumDescriptions: ["false", "true"],
                                    enum: [
                                        { type: "byte", value: 0 },
                                        { type: "byte", value: 1 },
                                    ],
                                },
                                DragonUUID: {
                                    title: "Dragon UUID",
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "long",
                                },
                                ExitPortalLocation: {
                                    title: "Exit Portal Location",
                                    markdownDescription: "UNDOCUMENTED. A Vector3.",
                                    type: "list",
                                    items: [
                                        {
                                            title: "x",
                                            markdownDescription: "X component of this vector.",
                                            type: "int",
                                        },
                                        {
                                            title: "y",
                                            markdownDescription: "Y component of this vector.",
                                            type: "int",
                                        },
                                        {
                                            title: "z",
                                            markdownDescription: "Z component of this vector.",
                                            type: "int",
                                        },
                                    ],
                                },
                                Gateways: {
                                    title: "Gateways",
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "list",
                                    items: {
                                        title: "Gateway",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                    },
                                },
                                IsRespawning: {
                                    title: "Is Respawning",
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "byte",
                                    markdownEnumDescriptions: ["false", "true"],
                                    enum: [
                                        { type: "byte", value: 0 },
                                        { type: "byte", value: 1 },
                                    ],
                                },
                                PreviouslyKilled: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "byte",
                                    markdownEnumDescriptions: ["false", "true"],
                                    enum: [
                                        { type: "byte", value: 0 },
                                        { type: "byte", value: 1 },
                                    ],
                                },
                            },
                        },
                        Gateways: {
                            title: "Gateways",
                            markdownDescription: "UNDOCUMENTED.",
                            type: "list",
                            items: {
                                title: "Gateway",
                                markdownDescription: "UNDOCUMENTED.",
                                type: "compound",
                                required: ["Entry", "Exit"],
                                properties: {
                                    Entry: {
                                        title: "Entry",
                                        markdownDescription: "UNDOCUMENTED. A Vector3.",
                                        type: "list",
                                        items: [
                                            {
                                                title: "x",
                                                markdownDescription: "X component of this vector.",
                                                type: "int",
                                            },
                                            {
                                                title: "y",
                                                markdownDescription: "Y component of this vector.",
                                                type: "int",
                                            },
                                            {
                                                title: "z",
                                                markdownDescription: "Z component of this vector.",
                                                type: "int",
                                            },
                                        ],
                                    },
                                    Exit: {
                                        title: "Exit",
                                        markdownDescription: "UNDOCUMENTED. A Vector3.",
                                        type: "list",
                                        items: [
                                            {
                                                title: "x",
                                                markdownDescription: "X component of this vector.",
                                                type: "int",
                                            },
                                            {
                                                title: "y",
                                                markdownDescription: "Y component of this vector.",
                                                type: "int",
                                            },
                                            {
                                                title: "z",
                                                markdownDescription: "Z component of this vector.",
                                                type: "int",
                                            },
                                        ],
                                    },
                                },
                            },
                        },
                    },
                },
            },
            allOf: [{ $ref: "LimboEntities" }],
            additionalProperties: false,
        },
        // NOTE: Verified.
        CustomDimension: {
            id: "CustomDimension",
            title: "The CustomDimension schema.",
            markdownDescription: "The data of a custom dimension, seems to currently just include the LimboEntities data.",
            type: "compound",
            properties: {},
            $ref: "LimboEntities",
        },
        // NOTE: Verified.
        DynamicProperties: {
            id: "DynamicProperties",
            title: "The DynamicProperties schema.",
            markdownDescription: "The dynamic properties data of the add-ons that have been on the world. The property keys should be the add-ons' script module UUIDs.",
            type: "compound",
            additionalProperties: {
                markdownDescription: "The dynamic properties of an add-on. The property keys should be the dynamic property keys.",
                type: "compound",
                additionalProperties: {
                    oneOf: [
                        {
                            markdownDescription: "A string.",
                            type: "string",
                        },
                        {
                            markdownDescription: "A boolean.",
                            type: "byte",
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                            markdownEnumDescriptions: ["false", "true"],
                        },
                        {
                            markdownDescription: "A number.",
                            type: "double",
                        },
                        {
                            markdownDescription: "A Vector3.",
                            type: "list",
                            items: [
                                {
                                    title: "x",
                                    markdownDescription: "X component of this vector.",
                                    type: "float",
                                },
                                {
                                    title: "y",
                                    markdownDescription: "Y component of this vector.",
                                    type: "float",
                                },
                                {
                                    title: "z",
                                    markdownDescription: "Z component of this vector.",
                                    type: "float",
                                },
                            ],
                        },
                    ],
                },
            },
        },
        // NOTE: Verified.
        LevelDat: {
            id: "LevelDat",
            title: "The LevelDat schema.",
            markdownDescription: "World data.",
            type: "compound",
            properties: {
                abilities: {
                    type: "compound",
                    properties: {
                        attackmobs: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the player can attack mobs.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        attackplayers: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the player can attack other players.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        build: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the player can place blocks.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        doorsandswitches: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the player is able to interact with redstone components.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        flying: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the player is currently flying.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        flySpeed: {
                            type: "float",
                            markdownDescription: "The flying speed, always 0.05 (or 0.05000000074505806).",
                            default: {
                                type: "float",
                                value: 0.05,
                            },
                        },
                        instabuild: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the player can instantly destroy blocks.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        invulnerable: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the player is immune to all damage and harmful effects.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        lightning: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the player was struck by lightning.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        mayfly: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the player can fly.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        mine: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the player can destroy blocks.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        // REVIEW: Check if this property actually ever exists.
                        mute: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the player messages cannot be seen by other players.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        // REVIEW: Check if this property actually ever exists.
                        noclip: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the player can phase through blocks.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        op: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the player has operator commands.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        opencontainers: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the player is able to open containers.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        // REVIEW: Check if this property actually ever exists.
                        permissionsLevel: {
                            type: "int",
                            markdownDescription: "What permissions a player defaults to, when joining a world.",
                            default: {
                                type: "int",
                                value: 0,
                            },
                        },
                        // REVIEW: Check if this property actually ever exists.
                        playerPermissionsLevel: {
                            type: "int",
                            markdownDescription: "What permissions a player has.",
                            default: {
                                type: "int",
                                value: 0,
                            },
                        },
                        teleport: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the player is allowed to teleport.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        walkSpeed: {
                            type: "float",
                            markdownDescription: "The walking speed, always 0.1.",
                            default: {
                                type: "float",
                                value: 0.1,
                            },
                        },
                        // REVIEW: Check if this property actually ever exists.
                        worldbuilder: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the player is a world builder.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        verticalFlySpeed: {
                            type: "float",
                            markdownDescription: "The vertical fly speed, always 1.",
                            default: {
                                type: "float",
                                value: 1,
                            },
                        },
                    },
                    markdownDescription: "The default permissions for players in the world.",
                },
                allowAnonymousBlockDropsInEditorWorlds: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                // REVIEW: Check if this property actually ever exists.
                allowdestructiveobjects: {
                    type: "byte",
                    markdownDescription: "The `allowdestructiveobjects` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                // REVIEW: Check if this property actually ever exists.
                allowmobs: {
                    type: "byte",
                    markdownDescription: "The `allowmobs` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                baseGameVersion: {
                    type: "string",
                    markdownDescription: "The version of Minecraft that is the maximum version to load resources from. Eg. setting this to `1.16.0` removes any features that were added after version `1.16.0`.",
                    default: {
                        type: "string",
                        value: "*",
                    },
                },
                BiomeOverride: {
                    type: "string",
                    markdownDescription: "Makes the world into a [single biome](https://minecraft.wiki/w/single_biome) world and the biome set here is the biome of this single biome world.",
                    examples: Object.keys(__biome_data__.int_map).map((biome) => ({
                        type: "string",
                        value: biome,
                    })),
                },
                bonusChestEnabled: {
                    type: "byte",
                    markdownDescription: "1 or 0 (true/false) - true if the bonus chest is enabled.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                bonusChestSpawned: {
                    type: "byte",
                    markdownDescription: "1 or 0 (true/false) - true if the bonus chest has been placed in the world. Turning this to false spawns another bonus chest near the spawn coordinates.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                cheatsEnabled: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                // REVIEW: Check if this property actually ever exists.
                codebuilder: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                commandblockoutput: {
                    type: "byte",
                    markdownDescription: "The `commandblockoutput` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                CenterMapsToOrigin: {
                    type: "byte",
                    markdownDescription: "1 or 0 (true/false) - true if the maps should be on a grid or centered to exactly where they are created. Default to 0.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                commandblocksenabled: {
                    type: "byte",
                    markdownDescription: "The `commandblocksenabled` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                commandsEnabled: {
                    type: "byte",
                    markdownDescription: "1 or 0 (true/false) - true if cheats are on.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                ConfirmedPlatformLockedContent: {
                    type: "byte",
                    markdownDescription: "1 or 0 (true/false) - tells if the world has Platform-Specific texture packs or content. Used to prevent cross play in specific worlds, that use assets allowed only on specific consoles.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                currentTick: {
                    type: "long",
                    markdownDescription: "UNDOCUMENTED.",
                },
                Difficulty: {
                    type: "int",
                    markdownDescription: "The current difficulty setting. 0 is Peaceful, 1 is Easy, 2 is Normal, and 3 is Hard.",
                    markdownEnumDescriptions: ["Peaceful", "Easy", "Normal", "Hard"],
                    enum: [
                        { type: "int", value: 0 },
                        { type: "int", value: 1 },
                        { type: "int", value: 2 },
                        { type: "int", value: 3 },
                    ],
                },
                // REVIEW: Check if this property actually ever exists.
                Dimension: {
                    type: "int",
                    markdownDescription: "The dimension the player is in. 0 is the Overworld, 1 is the Nether, and 2 is the End.",
                    markdownEnumDescriptions: ["Overworld", "Nether", "The End"],
                    enum: [
                        { type: "int", value: 0 },
                        { type: "int", value: 1 },
                        { type: "int", value: 2 },
                    ],
                },
                daylightCycle: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                },
                dodaylightcycle: {
                    type: "byte",
                    markdownDescription: "The `dodaylightcycle` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                doentitydrops: {
                    type: "byte",
                    markdownDescription: "The `doentitydrops` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                dofiretick: {
                    type: "byte",
                    markdownDescription: "The `dofiretick` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                doimmediaterespawn: {
                    type: "byte",
                    markdownDescription: "The `doimmediaterespawn` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                doinsomnia: {
                    type: "byte",
                    markdownDescription: "The `doinsomnia` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                dolimitedcrafting: {
                    type: "byte",
                    markdownDescription: "The `dolimitedcrafting` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                domobloot: {
                    type: "byte",
                    markdownDescription: "The `domobloot` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                domobspawning: {
                    type: "byte",
                    markdownDescription: "The `domobspawning` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                dotiledrops: {
                    type: "byte",
                    markdownDescription: "The `dotiledrops` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                doweathercycle: {
                    type: "byte",
                    markdownDescription: "The `doweathercycle` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                drowningdamage: {
                    type: "byte",
                    markdownDescription: "The `drowningdamage` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                educationFeaturesEnabled: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                // For some reason this is actually an int.
                editorWorldType: {
                    type: "int",
                    markdownDescription: "Marks a world as a [bedrock editor](https://minecraft.wiki/w/Bedrock_Editor) world (worlds with this set to 1 only show up when in editor mode).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "int", value: 0 },
                        { type: "int", value: 1 },
                    ],
                },
                // REVIEW: Check if this property actually ever exists.
                EducationOid: {
                    type: "string",
                    markdownDescription: "A [UUID](https://minecraft.wiki/w/UUID). *info needed*",
                },
                // REVIEW: Check if this property actually ever exists.
                EducationProductId: {
                    type: "string",
                    markdownDescription: "UNDOCUMENTED.",
                },
                eduOffer: {
                    type: "int",
                    markdownDescription: "Marks a world as an Education Edition world (worlds with this set to 1 do not open on Bedrock!).",
                    default: {
                        type: "int",
                        value: 0,
                    },
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "int", value: 0 },
                        { type: "int", value: 1 },
                    ],
                },
                // REVIEW: Check if this property actually ever exists.
                eduSharedResource: {
                    type: "compound",
                    properties: {
                        buttonName: {
                            type: "string",
                            markdownDescription: "Unused in Bedrock Edition, but is used in Education Edition as part of the Resource Link feature on the Pause Screen. It defines the Resource Link Button Text.",
                        },
                        linkUri: {
                            type: "string",
                            markdownDescription: "Unused in Bedrock Edition, but is used in Education Edition as part of the Resource Link feature on the Pause Screen. It defines what link opens upon clicking the Resource Link Button.",
                        },
                    },
                },
                experiments: {
                    type: "compound",
                    markdownDescription: "The experimental toggles.",
                    properties: {
                        experiments_ever_used: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the world is locked on [experimental gameplay](https://minecraft.wiki/w/experimental_gameplay).",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        saved_with_toggled_experiments: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the world has been saved with experiments on before.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        gametest: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the beta APIs experimental toggle is enabled.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        camera_aim_assist: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the camera aim assist experimental toggle is enabled.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        data_driven_biomes: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the data driven biomes experimental toggle is enabled.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        data_driven_items: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - UNDOCUMENTED.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        data_driven_vanilla_blocks_and_items: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - UNDOCUMENTED.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        experimental_creator_cameras: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the experimental creator cameras experimental toggle is enabled.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        experimental_molang_features: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - UNDOCUMENTED.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        jigsaw_structures: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the jigsaw structures experimental toggle is enabled.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        locator_bar: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the locator bar experimental toggle is enabled.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        next_major_update: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - UNDOCUMENTED.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        upcoming_creator_features: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the upcoming creator features experimental toggle is enabled.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        vanilla_experiments: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - UNDOCUMENTED.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        y_2025_drop_1: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the y_2025_drop_1 experimental toggle is enabled.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        y_2025_drop_2: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the y_2025_drop_2 experimental toggle is enabled.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        y_2025_drop_3: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the y_2025_drop_3 experimental toggle is enabled.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        y_2026_drop_1: {
                            type: "byte",
                            markdownDescription: "1 or 0 (true/false) - true if the y_2026_drop_1 experimental toggle is enabled.",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                    },
                    additionalProperties: {
                        type: "byte",
                        markdownEnumDescriptions: ["false", "true"],
                        enum: [
                            { type: "byte", value: 0 },
                            { type: "byte", value: 1 },
                        ],
                    },
                },
                falldamage: {
                    type: "byte",
                    markdownDescription: "The `falldamage` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                firedamage: {
                    type: "byte",
                    markdownDescription: "The `firedamage` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                FlatWorldLayers: {
                    type: "string",
                    markdownDescription: 'JSON that controls generation of flat worlds. Default is `{"biome_id":1,"block_layers":[{"block_name":"minecraft:bedrock","count":1},{"block_name":"minecraft:dirt","count":2},{"block_name":"minecraft:grass_block","count":1}],"encoding_version":6,"structure_options":null,"world_version":"version.post_1_18"}`.',
                    default: {
                        type: "string",
                        value: `{"biome_id":1,"block_layers":[{"block_name":"minecraft:bedrock","count":1},{"block_name":"minecraft:dirt","count":2},{"block_name":"minecraft:grass_block","count":1}],"encoding_version":6,"structure_options":null,"world_version":"version.post_1_18"}`,
                    },
                },
                freezedamage: {
                    type: "byte",
                    markdownDescription: "The `freezedamage` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                functioncommandlimit: {
                    type: "int",
                    markdownDescription: "The `functioncommandlimit` [game rule](https://minecraft.wiki/w/game_rule).",
                    default: {
                        type: "int",
                        value: 10_000,
                    },
                },
                // REVIEW: Check if this property actually ever exists.
                globalmute: {
                    type: "byte",
                    markdownDescription: "The `globalmute` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                ForceGameType: {
                    type: "byte",
                    markdownDescription: "1 or 0 (true/false) - true if force the player into the game mode defined in `GameType`.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                GameType: {
                    type: "int",
                    markdownDescription: "The default game mode of the player. 0 is [Survival](https://minecraft.wiki/w/Survival), 1 is [Creative](https://minecraft.wiki/w/Creative), 2 is [Adventure](https://minecraft.wiki/w/Adventure), 5 is [Default](https://minecraft.wiki/w/Game_mode#Default), and 6 is [Spectator](https://minecraft.wiki/w/Spectator).",
                    oneOf: [
                        {
                            type: "int",
                            not: {
                                enum: [
                                    { type: "int", value: 0 },
                                    { type: "int", value: 1 },
                                    { type: "int", value: 2 },
                                    { type: "int", value: 5 },
                                    { type: "int", value: 6 },
                                    { type: "int", value: 7 },
                                ],
                            },
                        },
                        {
                            type: "int",
                            markdownEnumDescriptions: ["Survival", "Creative", "Adventure", "Default", "Spectator"],
                            enum: [
                                { type: "int", value: 0 },
                                { type: "int", value: 1 },
                                { type: "int", value: 2 },
                                { type: "int", value: 5 },
                                { type: "int", value: 6 },
                            ],
                        },
                    ],
                },
                Generator: {
                    type: "int",
                    markdownDescription: "The world type. 0 is Old, 1 is Infinite, 2 is Flat, and 5 is Void.",
                    oneOf: [
                        {
                            not: {
                                enum: [
                                    { type: "int", value: 0 },
                                    { type: "int", value: 1 },
                                    { type: "int", value: 2 },
                                    { type: "int", value: 5 },
                                ],
                            },
                        },
                        {
                            markdownEnumDescriptions: ["Old", "Infinite", "Flat", "Void"],
                            enum: [
                                { type: "int", value: 0 },
                                { type: "int", value: 1 },
                                { type: "int", value: 2 },
                                { type: "int", value: 5 },
                            ],
                        },
                    ],
                },
                hasBeenLoadedInCreative: {
                    type: "byte",
                    markdownDescription: "Whether the world has achievements locked. Set to 1 if the default game mode is set to Creative, if [cheats](https://minecraft.wiki/w/Commands#Cheats) have been enabled, or if a [behavior pack](https://minecraft.wiki/w/add-on) has been equipped.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                hasLockedBehaviorPack: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                hasLockedResourcePack: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                HasUncompleteWorldFileOnDisk: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                immutableWorld: {
                    type: "byte",
                    markdownDescription: "Is read-only.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                InventoryVersion: {
                    type: "string",
                    markdownDescription: "Seems to correspond to the version the world was created or first opened in",
                    examples: [
                        {
                            type: "string",
                            value: "1.21.51",
                        },
                        {
                            type: "string",
                            value: "1.26.10-preview21",
                        },
                    ],
                },
                isCreatedInEditor: {
                    type: "byte",
                    markdownDescription: "1 or 0 (true/false) - true if it was created from the [bedrock editor](https://minecraft.wiki/w/Bedrock_Editor).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                isExportedFromEditor: {
                    type: "byte",
                    markdownDescription: "1 or 0 (true/false) - true if exported from the [bedrock editor](https://minecraft.wiki/w/Bedrock_Editor).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                isFromLockedTemplate: {
                    type: "byte",
                    markdownDescription: "1 or 0 (true/false) - true if the world is created from a world template where the world options were intended not to be modified.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                isFromWorldTemplate: {
                    type: "byte",
                    markdownDescription: "1 or 0 (true/false) - true if the world is created from a world template.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                IsHardcore: {
                    type: "byte",
                    markdownDescription: "1 or 0 (true/false) - true if the world is in [Hardcore](https://minecraft.wiki/w/Hardcore) mode.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                isRandomSeedAllowed: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                isSingleUseWorld: {
                    type: "byte",
                    markdownDescription: "1 or 0 (true/false) - (unused) may cause world to not save, or delete after use. Seems to default back to false when a world is loaded.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                isWorldTemplateOptionLocked: {
                    type: "byte",
                    markdownDescription: "1 or 0 (true/false) - true if the world options cannot be modified until the user accepts that they are changing the map.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                keepinventory: {
                    type: "byte",
                    markdownDescription: "The `keepinventory` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                LANBroadcast: {
                    type: "byte",
                    markdownDescription: 'Whether the world has been opened with the "Visible to LAN players" world setting enabled.',
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                LANBroadcastIntent: {
                    type: "byte",
                    markdownDescription: 'Whether the "Visible to LAN players" world toggle is enabled.',
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                lastOpenedWithVersion: {
                    type: "list",
                    markdownDescription: "Five ints representing the last version with which the world was opened. Eg. for the [beta/_Preview_ 1.20.30.22](https://minecraft.wiki/w/Bedrock_Edition_Preview_1.20.30.22) the version is `1 20 30 22 1`.",
                    items: [
                        {
                            title: "Major",
                            type: "int",
                        },
                        {
                            title: "Minor",
                            type: "int",
                        },
                        {
                            title: "Patch",
                            type: "int",
                        },
                        {
                            title: "Build",
                            type: "int",
                        },
                        {
                            title: "Preview",
                            type: "int",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "int", value: 0 },
                                { type: "int", value: 1 },
                            ],
                        },
                    ],
                },
                LastPlayed: {
                    type: "long",
                    markdownDescription: "Stores a timestamp of when the world was last played as the number of seconds since the epoch (1/1/1970).",
                },
                LevelName: {
                    type: "string",
                    markdownDescription: "Specifies the name of the world.",
                    default: {
                        type: "string",
                        value: "My World",
                    },
                },
                lightningLevel: {
                    type: "float",
                    markdownDescription: "UNDOCUMENTED.",
                },
                lightningTime: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                },
                LimitedWorldOriginX: {
                    type: "int",
                    markdownDescription: "The X coordinate where limited (old) world generation started.",
                    default: {
                        type: "int",
                        value: 0,
                    },
                },
                LimitedWorldOriginY: {
                    type: "int",
                    markdownDescription: "The Y coordinate where limited (old) world generation started.",
                    default: {
                        type: "int",
                        value: 0,
                    },
                },
                LimitedWorldOriginZ: {
                    type: "int",
                    markdownDescription: "The Z coordinate where limited (old) world generation started.",
                    default: {
                        type: "int",
                        value: 0,
                    },
                },
                limitedWorldDepth: {
                    type: "int",
                    markdownDescription: "The depth (in chunks) of the borders surrounding the (old) world generation. Defaults to 16.",
                    default: {
                        type: "int",
                        value: 16,
                    },
                },
                limitedWorldWidth: {
                    type: "int",
                    markdownDescription: "The width (in chunks) of the borders surrounding the (old) world generation. Defaults to 16.",
                    default: {
                        type: "int",
                        value: 16,
                    },
                },
                locatorbar: {
                    type: "byte",
                    markdownDescription: "The `locatorbar` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                maxcommandchainlength: {
                    type: "int",
                    markdownDescription: "The `maxcommandchainlength` [game rule](https://minecraft.wiki/w/game_rule).",
                    default: {
                        type: "int",
                        value: 65_535,
                    },
                },
                MinimumCompatibleClientVersion: {
                    type: "list",
                    markdownDescription: "Five ints representing the minimum compatible client version that is needed to open the world. Eg. for the [beta/_Preview_ 1.20.30.22](https://minecraft.wiki/w/Bedrock_Edition_Preview_1.20.30.22) the minimum compatible version is `1 20 30 0 0`.",
                    items: [
                        {
                            title: "Major",
                            type: "int",
                        },
                        {
                            title: "Minor",
                            type: "int",
                        },
                        {
                            title: "Patch",
                            type: "int",
                        },
                        {
                            title: "Build",
                            type: "int",
                        },
                        {
                            title: "Preview",
                            type: "int",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "int", value: 0 },
                                { type: "int", value: 1 },
                            ],
                        },
                    ],
                },
                mobgriefing: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                MultiplayerGame: {
                    type: "byte",
                    markdownDescription: 'Whether the world has been opened with the "Multiplayer Game" world setting enabled.',
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                MultiplayerGameIntent: {
                    type: "byte",
                    markdownDescription: 'Whether the "Multiplayer Game" world toggle is enabled.',
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                naturalregeneration: {
                    type: "byte",
                    markdownDescription: "The `naturalregeneration` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                NetherScale: {
                    type: "int",
                    markdownDescription: "Defaults to 8. This is used to tell the game how many Overworld blocks go into one nether block (X blocks in the nether = 1 block in the overworld).",
                    default: {
                        type: "int",
                        value: 8,
                    },
                },
                NetworkVersion: {
                    type: "int",
                    markdownDescription: "Seems to store the protocol version of the version the world was created or first opened in.",
                },
                Platform: {
                    type: "int",
                    markdownDescription: "Seems to store the platform that the level is created on. Currently observed value is 2.",
                    default: {
                        type: "int",
                        value: 2,
                    },
                },
                PlatformBroadcastIntent: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                },
                PlayerHasDied: {
                    type: "byte",
                    // TODO: Figure out if this is for is any player died, only the host, any player dying in hardcore mode, or the host dying in hardcore mode.
                    markdownDescription: "Whether a player has died in this world (may refer to the host specifically or may refer to any player).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                permissionsLevel: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                },
                playerPermissionsLevel: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                },
                playerssleepingpercentage: {
                    type: "int",
                    markdownDescription: "The `playerssleepingpercentage` [game rule](https://minecraft.wiki/w/game_rule).",
                    default: {
                        type: "int",
                        value: 100,
                    },
                },
                playerwaypoints: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                },
                prid: {
                    type: "string",
                    markdownDescription: "The UUID of the premium world template this world was created with. Used for [Marketplace worlds](https://minecraft.wiki/w/Marketplace#Worlds). *info needed*",
                    default: {
                        type: "string",
                        value: "",
                    },
                },
                projectilescanbreakblocks: {
                    type: "byte",
                    markdownDescription: "The `projectilescanbreakblocks` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                pvp: {
                    type: "byte",
                    markdownDescription: "The `pvp` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                rainLevel: {
                    type: "float",
                    markdownDescription: "UNDOCUMENTED.",
                },
                rainTime: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                },
                RandomSeed: {
                    type: "long",
                    markdownDescription: "Level seed.",
                },
                randomtickspeed: {
                    type: "int",
                    markdownDescription: "The `randomtickspeed` [game rule](https://minecraft.wiki/w/game_rule).",
                    default: {
                        type: "int",
                        value: 1,
                    },
                },
                recipesunlock: {
                    type: "byte",
                    markdownDescription: "The `recipesunlock` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                requiresCopiedPackRemovalCheck: {
                    type: "byte",
                    markdownDescription: "UNDOCUMENTED.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                respawnblocksexplode: {
                    type: "byte",
                    markdownDescription: "The `respawnblocksexplode` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                sendcommandfeedback: {
                    type: "byte",
                    markdownDescription: "The `sendcommandfeedback` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                serverChunkTickRange: {
                    type: "int",
                    markdownDescription: "Simulation distance. *info needed*",
                    default: {
                        type: "int",
                        value: 4,
                    },
                },
                serverEditorConnectionPolicy: {
                    type: "int",
                    markdownDescription: "UNDOCUMENTED.",
                },
                showbordereffect: {
                    type: "byte",
                    markdownDescription: "The `showbordereffect` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                showcoordinates: {
                    type: "byte",
                    markdownDescription: "The `showcoordinates` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                showdaysplayed: {
                    type: "byte",
                    markdownDescription: "The `showdaysplayed` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                showdeathmessages: {
                    type: "byte",
                    markdownDescription: "The `showdeathmessages` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                showrecipemessages: {
                    type: "byte",
                    markdownDescription: "The `showrecipemessages` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                showtags: {
                    type: "byte",
                    markdownDescription: "The `showtags` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                spawnMobs: {
                    type: "byte",
                    markdownDescription: "1 or 0 (true/false) - true if mobs can spawn.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                spawnradius: {
                    type: "int",
                    markdownDescription: "The `spawnradius` [game rule](https://minecraft.wiki/w/game_rule).",
                },
                SpawnV1Villagers: {
                    type: "byte",
                    markdownDescription: "Spawn pre-1.10.0 villagers.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                SpawnX: {
                    type: "int",
                    markdownDescription: "The X coordinate of the world spawn position. Defaults to 0.",
                    default: {
                        type: "int",
                        value: 0,
                    },
                },
                SpawnY: {
                    type: "int",
                    markdownDescription: "The Y coordinate of the world spawn position. Defaults to 64.",
                    default: {
                        type: "int",
                        value: 64,
                    },
                },
                SpawnZ: {
                    type: "int",
                    markdownDescription: "The Z coordinate of the world spawn position. Defaults to 0.",
                    default: {
                        type: "int",
                        value: 0,
                    },
                },
                startWithMapEnabled: {
                    type: "byte",
                    markdownDescription: "1 or 0 (true/false) - true if new players spawn with a locator map.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                StorageVersion: {
                    type: "int",
                    markdownDescription: "Version of _Bedrock Edition_ Storage Tool, currently is 10.",
                    default: {
                        type: "int",
                        value: 10,
                    },
                },
                texturePacksRequired: {
                    type: "byte",
                    markdownDescription: "1 or 0 (true/false) - true if the user must download the texture packs applied to the world to join, this option also disables global resource packs.",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                Time: {
                    type: "long",
                    markdownDescription: 'Stores the current "time of day" in ticks. There are 20 ticks per real-life second, and 24000 ticks per Minecraft [daylight cycle](https://minecraft.wiki/w/daylight_cycle), making the full cycle length 20 minutes. 0 is the start of [daytime](https://minecraft.wiki/w/Daylight_cycle#Daytime), 12000 is the start of [sunset](https://minecraft.wiki/w/Daylight_cycle#Sunset/dusk), 13800 is the start of [nighttime](https://minecraft.wiki/w/Daylight_cycle#Nighttime), 22200 is the start of [sunrise](https://minecraft.wiki/w/Daylight_cycle#Sunrise/dawn), and 24000 is daytime again. The value stored in level.dat is always increasing and can be larger than 24000, but the "time of day" is always modulo 24000 of the "Time" field value.',
                    default: {
                        type: "long",
                        value: 0n,
                    },
                },
                WorldVersion: {
                    type: "int",
                    markdownDescription: "UNDOCMENTED.",
                    default: {
                        type: "int",
                        value: 1,
                    },
                },
                tntexplodes: {
                    type: "byte",
                    markdownDescription: "The `tntexplodes` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                tntexplosiondropdecay: {
                    type: "byte",
                    markdownDescription: "The `tntexplosiondropdecay` [game rule](https://minecraft.wiki/w/game_rule).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                useMsaGamertagsOnly: {
                    type: "byte",
                    markdownDescription: "Whether the world is restricted to Microsoft Accounts only (players must be signed in).",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                worldStartCount: {
                    type: "long",
                    markdownDescription: "Counts how many times the game has been closed since the world was created, with its value decreasing by 1 each time.",
                },
                world_policies: {
                    type: "compound",
                    properties: {},
                    additionalProperties: true,
                    markdownDescription: "UNDOCUMENTED.",
                },
                XBLBroadcastIntent: {
                    type: "int",
                    markdownDescription: 'The [multiplayer](https://minecraft.wiki/w/multiplayer) exposure for Xbox Live services, corresponding to the "Microsoft Account Settings" world setting. 0 is disabled, *info needed* 1 is "Invite Only," 2 is "Friends Only," and 3 is "Friends of Friends."',
                    oneOf: [
                        {
                            not: {
                                enum: [
                                    {
                                        type: "int",
                                        value: 0,
                                    },
                                    {
                                        type: "int",
                                        value: 1,
                                    },
                                    {
                                        type: "int",
                                        value: 2,
                                    },
                                    {
                                        type: "int",
                                        value: 3,
                                    },
                                ],
                            },
                        },
                        {
                            type: "int",
                            markdownEnumDescriptions: ["disabled", "Invite Only", "Friends Only", "Friends of Friends"],
                            enum: [
                                {
                                    type: "int",
                                    value: 0,
                                },
                                {
                                    type: "int",
                                    value: 1,
                                },
                                {
                                    type: "int",
                                    value: 2,
                                },
                                {
                                    type: "int",
                                    value: 3,
                                },
                            ],
                        },
                    ],
                },
            },
        },
        // NOTE: Verified.
        LegacyOverworld: {
            id: "LegacyOverworld",
            markdownDescription: "The structure data of the Overworld dimension, this is the data for the `dimension0` LevelDB key.",
            type: "compound",
            required: ["mineshaft", "oceans", "scattered", "stronghold", "village"],
            properties: {
                mansion: {
                    title: "Woodland Mansions",
                    markdownDescription: "The list of woodland mansions.",
                    type: "compound",
                    properties: {
                        structures: {
                            type: "list",
                            items: {
                                type: "compound",
                                required: ["BB", "Children", "ChunkX", "ChunkZ", "ID", "IsValid"],
                                properties: {
                                    BB: {
                                        title: "Bounding Box",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "intArray",
                                        minItems: 6,
                                        maxItems: 6,
                                    },
                                    Children: {
                                        title: "Children",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "list",
                                        items: {
                                            type: "compound",
                                            required: ["BB", "ID", "Mirror", "Rotation", "Template", "TemplatePosition", "gendepth", "orientation"],
                                            properties: {
                                                BB: {
                                                    title: "Bounding Box",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "intArray",
                                                    minItems: 6,
                                                    maxItems: 6,
                                                },
                                                ID: {
                                                    title: "ID",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                Mirror: {
                                                    title: "Mirror",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                    markdownEnumDescriptions: ["UNDOCUMENTED.", "UNDOCUMENTED.", "UNDOCUMENTED.", "UNDOCUMENTED."],
                                                    enum: [
                                                        { type: "int", value: 0 },
                                                        { type: "int", value: 1 },
                                                        { type: "int", value: 2 },
                                                        { type: "int", value: 3 },
                                                    ],
                                                },
                                                Rotation: {
                                                    title: "Rotation",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                    markdownEnumDescriptions: ["UNDOCUMENTED.", "UNDOCUMENTED.", "UNDOCUMENTED.", "UNDOCUMENTED."],
                                                    enum: [
                                                        { type: "int", value: 0 },
                                                        { type: "int", value: 1 },
                                                        { type: "int", value: 2 },
                                                        { type: "int", value: 3 },
                                                    ],
                                                },
                                                Template: {
                                                    title: "Template",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "string",
                                                    // [...new Set(data.mansion.value.structures.value.value.flatMap(v=>v.Children.value.value.flatMap(v=>v.Template.value)))].map(v=>({type: "string", value: v}))
                                                    // TODO: Find more of this structure to find all possible templates, then switch this to an enum.
                                                    examples: [
                                                        {
                                                            type: "string",
                                                            value: "entrance",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "wall_flat",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "wall_corner",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "wall_window",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "roof",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "roof_front",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "small_wall",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "small_wall_corner",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "roof_corner",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "roof_inner_corner",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "corridor_floor",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "carpet_east",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "carpet_south",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "carpet_west",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "carpet_north",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "indoors_wall",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "indoors_door",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "2x2_a4",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "1x2_a5",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "1x1_a3",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "1x1_a4",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "2x2_a3",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "1x2_a7",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "1x1_a2",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "1x2_b1",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "1x2_a9",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "corridor_floor_2",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "carpet_south_2",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "carpet_west_2",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "indoors_wall_2",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "indoors_door_2",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "1x1_b4",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "1x1_b3",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "1x1_b2",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "2x2_b1",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "2x2_b5",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "1x2_c4",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "2x2_b4",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "1x2_c_stairs",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "1x2_c3",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "1x2_c1",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "1x1_as3",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "1x2_d4",
                                                        },
                                                    ],
                                                },
                                                TemplatePosition: {
                                                    title: "Template Position",
                                                    markdownDescription: "UNDOCUMENTED. A Vector3.",
                                                    type: "list",
                                                    items: [
                                                        {
                                                            title: "x",
                                                            markdownDescription: "X component of this vector.",
                                                            type: "int",
                                                        },
                                                        {
                                                            title: "y",
                                                            markdownDescription: "Y component of this vector.",
                                                            type: "int",
                                                        },
                                                        {
                                                            title: "z",
                                                            markdownDescription: "Z component of this vector.",
                                                            type: "int",
                                                        },
                                                    ],
                                                },
                                                gendepth: {
                                                    title: "UNTITLED.",
                                                    description: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                orientation: {
                                                    title: "Orientation",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                            },
                                        },
                                    },
                                    ChunkX: {
                                        title: "Chunk X",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                    },
                                    ChunkZ: {
                                        title: "Chunk Z",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                    },
                                    ID: {
                                        title: "ID",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                        // IDEA: Observed value is 8, maybe make this a constant?
                                    },
                                    IsValid: {
                                        title: "Is Valid",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "byte",
                                        markdownEnumDescriptions: ["false", "true"],
                                        enum: [
                                            { type: "byte", value: 0 },
                                            { type: "byte", value: 1 },
                                        ],
                                    },
                                },
                            },
                        },
                    },
                },
                mineshaft: {
                    title: "Mineshafts",
                    markdownDescription: "The list of mineshafts.",
                    type: "compound",
                    properties: {
                        structures: {
                            type: "list",
                            items: {
                                type: "compound",
                                required: ["BB", "Children", "ChunkX", "ChunkZ", "ID"],
                                properties: {
                                    BB: {
                                        title: "Bounding Box",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "intArray",
                                        minItems: 6,
                                        maxItems: 6,
                                    },
                                    Children: {
                                        title: "Children",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "list",
                                        items: {
                                            type: "compound",
                                            required: ["BB", "ID", "gendepth", "orientation"],
                                            properties: {
                                                BB: {
                                                    title: "Bounding Box",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "intArray",
                                                    minItems: 6,
                                                    maxItems: 6,
                                                },
                                                ID: {
                                                    title: "ID",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                gendepth: {
                                                    title: "UNTITLED.",
                                                    description: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                orientation: {
                                                    title: "Orientation",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                            },
                                            // TODO: Fix the NBT schema to TypeScript type converter, as it doesn't include the types for these `oneOf` entries.
                                            oneOf: [
                                                {
                                                    type: "compound",
                                                    properties: {},
                                                    not: {
                                                        oneOf: [{ required: ["D"] }, { required: ["Entrances"] }, { required: ["Num"] }],
                                                    },
                                                },
                                                {
                                                    type: "compound",
                                                    required: ["D", "tf"],
                                                    properties: {
                                                        D: {
                                                            title: "UNTITLED.",
                                                            description: "UNDOCUMENTED.",
                                                            type: "int",
                                                        },
                                                        tf: {
                                                            title: "UNTITLED.",
                                                            markdownDescription: "UNDOCUMENTED.",
                                                            type: "byte",
                                                            markdownEnumDescriptions: ["false", "true"],
                                                            enum: [
                                                                { type: "byte", value: 0 },
                                                                { type: "byte", value: 1 },
                                                            ],
                                                        },
                                                    },
                                                },
                                                {
                                                    type: "compound",
                                                    required: ["Entrances"],
                                                    properties: {
                                                        Entrances: {
                                                            title: "Entrances",
                                                            markdownDescription: "The bounding boxes of the entrances.",
                                                            type: "list",
                                                            items: {
                                                                title: "Entrance Bounding Box",
                                                                markdownDescription: "The bounding box of an entrance.",
                                                                type: "intArray",
                                                                minItems: 6,
                                                                maxItems: 6,
                                                            },
                                                        },
                                                    },
                                                },
                                                {
                                                    type: "compound",
                                                    required: ["Num", "hps", "hr", "sc"],
                                                    properties: {
                                                        Num: {
                                                            title: "UNTITLED.",
                                                            description: "UNDOCUMENTED.",
                                                            type: "int",
                                                        },
                                                        hps: {
                                                            title: "UNTITLED.",
                                                            markdownDescription: "UNDOCUMENTED.",
                                                            type: "byte",
                                                            markdownEnumDescriptions: ["false", "true"],
                                                            enum: [
                                                                { type: "byte", value: 0 },
                                                                { type: "byte", value: 1 },
                                                            ],
                                                        },
                                                        hr: {
                                                            title: "UNTITLED.",
                                                            markdownDescription: "UNDOCUMENTED.",
                                                            type: "byte",
                                                            markdownEnumDescriptions: ["false", "true"],
                                                            enum: [
                                                                { type: "byte", value: 0 },
                                                                { type: "byte", value: 1 },
                                                            ],
                                                        },
                                                        sc: {
                                                            title: "UNTITLED.",
                                                            markdownDescription: "UNDOCUMENTED.",
                                                            type: "byte",
                                                            markdownEnumDescriptions: ["false", "true"],
                                                            enum: [
                                                                { type: "byte", value: 0 },
                                                                { type: "byte", value: 1 },
                                                            ],
                                                        },
                                                    },
                                                },
                                            ],
                                        },
                                    },
                                    ChunkX: {
                                        title: "Chunk X",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                    },
                                    ChunkZ: {
                                        title: "Chunk Z",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                    },
                                    ID: {
                                        title: "ID",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                        // IDEA: Observed value is 3, maybe make this a constant?
                                    },
                                },
                            },
                        },
                    },
                },
                oceans: {
                    title: "Ocean Monuments",
                    markdownDescription: "The list of ocean monuments.",
                    type: "compound",
                    properties: {
                        structures: {
                            type: "list",
                            items: {
                                type: "compound",
                                required: ["BB", "Children", "ChunkX", "ChunkZ", "ID", "iscreated"],
                                properties: {
                                    BB: {
                                        title: "Bounding Box",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "intArray",
                                        minItems: 6,
                                        maxItems: 6,
                                    },
                                    Children: {
                                        title: "Children",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "list",
                                        items: {
                                            type: "compound",
                                            required: ["BB", "ID", "gendepth", "orientation"],
                                            properties: {
                                                BB: {
                                                    title: "Bounding Box",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "intArray",
                                                    minItems: 6,
                                                    maxItems: 6,
                                                },
                                                ID: {
                                                    title: "ID",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                gendepth: {
                                                    title: "UNTITLED.",
                                                    description: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                orientation: {
                                                    title: "Orientation",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                            },
                                        },
                                    },
                                    ChunkX: {
                                        title: "Chunk X",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                    },
                                    ChunkZ: {
                                        title: "Chunk Z",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                    },
                                    ID: {
                                        title: "ID",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                        // IDEA: Observed value is 4, maybe make this a constant?
                                    },
                                    iscreated: {
                                        title: "Is Created",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "byte",
                                        markdownEnumDescriptions: ["false", "true"],
                                        enum: [
                                            { type: "byte", value: 0 },
                                            { type: "byte", value: 1 },
                                        ],
                                    },
                                },
                            },
                        },
                    },
                },
                scattered: {
                    title: "Temples",
                    markdownDescription: "The list of temples (desert pyramids, jungle pyramids, igloos, and swamp huts).",
                    type: "compound",
                    properties: {
                        structures: {
                            type: "list",
                            items: {
                                type: "compound",
                                required: ["BB", "Children", "ChunkX", "ChunkZ", "ID"],
                                properties: {
                                    BB: {
                                        title: "Bounding Box",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "intArray",
                                        minItems: 6,
                                        maxItems: 6,
                                    },
                                    Children: {
                                        title: "Children",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "list",
                                        items: {
                                            type: "compound",
                                            required: ["BB", "Depth", "HPos", "Height", "ID", "Width", "gendepth", "orientation"],
                                            properties: {
                                                BB: {
                                                    title: "Bounding Box",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "intArray",
                                                    minItems: 6,
                                                    maxItems: 6,
                                                },
                                                Depth: {
                                                    title: "Depth",
                                                    description: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                HPos: {
                                                    title: "UNTITLED.",
                                                    description: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                Height: {
                                                    title: "Height",
                                                    description: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                ID: {
                                                    title: "ID",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                Width: {
                                                    title: "Width",
                                                    description: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                gendepth: {
                                                    title: "UNTITLED.",
                                                    description: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                orientation: {
                                                    title: "Orientation",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                            },
                                            oneOf: [
                                                {
                                                    type: "compound",
                                                    properties: {},
                                                    not: {
                                                        oneOf: [
                                                            { required: ["Witch"] },
                                                            { required: ["hasPlacedChest0"] },
                                                            { required: ["hasPlacedHiddenChest"] },
                                                        ],
                                                    },
                                                },
                                                {
                                                    type: "compound",
                                                    required: ["Witch"],
                                                    properties: {
                                                        Witch: {
                                                            title: "Witch",
                                                            markdownDescription: "UNDOCUMENTED.",
                                                            type: "byte",
                                                            markdownEnumDescriptions: ["false", "true"],
                                                            enum: [
                                                                { type: "byte", value: 0 },
                                                                { type: "byte", value: 1 },
                                                            ],
                                                        },
                                                    },
                                                },
                                                {
                                                    type: "compound",
                                                    required: ["hasPlacedChest0", "hasPlacedChest1", "hasPlacedChest2", "hasPlacedChest3"],
                                                    properties: {
                                                        hasPlacedChest0: {
                                                            title: "Has Placed Chest 0",
                                                            markdownDescription: "UNDOCUMENTED.",
                                                            type: "byte",
                                                            markdownEnumDescriptions: ["false", "true"],
                                                            enum: [
                                                                { type: "byte", value: 0 },
                                                                { type: "byte", value: 1 },
                                                            ],
                                                        },
                                                        hasPlacedChest1: {
                                                            title: "Has Placed Chest 1",
                                                            markdownDescription: "UNDOCUMENTED.",
                                                            type: "byte",
                                                            markdownEnumDescriptions: ["false", "true"],
                                                            enum: [
                                                                { type: "byte", value: 0 },
                                                                { type: "byte", value: 1 },
                                                            ],
                                                        },
                                                        hasPlacedChest2: {
                                                            title: "Has Placed Chest 2",
                                                            markdownDescription: "UNDOCUMENTED.",
                                                            type: "byte",
                                                            markdownEnumDescriptions: ["false", "true"],
                                                            enum: [
                                                                { type: "byte", value: 0 },
                                                                { type: "byte", value: 1 },
                                                            ],
                                                        },
                                                        hasPlacedChest3: {
                                                            title: "Has Placed Chest 3",
                                                            markdownDescription: "UNDOCUMENTED.",
                                                            type: "byte",
                                                            markdownEnumDescriptions: ["false", "true"],
                                                            enum: [
                                                                { type: "byte", value: 0 },
                                                                { type: "byte", value: 1 },
                                                            ],
                                                        },
                                                    },
                                                },
                                                {
                                                    type: "compound",
                                                    required: ["hasPlacedHiddenChest", "hasPlacedMainChest", "hasPlacedTrap0", "hasPlacedTrap1"],
                                                    properties: {
                                                        hasPlacedHiddenChest: {
                                                            title: "Has Placed Hidden Chest",
                                                            markdownDescription: "UNDOCUMENTED.",
                                                            type: "byte",
                                                            markdownEnumDescriptions: ["false", "true"],
                                                            enum: [
                                                                { type: "byte", value: 0 },
                                                                { type: "byte", value: 1 },
                                                            ],
                                                        },
                                                        hasPlacedMainChest: {
                                                            title: "Has Placed Main Chest",
                                                            markdownDescription: "UNDOCUMENTED.",
                                                            type: "byte",
                                                            markdownEnumDescriptions: ["false", "true"],
                                                            enum: [
                                                                { type: "byte", value: 0 },
                                                                { type: "byte", value: 1 },
                                                            ],
                                                        },
                                                        hasPlacedTrap0: {
                                                            title: "Has Placed Trap 0",
                                                            markdownDescription: "UNDOCUMENTED.",
                                                            type: "byte",
                                                            markdownEnumDescriptions: ["false", "true"],
                                                            enum: [
                                                                { type: "byte", value: 0 },
                                                                { type: "byte", value: 1 },
                                                            ],
                                                        },
                                                        hasPlacedTrap1: {
                                                            title: "Has Placed Trap 1",
                                                            markdownDescription: "UNDOCUMENTED.",
                                                            type: "byte",
                                                            markdownEnumDescriptions: ["false", "true"],
                                                            enum: [
                                                                { type: "byte", value: 0 },
                                                                { type: "byte", value: 1 },
                                                            ],
                                                        },
                                                    },
                                                },
                                            ],
                                        },
                                    },
                                    ChunkX: {
                                        title: "Chunk X",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                    },
                                    ChunkZ: {
                                        title: "Chunk Z",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                    },
                                    ID: {
                                        title: "ID",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                        // IDEA: Observed value is 6 (for all four temple types), maybe make this a constant?
                                    },
                                },
                            },
                        },
                    },
                },
                stronghold: {
                    title: "Strongholds",
                    markdownDescription: "The list of strongholds.",
                    type: "compound",
                    properties: {
                        structures: {
                            type: "list",
                            items: {
                                type: "compound",
                                required: ["BB", "Children", "ChunkX", "ChunkZ", "ID", "Valid"],
                                properties: {
                                    BB: {
                                        title: "Bounding Box",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "intArray",
                                        minItems: 6,
                                        maxItems: 6,
                                    },
                                    Children: {
                                        title: "Children",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "list",
                                        items: {
                                            type: "compound",
                                            required: ["BB", "EntryDoor", "ID", "gendepth", "orientation"],
                                            properties: {
                                                BB: {
                                                    title: "Bounding Box",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "intArray",
                                                    minItems: 6,
                                                    maxItems: 6,
                                                },
                                                EntryDoor: {
                                                    title: "Entry Door",
                                                    description: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                ID: {
                                                    title: "ID",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                Steps: {
                                                    title: "Steps",
                                                    description: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                Left: {
                                                    title: "Left",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "byte",
                                                    markdownEnumDescriptions: ["false", "true"],
                                                    enum: [
                                                        { type: "byte", value: 0 },
                                                        { type: "byte", value: 1 },
                                                    ],
                                                },
                                                Right: {
                                                    title: "Right",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "byte",
                                                    markdownEnumDescriptions: ["false", "true"],
                                                    enum: [
                                                        { type: "byte", value: 0 },
                                                        { type: "byte", value: 1 },
                                                    ],
                                                },
                                                gendepth: {
                                                    title: "UNTITLED.",
                                                    description: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                leftHigh: {
                                                    title: "Left High",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "byte",
                                                    markdownEnumDescriptions: ["false", "true"],
                                                    enum: [
                                                        { type: "byte", value: 0 },
                                                        { type: "byte", value: 1 },
                                                    ],
                                                },
                                                leftLow: {
                                                    title: "Left Low",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "byte",
                                                    markdownEnumDescriptions: ["false", "true"],
                                                    enum: [
                                                        { type: "byte", value: 0 },
                                                        { type: "byte", value: 1 },
                                                    ],
                                                },
                                                orientation: {
                                                    title: "Orientation",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                rightHigh: {
                                                    title: "Right High",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "byte",
                                                    markdownEnumDescriptions: ["false", "true"],
                                                    enum: [
                                                        { type: "byte", value: 0 },
                                                        { type: "byte", value: 1 },
                                                    ],
                                                },
                                                rightLow: {
                                                    title: "Right Low",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "byte",
                                                    markdownEnumDescriptions: ["false", "true"],
                                                    enum: [
                                                        { type: "byte", value: 0 },
                                                        { type: "byte", value: 1 },
                                                    ],
                                                },
                                            },
                                        },
                                    },
                                    ChunkX: {
                                        title: "Chunk X",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                    },
                                    ChunkZ: {
                                        title: "Chunk Z",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                    },
                                    ID: {
                                        title: "ID",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                        // IDEA: Observed value is 5, maybe make this a constant?
                                    },
                                    Valid: {
                                        title: "Valid",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "byte",
                                        markdownEnumDescriptions: ["false", "true"],
                                        enum: [
                                            { type: "byte", value: 0 },
                                            { type: "byte", value: 1 },
                                        ],
                                    },
                                },
                            },
                        },
                    },
                },
                village: {
                    title: "Villages",
                    markdownDescription: "The list of villages.",
                    type: "compound",
                    properties: {
                        structures: {
                            type: "list",
                            items: {
                                type: "compound",
                                required: ["BB", "Children", "ChunkX", "ChunkZ", "ID", "Valid"],
                                properties: {
                                    BB: {
                                        title: "Bounding Box",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "intArray",
                                        minItems: 6,
                                        maxItems: 6,
                                    },
                                    Children: {
                                        title: "Children",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "list",
                                        items: {
                                            type: "compound",
                                            required: ["Abandoned", "BB", "Desert", "HPos", "ID", "Savannah", "Taiga", "VCount", "gendepth", "orientation"],
                                            properties: {
                                                Abandoned: {
                                                    title: "Is Abandoned",
                                                    markdownDescription: "Whether this is an village is abandoned.",
                                                    type: "byte",
                                                    markdownEnumDescriptions: ["false", "true"],
                                                    enum: [
                                                        { type: "byte", value: 0 },
                                                        { type: "byte", value: 1 },
                                                    ],
                                                },
                                                BB: {
                                                    title: "Bounding Box",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "intArray",
                                                    minItems: 6,
                                                    maxItems: 6,
                                                },
                                                Desert: {
                                                    title: "Is Desert Village",
                                                    markdownDescription: "Whether this is a desert village.",
                                                    type: "byte",
                                                    markdownEnumDescriptions: ["false", "true"],
                                                    enum: [
                                                        { type: "byte", value: 0 },
                                                        { type: "byte", value: 1 },
                                                    ],
                                                },
                                                HPos: {
                                                    title: "UNTITLED.",
                                                    description: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                ID: {
                                                    title: "ID",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                Savannah: {
                                                    title: "Is Savannah Village",
                                                    markdownDescription: "Whether this is a savannah village.",
                                                    type: "byte",
                                                    markdownEnumDescriptions: ["false", "true"],
                                                    enum: [
                                                        { type: "byte", value: 0 },
                                                        { type: "byte", value: 1 },
                                                    ],
                                                },
                                                Taiga: {
                                                    title: "Is Taiga Village",
                                                    markdownDescription: "Whether this is a taiga village.",
                                                    type: "byte",
                                                    markdownEnumDescriptions: ["false", "true"],
                                                    enum: [
                                                        { type: "byte", value: 0 },
                                                        { type: "byte", value: 1 },
                                                    ],
                                                },
                                                VCount: {
                                                    title: "UNTITLED.",
                                                    description: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                gendepth: {
                                                    title: "UNTITLED.",
                                                    description: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                orientation: {
                                                    title: "Orientation",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                            },
                                        },
                                    },
                                    ChunkX: {
                                        title: "Chunk X",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                    },
                                    ChunkZ: {
                                        title: "Chunk Z",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                    },
                                    ID: {
                                        title: "ID",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                        // IDEA: Observed value is 7, maybe make this a constant?
                                    },
                                    Valid: {
                                        title: "Valid",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "byte",
                                        markdownEnumDescriptions: ["false", "true"],
                                        enum: [
                                            { type: "byte", value: 0 },
                                            { type: "byte", value: 1 },
                                        ],
                                    },
                                },
                            },
                        },
                    },
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        LegacyNether: {
            id: "LegacyNether",
            markdownDescription: "The structure data of the Nether dimension, this is the data for the `dimension1` LevelDB key.",
            type: "compound",
            required: ["bridge"],
            properties: {
                bridge: {
                    markdownDescription: "The list of nether fortresses.",
                    type: "compound",
                    properties: {
                        structures: {
                            type: "list",
                            items: {
                                type: "compound",
                                required: ["BB", "Children", "ChunkX", "ChunkZ", "ID"],
                                properties: {
                                    BB: {
                                        title: "Bounding Box",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "intArray",
                                        minItems: 6,
                                        maxItems: 6,
                                    },
                                    Children: {
                                        title: "Children",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "list",
                                        items: {
                                            type: "compound",
                                            required: ["BB", "ID", "gendepth", "orientation"],
                                            properties: {
                                                BB: {
                                                    title: "Bounding Box",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "intArray",
                                                    minItems: 6,
                                                    maxItems: 6,
                                                },
                                                ID: {
                                                    title: "ID",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                gendepth: {
                                                    title: "UNTITLED.",
                                                    description: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                orientation: {
                                                    title: "Orientation",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                            },
                                        },
                                    },
                                    ChunkX: {
                                        title: "Chunk X",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                    },
                                    ChunkZ: {
                                        title: "Chunk Z",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                    },
                                    ID: {
                                        title: "ID",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                        // IDEA: Observed value is 2, maybe make this a constant?
                                    },
                                },
                            },
                        },
                    },
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        LegacyTheEnd: {
            id: "LegacyTheEnd",
            markdownDescription: "The structure data of the End dimension, this is the data for the `dimension2` LevelDB key.",
            type: "compound",
            required: ["endcity"],
            properties: {
                endcity: {
                    markdownDescription: "The list of end cities.",
                    type: "compound",
                    properties: {
                        structures: {
                            type: "list",
                            items: {
                                type: "compound",
                                required: ["BB", "Children", "ChunkX", "ChunkZ", "ID"],
                                properties: {
                                    BB: {
                                        title: "Bounding Box",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "intArray",
                                        minItems: 6,
                                        maxItems: 6,
                                    },
                                    Children: {
                                        title: "Children",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "list",
                                        items: {
                                            type: "compound",
                                            required: ["BB", "ID", "Overwrite", "Rotation", "Template", "TemplatePosition", "gendepth", "orientation"],
                                            properties: {
                                                BB: {
                                                    title: "Bounding Box",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "intArray",
                                                    minItems: 6,
                                                    maxItems: 6,
                                                },
                                                ID: {
                                                    title: "ID",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                Overwrite: {
                                                    title: "Overwrite",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "byte",
                                                    markdownEnumDescriptions: ["false", "true"],
                                                    enum: [
                                                        { type: "byte", value: 0 },
                                                        { type: "byte", value: 1 },
                                                    ],
                                                },
                                                Rotation: {
                                                    title: "Rotation",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                    markdownEnumDescriptions: ["UNDOCUMENTED.", "UNDOCUMENTED.", "UNDOCUMENTED.", "UNDOCUMENTED."],
                                                    enum: [
                                                        { type: "int", value: 0 },
                                                        { type: "int", value: 1 },
                                                        { type: "int", value: 2 },
                                                        { type: "int", value: 3 },
                                                    ],
                                                },
                                                Template: {
                                                    title: "Template",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "string",
                                                    // [...new Set(data.endcity.value.structures.value.value.flatMap(v=>v.Children.value.value.flatMap(v=>v.Template.value)))].map(v=>({type: "string", value: v}))
                                                    // TODO: Find more of this structure to find all possible templates, then switch this to an enum.
                                                    examples: [
                                                        {
                                                            type: "string",
                                                            value: "base_floor",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "second_floor",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "third_floor",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "third_roof",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "tower_base",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "tower_piece",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "bridge_end",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "bridge_piece",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "bridge_steep_stairs",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "base_roof",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "bridge_gentle_stairs",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "second_floor_2",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "third_floor_c",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "fat_tower_base",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "fat_tower_middle",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "ship",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "fat_tower_top",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "tower_top",
                                                        },
                                                        {
                                                            type: "string",
                                                            value: "second_roof",
                                                        },
                                                    ],
                                                },
                                                TemplatePosition: {
                                                    title: "Template Position",
                                                    markdownDescription: "UNDOCUMENTED. A Vector3.",
                                                    type: "list",
                                                    items: [
                                                        {
                                                            title: "x",
                                                            markdownDescription: "X component of this vector.",
                                                            type: "int",
                                                        },
                                                        {
                                                            title: "y",
                                                            markdownDescription: "Y component of this vector.",
                                                            type: "int",
                                                        },
                                                        {
                                                            title: "z",
                                                            markdownDescription: "Z component of this vector.",
                                                            type: "int",
                                                        },
                                                    ],
                                                },
                                                gendepth: {
                                                    title: "UNTITLED.",
                                                    description: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                orientation: {
                                                    title: "Orientation",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                            },
                                        },
                                    },
                                    ChunkX: {
                                        title: "Chunk X",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                    },
                                    ChunkZ: {
                                        title: "Chunk Z",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                    },
                                    ID: {
                                        title: "ID",
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                        // IDEA: Observed value is 1, maybe make this a constant?
                                    },
                                },
                            },
                        },
                    },
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        LimboEntities: {
            id: "LimboEntities",
            markdownDescription: "The limbo entities data.",
            type: "compound",
            required: ["data"],
            properties: {
                data: {
                    markdownDescription: "A compound with a list of limbo entities.",
                    type: "compound",
                    required: ["LimboEntities"],
                    properties: {
                        LimboEntities: {
                            markdownDescription: "UNKNOWN.",
                            type: "list",
                        },
                    },
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        Map: {
            id: "Map",
            title: "The Map schema.",
            markdownDescription: "NBT structure of a map.",
            type: "compound",
            required: [
                "mapId",
                "parentMapId",
                "dimension",
                "fullyExplored",
                "mapLocked",
                "scale",
                "unlimitedTracking",
                "height",
                "width",
                "xCenter",
                "zCenter",
                "decorations",
                "colors",
            ],
            properties: {
                mapId: {
                    markdownDescription: "The Unique ID of the map.",
                    type: "long",
                },
                parentMapId: {
                    markdownDescription: "The Unique ID's of the parent maps.",
                    type: "long",
                },
                dimension: {
                    markdownDescription: "0 = The [Overworld](https://minecraft.wiki/w/Overworld), 1 = [The Nether](https://minecraft.wiki/w/The_Nether), 2 = [The End](https://minecraft.wiki/w/The_End), any other value = a static image with no player pin.",
                    type: "byte",
                },
                fullyExplored: {
                    markdownDescription: "1 if the map is full explored.",
                    type: "byte",
                },
                mapLocked: {
                    markdownDescription: "1 if the map has been locked in a [cartography table](https://minecraft.wiki/w/cartography_table).",
                    type: "byte",
                },
                scale: {
                    markdownDescription: "How zoomed in the map is, and must be a number between 0 and 4 (inclusive) that represent the level. Default 0. If this is changed in an [anvil](https://minecraft.wiki/w/anvil) or a [cartography table](https://minecraft.wiki/w/cartography_table), the Unique ID of the map changes.",
                    type: "byte",
                    default: {
                        type: "byte",
                        value: 0,
                    },
                },
                unlimitedTracking: {
                    markdownDescription: "UNDOCUMENTED. Default 0.",
                    type: "byte",
                    default: {
                        type: "byte",
                        value: 0,
                    },
                },
                height: {
                    markdownDescription: "The height of the map. Is associated with the scale level.",
                    type: "short",
                },
                width: {
                    markdownDescription: "The width of the map. Is associated with the scale level.",
                    type: "short",
                },
                xCenter: {
                    markdownDescription: "Center of the map according to real world by X.",
                    type: "int",
                },
                zCenter: {
                    markdownDescription: "Center of the map according to real world by Z.",
                    type: "int",
                },
                decorations: {
                    markdownDescription: "A list of optional icons to display on the map.",
                    type: "list",
                    items: {
                        markdownDescription: "An individual decoration.",
                        type: "compound",
                        properties: {
                            data: {
                                markdownDescription: "The data of the decoration.",
                                type: "compound",
                                required: ["rot", "type", "x", "y"],
                                properties: {
                                    rot: {
                                        markdownDescription: "The rotation of the symbol, ranging from 0 to 15. South = 0, West = 4, North = 8, East = 12.",
                                        type: "int",
                                    },
                                    type: {
                                        markdownDescription: "The ID of the [map icon](https://minecraft.wiki/w/Map_icons.png) to display.",
                                        type: "int",
                                    },
                                    x: {
                                        markdownDescription: "The horizontal column (x) where the decoration is located on the map (per pixel).",
                                        type: "int",
                                    },
                                    y: {
                                        markdownDescription: "The vertical column (y) where the decoration is located on the map (per pixel).",
                                        type: "int",
                                    },
                                },
                            },
                            // TODO: Figure out the correct schemas for the `key` property.
                            // NOTE: The below schema has been verified but it is unknown if it is different in certain situations.
                            key: {
                                markdownDescription: "UNKNOWN. // CAUTION: This schema has only been verified in certain situations, it is possible that this might follow a different structure in other situations.",
                                type: "compound",
                                required: ["entityId", "type"],
                                properties: {
                                    entityId: {
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "long",
                                        default: {
                                            type: "long",
                                            value: 0n,
                                        },
                                    },
                                    type: {
                                        markdownDescription: "UNDOCUMENTED.",
                                        type: "int",
                                        default: {
                                            type: "int",
                                            value: 0,
                                        },
                                    },
                                },
                            },
                            // TODO: Check if the below schema is actually used in some situations.
                            // key: {
                            //     type: "compound",
                            //     required: ["blockX", "blockY", "blockZ", "type"],
                            //     properties: {
                            //         blockX: {
                            //             markdownDescription: "The world x-position of the decoration.",
                            //             type: "int",
                            //         },
                            //         blockY: {
                            //             markdownDescription: "The world y-position of the decoration.",
                            //             type: "int",
                            //         },
                            //         blockZ: {
                            //             markdownDescription: "The world z-position of the decoration.",
                            //             type: "int",
                            //         },
                            //         type: {
                            //             markdownDescription: "UNDOCUMENTED.",
                            //             type: "int",
                            //         },
                            //     },
                            // },
                        },
                    },
                },
                colors: {
                    markdownDescription: "An array of bytes that represent color values (**65536 entries** for a default 128×128 map).",
                    type: "byteArray",
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        MobEvents: {
            id: "MobEvents",
            markdownDescription: "NBT structure of [mob event](https://minecraft.wiki/w/Commands/mobevent)s.",
            type: "compound",
            required: ["events_enabled", "minecraft:ender_dragon_event", "minecraft:pillager_patrols_event", "minecraft:wandering_trader_event"],
            properties: {
                events_enabled: {
                    markdownDescription: "1 or 0 (true/false) - true if the mob events can occur.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                "minecraft:ender_dragon_event": {
                    markdownDescription: "1 or 0 (true/false) - true if the [ender dragon](https://minecraft.wiki/w/ender_dragon) can spawn.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                "minecraft:pillager_patrols_event": {
                    markdownDescription: "1 or 0 (true/false) - true if the [illager patrol](https://minecraft.wiki/w/illager_patrol) can spawn.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                "minecraft:wandering_trader_event": {
                    markdownDescription: "1 or 0 (true/false) - true if the [wandering trader](https://minecraft.wiki/w/wandering_trader) can spawn.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        PendingTicks: {
            id: "PendingTicks",
            title: "The PendingTicks schema.",
            markdownDescription: "The list of pending ticks for a chunk.",
            type: "compound",
            required: ["tickList"],
            properties: {
                currentTick: {
                    title: "Current Tick",
                    markdownDescription: "The current tick.",
                    type: "int",
                },
                tickList: {
                    title: "Tick List",
                    markdownDescription: "The list of pending ticks.",
                    type: "list",
                    items: {
                        type: "compound",
                        required: ["time", "x", "y", "z"],
                        properties: {
                            blockState: {
                                title: "Block State",
                                markdownDescription: "The block type and block states of this block.",
                                $ref: "Block",
                            },
                            tileID: {
                                title: "Tile ID",
                                markdownDescription: "The tile ID of this block. This was used in older versions of Minecraft.",
                                type: "int",
                            },
                            time: {
                                title: "Time",
                                markdownDescription: "The tick that this block should be ticked.",
                                type: "long",
                            },
                            x: {
                                title: "X",
                                markdownDescription: "The world x-position of the block.",
                                type: "int",
                            },
                            y: {
                                title: "Y",
                                markdownDescription: "The world y-position of the block.",
                                type: "int",
                            },
                            z: {
                                title: "Z",
                                markdownDescription: "The world z-position of the block.",
                                type: "int",
                            },
                        },
                    },
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        PlayerClient: {
            id: "PlayerClient",
            title: "The PlayerClient schema.",
            markdownDescription: "The player client data.",
            type: "compound",
            required: ["MsaId", "SelfSignedId", "ServerId"],
            properties: {
                MsaId: {
                    type: "string",
                },
                SelfSignedId: {
                    type: "string",
                },
                ServerId: {
                    type: "string",
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        Portals: {
            id: "Portals",
            title: "The Portals schema.",
            markdownDescription: "The portals data.",
            type: "compound",
            properties: {
                data: {
                    type: "compound",
                    properties: {
                        PortalRecords: {
                            type: "list",
                            items: {
                                type: "compound",
                                properties: {
                                    DimId: {
                                        type: "int",
                                    },
                                    Span: {
                                        type: "byte",
                                    },
                                    TpX: {
                                        type: "int",
                                    },
                                    TpY: {
                                        type: "int",
                                    },
                                    TpZ: {
                                        type: "int",
                                    },
                                    Xa: {
                                        type: "byte",
                                    },
                                    Za: {
                                        type: "byte",
                                    },
                                },
                            },
                        },
                    },
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        PositionTrackingLastId: {
            id: "PositionTrackingLastId",
            title: "The PositionTrackingLastId schema.",
            markdownDescription: "The last ID for the lodestone compass position tracking database.",
            type: "compound",
            properties: {
                id: {
                    title: "ID",
                    markdownDescription: "The last ID for the lodestone compass position tracking database. It is stored in hex format. ex. 0x00000002",
                    type: "string",
                    pattern: "^0x[0-9a-fA-F]{8}$",
                    patternErrorMessage: "The last ID for the lodestone compass position tracking database must be in hex format. ex. 0x00000002",
                    default: {
                        type: "string",
                        value: "0x00000000",
                    },
                },
                version: {
                    title: "Version",
                    markdownDescription: "The version of the lodestone compass position tracking database, currently 1.",
                    type: "byte",
                    const: {
                        type: "byte",
                        value: 1,
                    },
                    default: {
                        type: "byte",
                        value: 1,
                    },
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        PositionTrackingDB: {
            id: "PositionTrackingDB",
            title: "The PositionTrackingDB schema.",
            markdownDescription: "An entry in the lodestone compass position tracking database.",
            type: "compound",
            properties: {
                dim: {
                    title: "Dimension",
                    markdownDescription: "The dimension of the lodestone the associated lodestone compass points to.",
                    type: "int",
                    markdownEnumDescriptions: ["Overworld", "Nether", "The End"],
                    enum: [
                        {
                            type: "int",
                            value: 0,
                        },
                        {
                            type: "int",
                            value: 1,
                        },
                        {
                            type: "int",
                            value: 2,
                        },
                    ],
                },
                id: {
                    title: "ID",
                    markdownDescription: "The last ID for the lodestone compass position tracking database. It is stored in hex format. ex. 0x00000002",
                    type: "string",
                    pattern: "^0x[0-9a-fA-F]{8}(?<!0x00000000)$",
                    patternErrorMessage: "The last ID for the lodestone compass position tracking database must be in hex format and may not be 0x00000000. ex. 0x00000002",
                    examples: [
                        {
                            type: "string",
                            value: "0x00000001",
                        },
                        {
                            type: "string",
                            value: "0x00000002",
                        },
                    ],
                },
                pos: {
                    title: "Position",
                    markdownDescription: "The location of the lodestone the associated lodestone compass points to. A Vector3.",
                    type: "list",
                    items: [
                        {
                            title: "x",
                            markdownDescription: "X component of this vector.",
                            type: "int",
                        },
                        {
                            title: "y",
                            markdownDescription: "Y component of this vector.",
                            type: "int",
                        },
                        {
                            title: "z",
                            markdownDescription: "Z component of this vector.",
                            type: "int",
                        },
                    ],
                },
                status: {
                    title: "Status",
                    markdownDescription: "UNDOCUMENTED. Currently observed value is 0, but there could be other possible values.",
                    type: "byte",
                },
                version: {
                    title: "Version",
                    markdownDescription: "The version of the lodestone compass position tracking database that this entry was saved in, currently 1.",
                    type: "byte",
                    const: {
                        type: "byte",
                        value: 1,
                    },
                    default: {
                        type: "byte",
                        value: 1,
                    },
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        RandomTicks: {
            id: "RandomTicks",
            title: "The RandomTicks schema.",
            markdownDescription: "The list of random ticks for a chunk.",
            type: "compound",
            // REVIEW: Check if RandomTicks was added before the PendingTicks tileID property was replaced with blockState to see if that property existed on RandomTicks at some point too, and if it did exist, mark blockState and currentTick as optional for RandomTicks.
            required: ["currentTick", "tickList"],
            properties: {
                currentTick: {
                    title: "Current Tick",
                    markdownDescription: "The current tick.",
                    type: "int",
                },
                tickList: {
                    title: "Tick List",
                    markdownDescription: "The list of random ticks.",
                    type: "list",
                    items: {
                        type: "compound",
                        required: ["blockState", "time", "x", "y", "z"],
                        properties: {
                            blockState: {
                                title: "Block State",
                                markdownDescription: "The block type and block states of this block.",
                                $ref: "Block",
                            },
                            time: {
                                title: "Time",
                                markdownDescription: "The tick that this block should be ticked.",
                                type: "long",
                            },
                            x: {
                                title: "X",
                                markdownDescription: "The world x-position of the block.",
                                type: "int",
                            },
                            y: {
                                title: "Y",
                                markdownDescription: "The world y-position of the block.",
                                type: "int",
                            },
                            z: {
                                title: "Z",
                                markdownDescription: "The world z-position of the block.",
                                type: "int",
                            },
                        },
                    },
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        SchedulerWT: {
            id: "SchedulerWT",
            title: "The SchedulerWT schema.",
            markdownDescription: "The schedulerWT data.",
            type: "compound",
            properties: {
                daysSinceLastWTSpawn: {
                    type: "int",
                },
                isSpawningWT: {
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                nextWTSpawnCheckTick: {
                    type: "long",
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        Scoreboard: {
            id: "Scoreboard",
            title: "The Scoreboard schema.",
            markdownDescription: "NBT structure of [scoreboard](https://minecraft.wiki/w/scoreboard)s.",
            type: "compound",
            required: ["DisplayObjectives", "Entries", "Objectives"],
            properties: {
                Criteria: {
                    markdownDescription: "UNKNOWN.",
                    type: "list",
                },
                DisplayObjectives: {
                    markdownDescription: "A  list of compound tags representing specific displayed objectives.",
                    type: "list",
                    items: {
                        markdownDescription: "A displayed objective.",
                        type: "compound",
                        required: ["Name", "ObjectiveName", "SortOrder"],
                        properties: {
                            Name: {
                                markdownDescription: "The **display slot** of this objective.",
                                type: "string",
                            },
                            ObjectiveName: {
                                markdownDescription: "The internal **name** of the objective displayed.",
                                type: "string",
                            },
                            SortOrder: {
                                markdownDescription: "The **sort order** of the objective displayed. 0 = `ascending`, 1 = `descending`. If not specified, or the **display slot** is `belowname`, 1 by default.",
                                type: "byte",
                                default: {
                                    type: "byte",
                                    value: 1,
                                },
                                markdownEnumDescriptions: ["ascending", "descending"],
                                enum: [
                                    { type: "byte", value: 0 },
                                    { type: "byte", value: 1 },
                                ],
                            },
                        },
                    },
                },
                Entries: {
                    markdownDescription: "A list of compound tags representing individual entities.",
                    type: "list",
                    items: {
                        markdownDescription: "An entity.",
                        type: "compound",
                        required: ["IdentityType", "ScoreboardId"],
                        properties: {
                            IdentityType: {
                                markdownDescription: "The identity type of this entity. 1 = Player, 2 = Entity, 3 = Fake player.",
                                type: "byte",
                                enum: [
                                    { type: "byte", value: 1 },
                                    { type: "byte", value: 2 },
                                    { type: "byte", value: 3 },
                                ],
                                markdownEnumDescriptions: ["Player", "Entity", "Fake player"],
                            },
                            FakePlayerName: {
                                markdownDescription: "Optional. The fake player's name.",
                                type: "string",
                            },
                            EntityId: {
                                markdownDescription: "Optional. The entity's Unique ID.",
                                type: "long",
                            },
                            PlayerId: {
                                markdownDescription: "Optional. The player's Unique ID.",
                                type: "long",
                            },
                            ScoreboardId: {
                                markdownDescription: "The numerical ID given to this entity on the scoreboard system, starting from 1.",
                                type: "long",
                            },
                        },
                    },
                },
                LastUniqueID: {
                    markdownDescription: "The numerical ID given to the last entity added on the scoreboard system.",
                    type: "long",
                },
                Objectives: {
                    markdownDescription: "A list of compound tags representing objectives.",
                    type: "list",
                    items: {
                        markdownDescription: "An objective.",
                        type: "compound",
                        required: ["Criteria", "DisplayName", "Name", "Scores"],
                        properties: {
                            Criteria: {
                                markdownDescription: "The **criterion** of this objective, currently, always `dummy`.",
                                type: "string",
                                default: {
                                    type: "string",
                                    value: "dummy",
                                },
                            },
                            DisplayName: {
                                markdownDescription: "The **display name** of this objective.",
                                type: "string",
                            },
                            Name: {
                                markdownDescription: "The internal **name** of this objective.",
                                type: "string",
                            },
                            Scores: {
                                markdownDescription: "A list of compound tags representing scores tracked on this objective.",
                                type: "list",
                                items: {
                                    markdownDescription: "A tracked entity with a score.",
                                    type: "compound",
                                    required: ["Score", "ScoreboardId"],
                                    properties: {
                                        Score: {
                                            markdownDescription: "The score this entity has on this objective.",
                                            type: "int",
                                        },
                                        ScoreboardId: {
                                            markdownDescription: "The numerical ID given to this entity on the scoreboard system.",
                                            type: "long",
                                        },
                                    },
                                },
                            },
                        },
                    },
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        StructureTemplate: {
            id: "StructureTemplate",
            title: "The StructureTemplate schema.",
            type: "compound",
            required: ["structure", "size", "structure_world_origin", "format_version"],
            properties: {
                structure: {
                    markdownDescription: "The structure data.",
                    type: "compound",
                    required: ["palette", "block_indices", "entities"],
                    properties: {
                        palette: {
                            markdownDescription: "The block palette.",
                            type: "compound",
                            required: ["default"],
                            properties: {
                                default: {
                                    markdownDescription: "The default block palette.",
                                    type: "compound",
                                    required: ["block_position_data", "block_palette"],
                                    properties: {
                                        block_position_data: {
                                            markdownDescription: "The block entity data.",
                                            type: "compound",
                                            patternProperties: {
                                                "[0-9]+": {
                                                    type: "compound",
                                                    required: ["block_entity_data"],
                                                    properties: {
                                                        block_entity_data: {
                                                            $ref: "BlockEntity",
                                                        },
                                                    },
                                                },
                                            },
                                        },
                                        block_palette: {
                                            markdownDescription: "The block palette.",
                                            type: "list",
                                            items: {
                                                markdownDescription: "The block palette array.",
                                                $ref: "Block",
                                            },
                                        },
                                    },
                                },
                            },
                        },
                        block_indices: {
                            markdownDescription: `The block indices.

These are two arrays of indices in the block palette.

The first layer is the block layer.

The second layer is the waterlog layer, even though it is mainly used for waterlogging, other blocks can be put here to,
which allows for putting two blocks in the same location, or creating ghost blocks (as blocks in this layer cannot be interacted with,
however when the corresponding block in the block layer is broken, this block gets moved to the block layer).`,
                            type: "list",
                            items: [
                                {
                                    title: "Block Layer",
                                    markdownDescription: "The block layer.",
                                    type: "list",
                                    items: {
                                        markdownDescription: "A block index in this layer.",
                                        type: "int",
                                    },
                                },
                                {
                                    title: "Waterlog Layer",
                                    markdownDescription: "The waterlog layer.",
                                    type: "list",
                                    items: {
                                        markdownDescription: "A block index in this layer.",
                                        type: "int",
                                    },
                                },
                            ],
                        },
                        entities: {
                            markdownDescription: "The list of entities in the structure.",
                            type: "list",
                            items: {
                                $ref: "ActorPrefix",
                            },
                        },
                    },
                },
                size: {
                    markdownDescription: "The size of the structure, as a tuple of 3 integers.",
                    type: "list",
                    items: [
                        {
                            title: "x",
                            markdownDescription: "The size of the x axis.",
                            type: "int",
                            minimum: 0,
                        },
                        {
                            title: "y",
                            markdownDescription: "The size of the y axis.",
                            type: "int",
                            minimum: 0,
                        },
                        {
                            title: "z",
                            markdownDescription: "The size of the z axis.",
                            type: "int",
                            minimum: 0,
                        },
                    ],
                },
                structure_world_origin: {
                    markdownDescription: "The world origin of the structure, as a tuple of 3 integers.\n\nThis is used for entity and block entity data, to get relative positions.",
                    type: "list",
                    items: [
                        {
                            title: "x",
                            markdownDescription: "The x coordinate.",
                            type: "int",
                        },
                        {
                            title: "y",
                            markdownDescription: "The y coordinate.",
                            type: "int",
                        },
                        {
                            title: "z",
                            markdownDescription: "The z coordinate.",
                            type: "int",
                        },
                    ],
                },
                /**
                 * The format version of the structure.
                 */
                format_version: {
                    markdownDescription: "The format version of the structure.",
                    type: "int",
                    enum: [
                        {
                            type: "int",
                            value: 1,
                        },
                    ],
                },
            },
        },
        // NOTE: Verified.
        TickingArea: {
            id: "TickingArea",
            title: "The TickingArea schema.",
            markdownDescription: "The tickingarea data.",
            type: "compound",
            required: ["Dimension", "IsCircle", "MaxX", "MaxZ", "MinX", "MinZ", "Name"],
            properties: {
                Dimension: {
                    type: "int",
                },
                EntityId: {
                    type: "long",
                },
                IsAlwaysActive: {
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                IsCircle: {
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                MaxDistToPlayers: {
                    type: "float",
                },
                MaxX: {
                    type: "int",
                },
                MaxZ: {
                    type: "int",
                },
                MinX: {
                    type: "int",
                },
                MinZ: {
                    type: "int",
                },
                Name: {
                    type: "string",
                    default: {
                        type: "string",
                        value: "",
                    },
                },
                Preload: {
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        VillageDwellers: {
            id: "VillageDwellers",
            title: "The VillageDwellers schema.",
            markdownDescription: "The village dwellers data.",
            type: "compound",
            required: ["Dwellers"],
            properties: {
                Dwellers: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "list",
                    items: {
                        markdownDescription: "UNDOCUMENTED.",
                        type: "compound",
                        properties: {
                            actors: {
                                markdownDescription: "UNDOCUMENTED.",
                                type: "list",
                                items: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "compound",
                                    required: ["ID", "last_saved_pos", "TS"],
                                    properties: {
                                        ID: {
                                            markdownDescription: "UNDOCUMENTED.",
                                            type: "long",
                                        },
                                        last_saved_pos: {
                                            markdownDescription: "UNDOCUMENTED.",
                                            type: "list",
                                            items: [
                                                {
                                                    title: "x",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                {
                                                    title: "y",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                                {
                                                    title: "z",
                                                    markdownDescription: "UNDOCUMENTED.",
                                                    type: "int",
                                                },
                                            ],
                                        },
                                        TS: {
                                            markdownDescription: "UNDOCUMENTED.",
                                            type: "long",
                                        },
                                        last_worked: {
                                            markdownDescription: "UNDOCUMENTED.",
                                            type: "long",
                                        },
                                    },
                                },
                            },
                        },
                    },
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        VillageInfo: {
            id: "VillageInfo",
            title: "The VillageInfo schema.",
            markdownDescription: "The village info data.",
            type: "compound",
            required: [
                "BDTime",
                "GDTime",
                "Initialized",
                "MTick",
                "PDTick",
                "RX0",
                "RX1",
                "RY0",
                "RY1",
                "RZ0",
                "RZ1",
                "Tick",
                "Version",
                "X0",
                "X1",
                "Y0",
                "Y1",
                "Z0",
                "Z1",
            ],
            properties: {
                BDTime: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "long",
                },
                GDTime: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "long",
                },
                Initialized: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                    markdownEnumDescriptions: ["false", "true"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                    ],
                },
                MTick: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "long",
                },
                PDTick: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "long",
                },
                RX0: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                RX1: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                RY0: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                RY1: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                RZ0: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                RZ1: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                Tick: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "long",
                },
                Version: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
                X0: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                X1: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                Y0: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                Y1: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                Z0: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                Z1: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        VillagePlayers: {
            id: "VillagePlayers",
            title: "The VillagePlayers schema.",
            markdownDescription: "The village players data.",
            type: "compound",
            required: ["Players"],
            properties: {
                Players: {
                    markdownDescription: "UNKNOWN.",
                    type: "list",
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        VillagePOI: {
            id: "VillagePOI",
            title: "The VillagePOI schema.",
            markdownDescription: "The village POIs data.",
            type: "compound",
            required: ["POI"],
            properties: {
                POI: {
                    type: "list",
                    items: {
                        type: "compound",
                        required: ["VillagerID", "instances"],
                        properties: {
                            VillagerID: {
                                type: "long",
                            },
                            instances: {
                                type: "list",
                                items: {
                                    type: "compound",
                                    required: [
                                        "Capacity",
                                        "InitEvent",
                                        "Name",
                                        "OwnerCount",
                                        "Radius",
                                        "Skip",
                                        "SoundEvent",
                                        "Type",
                                        "UseAABB",
                                        "Weight",
                                        "X",
                                        "Y",
                                        "Z",
                                    ],
                                    properties: {
                                        Capacity: {
                                            type: "long",
                                        },
                                        InitEvent: {
                                            type: "string",
                                        },
                                        Name: {
                                            type: "string",
                                        },
                                        OwnerCount: {
                                            type: "long",
                                        },
                                        Radius: {
                                            type: "float",
                                        },
                                        Skip: {
                                            type: "byte",
                                        },
                                        SoundEvent: {
                                            type: "string",
                                        },
                                        Type: {
                                            type: "int",
                                        },
                                        UseAABB: {
                                            type: "byte",
                                        },
                                        Weight: {
                                            type: "long",
                                        },
                                        X: {
                                            type: "int",
                                        },
                                        Y: {
                                            type: "int",
                                        },
                                        Z: {
                                            type: "int",
                                        },
                                    },
                                },
                            },
                        },
                    },
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        VillageRaid: {
            id: "VillageRaid",
            title: "The VillageRaid schema.",
            markdownDescription: "The village raid data.",
            type: "compound",
            required: ["Raid"],
            properties: {
                Raid: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "compound",
                    required: [
                        "GameTick",
                        "GroupNum",
                        "NumGroups",
                        "NumRaiders",
                        "Raiders",
                        "SpawnFails",
                        "SpawnX",
                        "SpawnY",
                        "SpawnZ",
                        "State",
                        "Status",
                        "Ticks",
                        "TotalMaxHealth",
                    ],
                    properties: {
                        GameTick: {
                            markdownDescription: "Seems to be the tick the raid data was last updated.",
                            type: "long",
                        },
                        GroupNum: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "byte",
                        },
                        NumGroups: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "byte",
                        },
                        NumRaiders: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "byte",
                        },
                        Raiders: {
                            markdownDescription: "The list of UUIDs of the raiders.",
                            type: "list",
                            items: {
                                markdownDescription: "The UUID of a raider.",
                                type: "long",
                            },
                        },
                        SpawnFails: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "byte",
                        },
                        SpawnX: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "float",
                        },
                        SpawnY: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "float",
                        },
                        SpawnZ: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "float",
                        },
                        State: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "int",
                        },
                        Status: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "int",
                        },
                        Ticks: {
                            markdownDescription: "Seems to be the number of ticks since the raid started (not sure if it is only counting while the raid is in loaded chunks or not).",
                            type: "long",
                        },
                        TotalMaxHealth: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "float",
                        },
                    },
                },
            },
            $fragment: false,
        },
        // NOTE: Verified.
        WorldClocks: {
            id: "WorldClocks",
            title: "The WorldClocks schema.",
            markdownDescription: "UNDOCUMENTED.",
            type: "compound",
            required: ["clocks"],
            properties: {
                clocks: {
                    title: "Clocks",
                    markdownDescription: "UNDOCMENTED.",
                    type: "list",
                    items: {
                        title: "Clock",
                        markdownDescription: "UNDOCUMENTED.",
                        type: "compound",
                        required: ["IsPaused", "Name", "Time"],
                        properties: {
                            IsPaused: {
                                title: "Is Paused",
                                markdownDescription: "UNDOCUMENTED.",
                                type: "byte",
                                markdownEnumDescriptions: ["false", "true"],
                                enum: [
                                    { type: "byte", value: 0 },
                                    { type: "byte", value: 1 },
                                ],
                            },
                            Name: {
                                title: "Name",
                                markdownDescription: "UNDOCUMENTED.",
                                type: "string",
                                examples: dimensions.map((v) => ({ type: "string", value: `minecraft:${v}` })),
                            },
                            Time: {
                                title: "Time",
                                markdownDescription: "UNDOCUMENTED.",
                                type: "int",
                            },
                        },
                    },
                },
            },
        },
        //#endregion
        //#region Schema Fragments
        Abilities: {
            id: "Abilities",
            markdownDescription: "NBT structure of players' ability info.",
            type: "compound",
            required: ["abilities"],
            properties: {
                abilities: {
                    markdownDescription: "The player's ability setting.",
                    type: "compound",
                    required: [
                        "attackmobs",
                        "attackplayers",
                        "build",
                        "doorsandswitches",
                        "flying",
                        "flySpeed",
                        "instabuild",
                        "invulnerable",
                        "lightning",
                        "mayfly",
                        "mine",
                        "mute",
                        "noclip",
                        "op",
                        "opencontainers",
                        "permissionsLevel",
                        "playerPermissionsLevel",
                        "teleport",
                        "walkSpeed",
                        "worldbuilder",
                    ],
                    properties: {
                        attackmobs: {
                            markdownDescription: "1 or 0 (true/false) - true if the player can attack mobs.",
                            type: "byte",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        attackplayers: {
                            markdownDescription: "1 or 0 (true/false) - true if the player can attack other players.",
                            type: "byte",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        build: {
                            markdownDescription: "1 or 0 (true/false) - true if the player can place blocks.",
                            type: "byte",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        doorsandswitches: {
                            markdownDescription: "1 or 0 (true/false) - true if the player is able to interact with redstone components.",
                            type: "byte",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        flying: {
                            markdownDescription: "1 or 0 (true/false) - true if the player is currently flying.",
                            type: "byte",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        flySpeed: {
                            markdownDescription: "The flying speed, always 0.05.",
                            type: "float",
                        },
                        instabuild: {
                            markdownDescription: "1 or 0 (true/false) - true if the player can instantly destroy blocks.",
                            type: "byte",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        invulnerable: {
                            markdownDescription: "1 or 0 (true/false) - true if the player is immune to all damage and harmful effects.",
                            type: "byte",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        lightning: {
                            markdownDescription: "1 or 0 (true/false) - true if the player was struck by lightning.",
                            type: "byte",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        mayfly: {
                            markdownDescription: "1 or 0 (true/false) - true if the player can fly.",
                            type: "byte",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        mine: {
                            markdownDescription: "1 or 0 (true/false) - true if the player can destroy blocks.",
                            type: "byte",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        mute: {
                            markdownDescription: "1 or 0 (true/false) - true if the player messages cannot be seen by other players.",
                            type: "byte",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        noclip: {
                            markdownDescription: "1 or 0 (true/false) - true if the player can phase through blocks.",
                            type: "byte",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        op: {
                            markdownDescription: "1 or 0 (true/false) - true if the player has operator commands.",
                            type: "byte",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        opencontainers: {
                            markdownDescription: "1 or 0 (true/false) - true if the player is able to open containers.",
                            type: "byte",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        permissionsLevel: {
                            markdownDescription: "What permissions a player will default to, when joining a world.",
                            type: "int",
                        },
                        playerPermissionsLevel: {
                            markdownDescription: "What permissions a player has.",
                            type: "int",
                        },
                        teleport: {
                            markdownDescription: "1 or 0 (true/false) - true if the player is allowed to teleport.",
                            type: "byte",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        walkSpeed: {
                            markdownDescription: "The walking speed, always 0.1.",
                            type: "float",
                        },
                        worldbuilder: {
                            markdownDescription: "1 or 0 (true/false) - true if the player is a world builder.",
                            type: "byte",
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                    },
                },
            },
            $fragment: true,
        },
        Attribute: {
            id: "Attribute",
            markdownDescription: "NBT structure of an [attribute](https://minecraft.wiki/w/attribute).",
            type: "compound",
            required: ["Base", "Current", "DefaultMax", "DefaultMin", "Max", "Min", "Name"],
            properties: {
                Base: {
                    markdownDescription: "The base value of this Attribute.",
                    type: "float",
                },
                Current: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "float",
                },
                DefaultMax: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "float",
                },
                DefaultMin: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "float",
                },
                Max: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "float",
                },
                Min: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "float",
                },
                Modifiers: {
                    markdownDescription: "(May not exist) List of [Modifiers](https://minecraft.wiki/w/Attribute#Modifiers).",
                    type: "list",
                    items: {
                        markdownDescription: "An individual Modifier.",
                        type: "compound",
                        $ref: "AttributeModifier",
                    },
                },
                Name: {
                    markdownDescription: "The name of this Attribute.",
                    type: "string",
                },
                TemporalBuffs: {
                    markdownDescription: "(May not exist) UNDOCUMENTED.",
                    type: "list",
                    items: [
                        {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "float",
                        },
                        {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "int",
                        },
                        {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "int",
                        },
                        {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "int",
                        },
                    ],
                },
            },
            $fragment: true,
        },
        Attributes: {
            id: "Attributes",
            markdownDescription: "List of [attribute](https://minecraft.wiki/w/attribute)s.",
            type: "list",
            items: {
                markdownDescription: "An attribute.",
                type: "compound",
                $ref: "Attribute",
            },
            $fragment: true,
        },
        AttributeModifier: {
            id: "AttributeModifier",
            markdownDescription: "NBT structure of an attribute [modifier](https://minecraft.wiki/w/modifier).",
            type: "compound",
            required: ["Amount", "Name", "Operand", "Operation", "UUIDLeast", "UUIDMost"],
            properties: {
                Amount: {
                    markdownDescription: "The amount by which this Modifier modifies the Base value in calculations.",
                    type: "float",
                },
                Name: {
                    markdownDescription: "The Modifier's name.",
                    type: "string",
                },
                Operand: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                Operation: {
                    markdownDescription: "Defines the operation this Modifier executes on the Attribute's Base value. 0: Increment X by Amount, 1: Increment Y by X * Amount, 2: Y = Y * (1 + Amount) (equivalent to Increment Y by Y * Amount). *needs testing*",
                    type: "int",
                },
                UUIDLeast: {
                    markdownDescription: "This modifier's UUID Least.",
                    type: "long",
                },
                UUIDMost: {
                    markdownDescription: "This modifier's UUID Most.",
                    type: "long",
                },
            },
            $fragment: true,
        },
        Block: {
            id: "Block",
            title: "The Block schema.",
            markdownDescription: "NBT structure of a [block](https://minecraft.wiki/w/block).",
            type: "compound",
            required: ["name", "states", "version"],
            properties: {
                name: {
                    markdownDescription: "The namespaced ID of this block.",
                    type: "string",
                },
                states: {
                    markdownDescription: "The block states of the block.",
                    type: "compound",
                    additionalProperties: true,
                },
                version: {
                    markdownDescription: "The data version.",
                    type: "int",
                    examples: [
                        { type: "int", value: 18163713 },
                        { type: "int", value: 18168865 },
                    ],
                },
            },
            $fragment: true,
        },
        CommandBlock: {
            id: "CommandBlock",
            markdownDescription: "NBT structure of [command block](https://minecraft.wiki/w/command_block) and [minecart with command block](https://minecraft.wiki/w/minecart_with_command_block).",
            type: "compound",
            required: [
                "Command",
                "CustomName",
                "ExecuteOnFirstTick",
                "LastExecution",
                "LastOutput",
                "LastOutputParams",
                "SuccessCount",
                "TickDelay",
                "TrackOutput",
                "Version",
            ],
            properties: {
                Command: {
                    markdownDescription: "The command entered into the command block.",
                    type: "string",
                },
                CustomName: {
                    markdownDescription: "The custom name or hover text of this command block.",
                    type: "string",
                },
                ExecuteOnFirstTick: {
                    markdownDescription: "1 or 0 (true/false) - true if it executes on the first tick once saved or activated.",
                    type: "byte",
                },
                LastExecution: {
                    markdownDescription: "Stores the time when a command block was last executed.",
                    type: "long",
                },
                LastOutput: {
                    markdownDescription: "The translation key of the output's last line generated by the command block. Still stored even if the [gamerule](https://minecraft.wiki/w/gamerule) commandBlockOutput is false. Appears in the command GUI.",
                    type: "string",
                },
                LastOutputParams: {
                    markdownDescription: "The params for the output's translation key.",
                    type: "list",
                    items: {
                        markdownDescription: "A param.",
                        type: "string",
                    },
                },
                SuccessCount: {
                    markdownDescription: "Represents the strength of the analog signal output by redstone comparators attached to this command block.",
                    type: "int",
                },
                TickDelay: {
                    markdownDescription: "The delay between each execution.",
                    type: "int",
                },
                TrackOutput: {
                    markdownDescription: '1 or 0 (true/false) - true if the `LastOutput` is stored. Can be toggled in the GUI by clicking a button near the "Previous Output" textbox.',
                    type: "byte",
                },
                Version: {
                    markdownDescription: "The data version.",
                    type: "int",
                },
            },
            $fragment: true,
        },
        FireworkExplosion: {
            id: "FireworkExplosion",
            markdownDescription: "NBT structure of [firework](https://minecraft.wiki/w/firework) and [firework star](https://minecraft.wiki/w/firework_star).",
            type: "compound",
            required: ["FireworkColor", "FireworkFade", "FireworkFlicker", "FireworkTrail", "FireworkType"],
            properties: {
                FireworkColor: {
                    markdownDescription: "Array of byte values corresponding to the primary colors of this firework's explosion.",
                    type: "byteArray",
                },
                FireworkFade: {
                    markdownDescription: "Array of byte values corresponding to the fading colors of this firework's explosion.",
                    type: "byteArray",
                },
                FireworkFlicker: {
                    markdownDescription: "1 or 0 (true/false) - true if this explosion has the twinkle effect (glowstone dust).",
                    type: "byte",
                },
                FireworkTrail: {
                    markdownDescription: "1 or 0 (true/false) - true if this explosion has the trail effect (diamond).",
                    type: "byte",
                },
                FireworkType: {
                    markdownDescription: "The shape of this firework's explosion. 0 = Small Ball, 1 = Large Ball, 2 = Star-shaped, 3 = Creeper-shaped, and 4 = Burst. *needs testing*",
                    type: "byte",
                },
            },
            $fragment: true,
        },
        MobEffect: {
            id: "MobEffect",
            markdownDescription: "NBT structure of a [status effect](https://minecraft.wiki/w/status_effect).",
            type: "compound",
            required: [
                "Ambient",
                "Amplifier",
                "DisplayOnScreenTextureAnimation",
                "Duration",
                "DurationEasy",
                "DurationHard",
                "DurationNormal",
                "Id",
                "ShowParticles",
            ],
            properties: {
                Ambient: {
                    markdownDescription: "1 or 0 (true/false) - true if this effect is provided by a beacon and therefore should be less intrusive on screen.",
                    type: "byte",
                },
                Amplifier: {
                    markdownDescription: "The potion effect level. 0 is level 1.",
                    type: "byte",
                },
                DisplayOnScreenTextureAnimation: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
                Duration: {
                    markdownDescription: "The number of ticks before the effect wears off.",
                    type: "int",
                },
                DurationEasy: {
                    markdownDescription: "Duration for Easy mode.",
                    type: "int",
                },
                DurationHard: {
                    markdownDescription: "Duration for Hard mode.",
                    type: "int",
                },
                DurationNormal: {
                    markdownDescription: "Duration for Normal mode.",
                    type: "int",
                },
                FactorCalculationData: {
                    type: "compound",
                    properties: {
                        change_timestamp: {
                            type: "int",
                        },
                        factor_current: {
                            type: "float",
                        },
                        factor_previous: {
                            type: "float",
                        },
                        factor_start: {
                            type: "float",
                        },
                        factor_target: {
                            type: "float",
                        },
                        had_applied: {
                            type: "byte",
                        },
                        had_last_tick: {
                            type: "byte",
                        },
                        padding_duration: {
                            type: "int",
                        },
                    },
                },
                Id: {
                    markdownDescription: "The numerical effect ID.",
                    type: "byte",
                },
                ShowParticles: {
                    markdownDescription: "1 or 0 (true/false) - true if particles are shown.",
                    type: "byte",
                },
            },
            $fragment: true,
        },
        MonsterSpawner: {
            id: "MonsterSpawner",
            markdownDescription: "NBT structure of a [monster spawner](https://minecraft.wiki/w/monster_spawner).",
            type: "compound",
            required: [
                "Delay",
                "DisplayEntityHeight",
                "DisplayEntityScale",
                "DisplayEntityWidth",
                "EntityIdentifier",
                "MaxNearbyEntities",
                "MaxSpawnDelay",
                "MinSpawnDelay",
                "RequiredPlayerRange",
                "SpawnCount",
                "SpawnRange",
            ],
            properties: {
                Delay: {
                    markdownDescription: "Ticks until next spawn. If 0, it spawns immediately when a player enters its range.",
                    type: "short",
                },
                DisplayEntityHeight: {
                    markdownDescription: "The height of entity model that displayed in the block.",
                    type: "float",
                },
                DisplayEntityScale: {
                    markdownDescription: "The scale of entity model that displayed in the block.",
                    type: "float",
                },
                DisplayEntityWidth: {
                    markdownDescription: "The width of entity model that displayed in the block.",
                    type: "float",
                },
                EntityIdentifier: {
                    markdownDescription: "The id of the entity to be summoned.",
                    type: "string",
                },
                MaxNearbyEntities: {
                    markdownDescription: "The maximum number of nearby (within a box of `SpawnRange`*2+1 × `SpawnRange`*2+1 × 8 centered around the spawner block *needs testing*) entities whose IDs match this spawner's entity ID.",
                    type: "short",
                },
                MaxSpawnDelay: {
                    markdownDescription: "The maximum random delay for the next spawn delay.",
                    type: "short",
                },
                MinSpawnDelay: {
                    markdownDescription: "The minimum random delay for the next spawn delay.",
                    type: "short",
                },
                RequiredPlayerRange: {
                    markdownDescription: "Overrides the block radius of the sphere of activation by players for this spawner.",
                    type: "short",
                },
                SpawnCount: {
                    markdownDescription: "How many mobs to attempt to spawn each time.",
                    type: "short",
                },
                SpawnData: {
                    markdownDescription: "(May not exist) Contains tags to copy to the next spawned entity(s) after spawning.",
                    type: "compound",
                    required: ["Properties", "TypeId", "Weight"],
                    properties: {
                        Properties: {
                            markdownDescription: "UNKNOWN.",
                            type: "compound",
                        },
                        TypeId: {
                            markdownDescription: "The entity's namespaced ID.",
                            type: "string",
                        },
                        Weight: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "int",
                        },
                    },
                },
                SpawnPotentials: {
                    markdownDescription: "(May not exist) List of possible entities to spawn.",
                    type: "list",
                    items: {
                        markdownDescription: "A potential future spawn.",
                        type: "compound",
                        required: ["Properties", "TypeId", "Weight"],
                        properties: {
                            Properties: {
                                markdownDescription: "UNKNOWN.",
                                type: "compound",
                            },
                            TypeId: {
                                markdownDescription: "The entity's namespaced ID.",
                                type: "string",
                            },
                            Weight: {
                                markdownDescription: "The chance that this spawn gets picked in comparison to other spawn weights. Must be positive and at least 1.",
                                type: "int",
                            },
                        },
                    },
                },
                SpawnRange: {
                    markdownDescription: "The radius around which the spawner attempts to place mobs randomly. The spawn area is square, includes the block the spawner is in, and is centered around the spawner's x,z coordinates - not the spawner itself. *needs testing* Default value is 4.",
                    type: "short",
                },
            },
            $fragment: true,
        },
        //#endregion
        //#region Entity NBT Schemas
        Entity_Minecart: {
            id: "Entity_Minecart",
            markdownDescription: "Minecart entities include.",
            type: "compound",
            required: ["CustomDisplayTile"],
            properties: {
                CustomDisplayTile: {
                    markdownDescription: "1 or 0 (true/false) - (may not exist) if is displayed the custom tile in this minecart.",
                    type: "byte",
                },
                DisplayBlock: {
                    markdownDescription: "(May not exist) The custom block in the minecart.",
                    type: "compound",
                    $ref: "Block",
                },
                DisplayOffset: {
                    markdownDescription: "(May not exist) The offset of the block displayed in the Minecart in pixels. Positive values move the block upwards, while negative values move it downwards. A value of 16 moves the block up by exactly one multiple of its height. *needs testing*",
                    type: "int",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Villagers: {
            id: "Entity_Villagers",
            markdownDescription: "Villager entities include.",
            type: "compound",
            required: ["Willing"],
            properties: {
                Willing: {
                    markdownDescription: "1 or 0 (true/false) - true if the villager is willing to mate. Becomes true after certain trades (those that would cause offers to be refreshed), and false after mating.",
                    type: "byte",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Monster: {
            id: "Entity_Monster",
            markdownDescription: "Monster entities include.",
            type: "compound",
            required: ["SpawnedByNight"],
            properties: {
                SpawnedByNight: {
                    markdownDescription: "1 or 0 (true/false) - true if is spawned by night.",
                    type: "byte",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_HumanoidMonster: {
            id: "Entity_HumanoidMonster",
            markdownDescription: "Humanoid monster entities include.",
            type: "compound",
            properties: {
                ItemInHand: {
                    markdownDescription: "(May not exist) The items in the entity's hand.",
                    type: "compound",
                    $ref: "Item_ItemStack",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Mob: {
            id: "Entity_Mob",
            markdownDescription: "Mob entities include.",
            type: "compound",
            required: [
                "Air",
                "Armor",
                "AttackTime",
                "Attributes",
                "boundX",
                "boundY",
                "boundZ",
                "canPickupItems",
                "Dead",
                "DeathTime",
                "hasBoundOrigin",
                "hasSetCanPickupItems",
                "HurtTime",
                "LeasherID",
                "limitedLife",
                "Mainhand",
                "NaturalSpawn",
                "Offhand",
                "Surface",
                "TargetID",
            ],
            properties: {
                ActiveEffects: {
                    markdownDescription: "(May not exist) The list of potion effects on this mob.",
                    type: "list",
                    items: {
                        markdownDescription: "An effect.",
                        type: "compound",
                        $ref: "MobEffect",
                    },
                },
                Air: {
                    markdownDescription: "How much air the living entity has, in ticks.",
                    type: "short",
                },
                Armor: {
                    markdownDescription: "The list of items the mob is wearing as armor.",
                    type: "list",
                    items: [
                        {
                            markdownDescription: "The item on the head.",
                            type: "compound",
                            $ref: "Item_ItemStack",
                        },
                        {
                            markdownDescription: "The item on the chest.",
                            type: "compound",
                            $ref: "Item_ItemStack",
                        },
                        {
                            markdownDescription: "The item on the legs.",
                            type: "compound",
                            $ref: "Item_ItemStack",
                        },
                        {
                            markdownDescription: "The item on the feets.",
                            type: "compound",
                            $ref: "Item_ItemStack",
                        },
                    ],
                },
                AttackTime: {
                    markdownDescription: "Number of ticks the mob attacks for. 0 when not attacking.",
                    type: "short",
                },
                Attributes: {
                    markdownDescription: "A list of [Attribute](https://minecraft.wiki/w/Attribute)s for this mob. These are used for many purposes in internal calculations. Valid Attributes for a given mob are listed in the [main article](https://minecraft.wiki/w/Attribute).",
                    type: "list",
                    items: {
                        markdownDescription: "An Attribute.",
                        type: "compound",
                        $ref: "Attribute",
                    },
                },
                BodyRot: {
                    markdownDescription: "(May not exist) UNDOCUMENTED.",
                    type: "float",
                },
                boundX: {
                    markdownDescription: "X of the bound origin.",
                    type: "int",
                },
                boundY: {
                    markdownDescription: "Y of the bound origin.",
                    type: "int",
                },
                boundZ: {
                    markdownDescription: "Z of the bound origin.",
                    type: "int",
                },
                canPickupItems: {
                    markdownDescription: "1 or 0 (true/false) - true if this entity can pick up items.",
                    type: "byte",
                },
                Dead: {
                    markdownDescription: "1 or 0 (true/false) - true if dead.",
                    type: "byte",
                },
                DeathTime: {
                    markdownDescription: "Number of ticks the mob has been dead for. Controls death animations. 0 when alive.",
                    type: "short",
                },
                hasBoundOrigin: {
                    markdownDescription: "1 or 0 (true/false) - if this mob has bound origin. Only *needs testing* effects [Vex](https://minecraft.wiki/w/Vex). When a vex is idle, it wanders, selecting air blocks from within a 15×11×15 *needs testing* cuboid range centered at BoundX, BoundY, BoundZ. when it summoned the vex, this value is set to true, and the central spot is the location of the evoker. Or if an evoker was not involved, this value is false.",
                    type: "byte",
                },
                hasSetCanPickupItems: {
                    markdownDescription: "1 or 0 (true/false) - true if `canPickupItems` has been set by the game.",
                    type: "byte",
                },
                HurtTime: {
                    markdownDescription: "Number of ticks the mob turns red for after being hit. 0 when not recently hit.",
                    type: "short",
                },
                LeasherID: {
                    markdownDescription: "The Unique ID of an entity that is leashing it with a lead. Set to -1 if there's no leasher.",
                    type: "long",
                },
                limitedLife: {
                    markdownDescription: "The left time in ticks until this entity disapears. Only *needs testing* effects [Evoker Fang](https://minecraft.wiki/w/Evoker_Fang)s. For other entities, it is set to 0.",
                    type: "long",
                },
                Mainhand: {
                    markdownDescription: "The item being held in the mob's main hand.",
                    type: "list",
                    items: {
                        markdownDescription: "The item.",
                        type: "compound",
                        $ref: "Item_ItemStack",
                    },
                },
                NaturalSpawn: {
                    markdownDescription: "1 or 0 (true/false) - true if it is naturally spawned.",
                    type: "byte",
                },
                Offhand: {
                    markdownDescription: "The item being held in the mob's off hand.",
                    type: "list",
                    items: {
                        markdownDescription: "The item.",
                        type: "compound",
                        $ref: "Item_ItemStack",
                    },
                },
                persistingOffers: {
                    markdownDescription: "(May not exist) UNKNOWN.",
                    type: "compound",
                },
                persistingRiches: {
                    markdownDescription: "(May not exist) UNDOCUMENTED.",
                    type: "int",
                },
                Surface: {
                    markdownDescription: "1 or 0 (true/false) - true if it is naturally spawned on the surface.",
                    type: "byte",
                },
                TargetCaptainID: {
                    markdownDescription: "(May not exist) The Unique ID of a captain to follow. Used by pillager and vindicator.",
                    type: "long",
                },
                TargetID: {
                    markdownDescription: "The Unique ID of an entity that this entity is angry at.",
                    type: "long",
                },
                TradeExperience: {
                    markdownDescription: "(May not exist) Trade experiences of this trader entity.",
                    type: "int",
                },
                TradeTier: {
                    markdownDescription: "(May not exist) Trade tier of this trader entity.",
                    type: "int",
                },
                WantsToBeJockey: {
                    markdownDescription: "(May not exist) unknown.",
                    type: "byte",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_AbstractArrow: {
            id: "Entity_AbstractArrow",
            markdownDescription: "Abstract arrow entities include.",
            type: "compound",
            required: ["isCreative", "OwnerID", "player"],
            properties: {
                isCreative: {
                    markdownDescription: "1 or 0 (true/false) - true if its owner is a player in Creative mode.",
                    type: "byte",
                },
                OwnerID: {
                    markdownDescription: "The Unique ID of the entity this projectile was thrown by. Set to -1 if it has no owner.",
                    type: "long",
                },
                player: {
                    markdownDescription: "1 or 0 (true/false) - true if its owner is a player.",
                    type: "byte",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Throwable: {
            id: "Entity_Throwable",
            markdownDescription: "Throwable entities include.",
            type: "compound",
            required: ["inGround", "OwnerID", "shake"],
            properties: {
                inGround: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
                OwnerID: {
                    markdownDescription: "The Unique ID of the entity this projectile was thrown by.",
                    type: "long",
                },
                shake: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Allay: {
            id: "Entity_Allay",
            markdownDescription: "Additional fields for [allay](https://minecraft.wiki/w/allay).",
            type: "compound",
            required: ["AllayDuplicationCooldown", "VibrationListener"],
            properties: {
                AllayDuplicationCooldown: {
                    markdownDescription: "The allay's duplication cooldown in ticks. This is set to 6000 ticks (5 minutes) when the allay duplicates.",
                    type: "long",
                },
                VibrationListener: {
                    markdownDescription: "The vibration event listener of this allay.",
                    type: "compound",
                    required: ["selector"],
                    properties: {
                        event: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "int",
                        },
                        pending: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "compound",
                            required: ["distance", "source", "vibration", "x", "y", "z"],
                            properties: {
                                distance: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "float",
                                },
                                source: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "long",
                                },
                                vibration: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "int",
                                },
                                x: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "int",
                                },
                                y: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "int",
                                },
                                z: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "int",
                                },
                            },
                        },
                        selector: {
                            markdownDescription: "UNKNOWN.",
                            type: "compound",
                        },
                        ticks: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "int",
                        },
                    },
                },
            },
            allOf: [
                {
                    $ref: "Component_Inventory",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_AreaEffectCloud: {
            id: "Entity_AreaEffectCloud",
            markdownDescription: "Additional fields for [area effect cloud](https://minecraft.wiki/w/area_effect_cloud).",
            type: "compound",
            required: [
                "Duration",
                "DurationOnUse",
                "InitialRadius",
                "mobEffects",
                "OwnerId",
                "ParticleColor",
                "ParticleId",
                "PickupCount",
                "PotionId",
                "Radius",
                "RadiusChangeOnPickup",
                "RadiusOnUse",
                "RadiusPerTick",
                "ReapplicationDelay",
                "SpawnTick",
            ],
            properties: {
                Duration: {
                    markdownDescription: "The maximum age of the field.",
                    type: "int",
                },
                DurationOnUse: {
                    markdownDescription: "The amount the duration of the field changes upon applying the effect.",
                    type: "int",
                },
                InitialRadius: {
                    markdownDescription: "The field's initial radius.",
                    type: "float",
                },
                mobEffects: {
                    markdownDescription: "A list of the applied [effect](https://minecraft.wiki/w/effect)s.",
                    type: "list",
                    items: {
                        $ref: "MobEffect",
                    },
                },
                OwnerId: {
                    markdownDescription: "The Unique ID of the entity who created the cloud. If it has no owner, defaults to -1.",
                    type: "long",
                },
                ParticleColor: {
                    markdownDescription: "The color of the particles.",
                    type: "int",
                },
                ParticleId: {
                    markdownDescription: "The particles displayed by the field.",
                    type: "int",
                },
                PickupCount: {
                    markdownDescription: "How many [dragon's breath](https://minecraft.wiki/w/dragon's_breath) can be picked up.",
                    type: "int",
                },
                PotionId: {
                    markdownDescription: "The name of the default potion effect. See [potion data values](https://minecraft.wiki/w/potion#Item_data) for valid IDs.",
                    type: "short",
                },
                Radius: {
                    markdownDescription: "The field's current radius.",
                    type: "float",
                },
                RadiusChangeOnPickup: {
                    markdownDescription: "The amount the radius changes when picked up by a glass bottle.",
                    type: "float",
                },
                RadiusOnUse: {
                    markdownDescription: "The amount the radius changes upon applying the effect. Normally negative.",
                    type: "float",
                },
                RadiusPerTick: {
                    markdownDescription: "The amount the radius changes per tick. Normally negative.",
                    type: "float",
                },
                ReapplicationDelay: {
                    markdownDescription: "The number of ticks before reapplying the effect.",
                    type: "int",
                },
                SpawnTick: {
                    markdownDescription: "The time when it was spawned.",
                    type: "long",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Armadillo: {
            id: "Entity_Armadillo",
            markdownDescription: "Additional fields for [armadillo](https://minecraft.wiki/w/armadillo).",
            type: "compound",
            required: ["properties"],
            properties: {
                properties: {
                    markdownDescription: "The armadillo `properties`.",
                    type: "compound",
                    required: ["minecraft:is_rolled_up", "minecraft:is_threatened", "minecraft:is_trying_to_relax"],
                    properties: {
                        "minecraft:is_rolled_up": {
                            markdownDescription: "1 or 0 (true/false) - true if the armadillo is rolled up.",
                            type: "byte",
                        },
                        "minecraft:is_threatened": {
                            markdownDescription: "1 or 0 (true/false) - true if the armadillo was hit.",
                            type: "byte",
                        },
                        "minecraft:is_trying_to_relax": {
                            markdownDescription: "1 or 0 (true/false) - UNDOCUMENTED.",
                            type: "byte",
                        },
                    },
                },
            },
            allOf: [
                {
                    $ref: "Component_Ageable",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_ArmorStand: {
            id: "Entity_ArmorStand",
            markdownDescription: "Additional fields for [armor stand](https://minecraft.wiki/w/armor_stand).",
            type: "compound",
            required: ["Pose"],
            properties: {
                Pose: {
                    markdownDescription: "The ArmorStand's pose.",
                    type: "compound",
                    required: ["LastSignal", "PoseIndex"],
                    properties: {
                        LastSignal: {
                            markdownDescription: "The redstone signal level it received.",
                            type: "int",
                        },
                        PoseIndex: {
                            markdownDescription: "The index of current pose.",
                            type: "int",
                        },
                    },
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Arrow: {
            id: "Entity_Arrow",
            markdownDescription: "Additional fields for [arrow](https://minecraft.wiki/w/arrow).",
            type: "compound",
            required: ["auxValue", "enchantFlame", "enchantInfinity", "mobEffects", "enchantPower", "enchantPunch"],
            properties: {
                auxValue: {
                    markdownDescription: "The metadata of this arrow. See [Arrow#Metadata](https://minecraft.wiki/w/Arrow#Metadata).",
                    type: "byte",
                },
                enchantFlame: {
                    markdownDescription: "The level of [Flame](https://minecraft.wiki/w/Flame) enchantment on the bow that shot this arrow, where 1 is level 1. 0 if no Flame enchantment.",
                    type: "byte",
                },
                enchantInfinity: {
                    markdownDescription: "The level of [Infinity](https://minecraft.wiki/w/Infinity) enchantment on the bow that shot this arrow, where 1 is level 1. 0 if no Infinity enchantment.",
                    type: "byte",
                },
                mobEffects: {
                    markdownDescription: "Effects on a tipped arrow.",
                    type: "list",
                    items: {
                        markdownDescription: "An effect.",
                        type: "compound",
                        $ref: "MobEffect",
                    },
                },
                enchantPower: {
                    markdownDescription: "The level of [Power](https://minecraft.wiki/w/Power) enchantment on the bow that shot this arrow, where 1 is level 1. 0 if no Power enchantment.",
                    type: "byte",
                },
                enchantPunch: {
                    markdownDescription: "The level of [Punch](https://minecraft.wiki/w/Punch) enchantment on the bow that shot this arrow, where 1 is level 1. 0 if no Punch enchantment.",
                    type: "byte",
                },
            },
            allOf: [
                {
                    $ref: "Component_Projectile",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Axolotl: {
            id: "Entity_Axolotl",
            markdownDescription: "Additional fields for [axolotl](https://minecraft.wiki/w/axolotl).",
            type: "compound",
            required: ["TicksRemainingUntilDryOut"],
            properties: {
                DamageTime: {
                    markdownDescription: "(May not exist) Applies a defined amount of damage to the axolotl at specified intervals.",
                    type: "short",
                },
                TicksRemainingUntilDryOut: {
                    markdownDescription: "Number of ticks until the axolotl dies when it is on the surface. Initially starts at 6000 ticks (5 minutes) and counts down to 0.",
                    type: "int",
                },
            },
            allOf: [
                {
                    $ref: "Component_Ageable",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Bat: {
            id: "Entity_Bat",
            markdownDescription: "Additional fields for [bat](https://minecraft.wiki/w/bat).",
            type: "compound",
            required: ["BatFlags"],
            properties: {
                BatFlags: {
                    markdownDescription: "1 when hanging upside down and 0 when flying.More info",
                    type: "byte",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Bee: {
            id: "Entity_Bee",
            markdownDescription: "Additional fields for [bee](https://minecraft.wiki/w/bee).",
            type: "compound",
            required: ["properties"],
            properties: {
                properties: {
                    markdownDescription: "The bee `properties`.",
                    type: "compound",
                    required: ["minecraft:has_nectar"],
                    properties: {
                        "minecraft:has_nectar": {
                            markdownDescription: "1 or 0 (true/false) - true if the bee is carrying pollen.",
                            type: "byte",
                        },
                    },
                },
            },
            allOf: [
                {
                    $ref: "Component_Ageable",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_BoatWithChest: {
            id: "Entity_BoatWithChest",
            markdownDescription: "Additional fields for [boat with chest](https://minecraft.wiki/w/boat_with_chest).",
            type: "compound",
            allOf: [{ $ref: "Component_Inventory" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Breeze: {
            id: "Entity_Breeze",
            markdownDescription: "Additional fields for [breeze](https://minecraft.wiki/w/breeze).",
            type: "compound",
            required: ["properties"],
            properties: {
                properties: {
                    markdownDescription: "The breeze `properties`.",
                    type: "compound",
                    required: ["minecraft:is_playing_idle_ground_sound"],
                    properties: {
                        "minecraft:is_playing_idle_ground_sound": {
                            markdownDescription: "1 or 0 (true/false) - true if the breeze is playing the `mob.breeze.idle_ground` sound.",
                            type: "byte",
                        },
                    },
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Camel: {
            id: "Entity_Camel",
            markdownDescription: "Additional fields for [camel](https://minecraft.wiki/w/camel).",
            type: "compound",
            allOf: [{ $ref: "Component_Ageable" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Cat: {
            id: "Entity_Cat",
            markdownDescription: "Additional fields for [cat](https://minecraft.wiki/w/cat).",
            type: "compound",
            allOf: [{ $ref: "Component_Ageable" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Chicken: {
            id: "Entity_Chicken",
            markdownDescription: "Additional fields for [chicken](https://minecraft.wiki/w/chicken).",
            type: "compound",
            properties: {
                entries: {
                    type: "list",
                    items: {
                        markdownDescription: "An entry.",
                        type: "compound",
                        required: ["SpawnTimer", "StopSpawning"],
                        properties: {
                            SpawnTimer: {
                                markdownDescription: "UNDOCUMENTED.",
                                type: "int",
                            },
                            StopSpawning: {
                                markdownDescription: "UNDOCUMENTED.",
                                type: "byte",
                            },
                        },
                    },
                },
            },
            allOf: [
                {
                    $ref: "Component_Ageable",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Cow: {
            id: "Entity_Cow",
            markdownDescription: "Additional fields for [cow](https://minecraft.wiki/w/cow).",
            type: "compound",
            allOf: [{ $ref: "Component_Ageable" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Creeper: {
            id: "Entity_Creeper",
            markdownDescription: "Additional fields for [creeper](https://minecraft.wiki/w/creeper).",
            type: "compound",
            allOf: [{ $ref: "Component_Explode" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Dolphin: {
            id: "Entity_Dolphin",
            markdownDescription: "Additional fields for [dolphin](https://minecraft.wiki/w/dolphin).",
            type: "compound",
            required: ["BribeTime", "TicksRemainingUntilDryOut"],
            properties: {
                BribeTime: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                DamageTime: {
                    markdownDescription: "(May not exist) Applies a defined amount of damage to the dolphin at specified intervals.",
                    type: "short",
                },
                TicksRemainingUntilDryOut: {
                    markdownDescription: "Number of ticks until the dolphin dies when it is on the surface. Initially starts at 2400 ticks (2 minutes) and counts down to 0.",
                    type: "int",
                },
            },
            allOf: [
                {
                    $ref: "Component_Ageable",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Donkey: {
            id: "Entity_Donkey",
            markdownDescription: "Additional fields for [donkey](https://minecraft.wiki/w/donkey).",
            type: "compound",
            required: ["Temper"],
            properties: {
                Temper: {
                    markdownDescription: "Random number that ranges from 0 to 100; increases with feeding or trying to tame it. Higher values make the donkey easier to tame.",
                    type: "int",
                },
            },
            allOf: [
                {
                    $ref: "Component_Ageable",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Egg: {
            id: "Entity_Egg",
            markdownDescription: "Additional fields for [egg](https://minecraft.wiki/w/egg).",
            type: "compound",
            allOf: [{ $ref: "Component_Projectile" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_EnderCrystal: {
            id: "Entity_EnderCrystal",
            markdownDescription: "Additional fields for [ender crystal](https://minecraft.wiki/w/ender_crystal).",
            type: "compound",
            properties: {
                BlockTargetX: {
                    markdownDescription: "(May not exist) The block location its beam points to.",
                    type: "int",
                },
                BlockTargetY: {
                    markdownDescription: "(May not exist) See above.",
                    type: "int",
                },
                BlockTargetZ: {
                    markdownDescription: "(May not exist) See above.",
                    type: "int",
                },
            },
            allOf: [
                {
                    $ref: "Component_Explode",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Enderman: {
            id: "Entity_Enderman",
            markdownDescription: "Additional fields for [enderman](https://minecraft.wiki/w/enderman).",
            type: "compound",
            required: ["carriedBlock"],
            properties: {
                carriedBlock: {
                    markdownDescription: "The block carried by the enderman.",
                    type: "compound",
                    $ref: "Block",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Endermite: {
            id: "Entity_Endermite",
            markdownDescription: "Additional fields for [endermite](https://minecraft.wiki/w/endermite).",
            type: "compound",
            required: ["Lifetime"],
            properties: {
                Lifetime: {
                    markdownDescription: "How long the endermite has existed in ticks. Disappears when this reaches around 2400.",
                    type: "int",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Evoker: {
            id: "Entity_Evoker",
            markdownDescription: "Additional fields for [evoker](https://minecraft.wiki/w/evoker).",
            type: "compound",
            allOf: [{ $ref: "Component_Dweller" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_ExperienceOrb: {
            id: "Entity_ExperienceOrb",
            markdownDescription: "Additional fields for [experience orb](https://minecraft.wiki/w/experience_orb).",
            type: "compound",
            required: ["Age", "experience value"],
            properties: {
                Age: {
                    markdownDescription: 'The number of ticks the XP orb has been "untouched". After 6000 ticks (5 minutes) the orb is destroyed. *needs testing*',
                    type: "short",
                },
                "experience value": {
                    markdownDescription: "The amount of experience the orb gives when picked up.",
                    type: "int",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_ExperiencePotion: {
            id: "Entity_ExperiencePotion",
            markdownDescription: "Additional fields for [experience potion](https://minecraft.wiki/w/experience_potion).",
            type: "compound",
            allOf: [{ $ref: "Component_Projectile" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_FallingBlock: {
            id: "Entity_FallingBlock",
            markdownDescription: "Additional fields for [falling block](https://minecraft.wiki/w/falling_block).",
            type: "compound",
            required: ["Time"],
            properties: {
                FallingBlock: {
                    type: "compound",
                    $ref: "Block",
                },
                Time: {
                    markdownDescription: "The number of ticks the entity has existed. If set to 0, the moment it ticks to 1, it vanishes if the block at its location has a different ID than the entity's `FallingBlock.Name`. If the block at its location has the same ID as its `FallingBlock.Name` when `Time` ticks from 0 to 1, the block is deleted, and the entity continues to fall, having overwritten it. When Time goes above 600, or above 100 while the block is below Y=1 or is outside building height, the entity is deleted. *needs testing*",
                    type: "byte",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Fireball: {
            id: "Entity_Fireball",
            markdownDescription: "Additional fields for [fireball](https://minecraft.wiki/w/fireball).",
            type: "compound",
            required: ["Direction", "inGround", "power"],
            properties: {
                Direction: {
                    markdownDescription: "List of 3 doubles. Should be identical to Motion. *needs testing*",
                    type: "list",
                    items: [
                        {
                            markdownDescription: "X",
                            type: "float",
                        },
                        {
                            markdownDescription: "Y",
                            type: "float",
                        },
                        {
                            markdownDescription: "Z",
                            type: "float",
                        },
                    ],
                },
                inGround: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
                power: {
                    markdownDescription: "List of 3 floats that adds to `Direction` every tick. Act as the acceleration.",
                    type: "list",
                    items: [
                        {
                            markdownDescription: "X",
                            type: "float",
                        },
                        {
                            markdownDescription: "Y",
                            type: "float",
                        },
                        {
                            markdownDescription: "Z",
                            type: "float",
                        },
                    ],
                },
            },
            allOf: [
                {
                    $ref: "Component_Explode",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_FireworksRocket: {
            id: "Entity_FireworksRocket",
            markdownDescription: "Additional fields for [firework rocket](https://minecraft.wiki/w/firework).",
            type: "compound",
            required: ["Life", "LifeTime"],
            properties: {
                Life: {
                    markdownDescription: "The number of ticks this fireworks rocket has been flying for.",
                    type: "int",
                },
                LifeTime: {
                    markdownDescription: "The number of ticks before this fireworks rocket explodes. This value is randomized when the firework is launched. *needs testing*",
                    type: "int",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_FishingBobber: {
            id: "Entity_FishingBobber",
            markdownDescription: "Additional fields for [fishing bobber](https://minecraft.wiki/w/fishing_bobber).",
            type: "compound",
            allOf: [{ $ref: "Component_Projectile" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Fox: {
            id: "Entity_Fox",
            markdownDescription: "Additional fields for [fox](https://minecraft.wiki/w/fox).",
            type: "compound",
            required: ["TrustedPlayersAmount", "TrustedPlayer[0-9]+"],
            properties: {
                TrustedPlayersAmount: {
                    markdownDescription: "The number of players who are trusted by the fox.",
                    type: "int",
                },
            },
            patternProperties: {
                "TrustedPlayer[0-9]+": {
                    markdownDescription: "A player's Unique ID. Note that `<_num_>` counts from 0.",
                    type: "long",
                },
            },
            allOf: [
                {
                    $ref: "Component_Ageable",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Frog: {
            id: "Entity_Frog",
            markdownDescription: "Additional fields for [frog](https://minecraft.wiki/w/frog).",
            type: "compound",
            allOf: [{ $ref: "Component_Breedable" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Goat: {
            id: "Entity_Goat",
            markdownDescription: "Additional fields for [goat](https://minecraft.wiki/w/goat).",
            type: "compound",
            required: ["GoatHornCount"],
            properties: {
                GoatHornCount: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
            },
            allOf: [
                {
                    $ref: "Component_Ageable",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_GuardianAndElderGuardian: {
            id: "Entity_GuardianAndElderGuardian",
            markdownDescription: "Additional fields for [guardian](https://minecraft.wiki/w/guardian) and [elder guardian](https://minecraft.wiki/w/elder_guardian).",
            type: "compound",
            required: ["Elder"],
            properties: {
                Elder: {
                    markdownDescription: "1 or 0 (true/false) - true if it is an elder guardian.",
                    type: "byte",
                },
            },
            allOf: [
                {
                    $ref: "Component_Home",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Hoglin: {
            id: "Entity_Hoglin",
            markdownDescription: "Additional fields for [hoglin](https://minecraft.wiki/w/hoglin).",
            type: "compound",
            allOf: [{ $ref: "Component_Ageable" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Horse: {
            id: "Entity_Horse",
            markdownDescription: "Additional fields for [horse](https://minecraft.wiki/w/horse).",
            type: "compound",
            required: ["Temper"],
            properties: {
                Temper: {
                    markdownDescription: "Random number that ranges from 0 to 100; increases with feeding or trying to tame it. Higher values make the horse easier to tame.",
                    type: "int",
                },
            },
            allOf: [
                {
                    $ref: "Component_Ageable",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Husk: {
            id: "Entity_Husk",
            markdownDescription: "Additional fields for [husk](https://minecraft.wiki/w/husk).",
            type: "compound",
            allOf: [{ $ref: "Component_Timer" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_IronGolem: {
            id: "Entity_IronGolem",
            markdownDescription: "Additional fields for [iron golem](https://minecraft.wiki/w/iron_golem).",
            type: "compound",
            allOf: [{ $ref: "Component_Dweller" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_ItemEntity: {
            id: "Entity_ItemEntity",
            markdownDescription: "Additional fields for [item entity](https://minecraft.wiki/w/Item_(entity)).",
            type: "compound",
            required: ["Age", "Health", "Item", "OwnerID"],
            properties: {
                Age: {
                    markdownDescription: 'The number of ticks the item has been "untouched". After 6000 ticks (5 minutes) the item is destroyed.',
                    type: "short",
                },
                Health: {
                    markdownDescription: "The health of the item, which starts at 5. Items take damage from fire, lava, and explosions. The item is destroyed when its health reaches 0. *needs testing*",
                    type: "short",
                },
                Item: {
                    markdownDescription: "The item of this stack.",
                    type: "compound",
                    $ref: "Item_ItemStack",
                },
                OwnerID: {
                    markdownDescription: "If present, only the player *needs testing* with this Unique ID can pick up the item.",
                    type: "long",
                    default: {
                        type: "long",
                        value: -1n,
                    },
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Llama: {
            id: "Entity_Llama",
            markdownDescription: "Additional fields for [llama](https://minecraft.wiki/w/llama).",
            type: "compound",
            required: ["Temper"],
            properties: {
                Temper: {
                    markdownDescription: "Random number that ranges from 0 to 100; increases with feeding or trying to tame it. Higher values make the llama easier to tame.",
                    type: "int",
                },
            },
            allOf: [
                {
                    $ref: "Component_Ageable",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_LlamaSpit: {
            id: "Entity_LlamaSpit",
            markdownDescription: "Additional fields for [llama spit](https://minecraft.wiki/w/Llama_Spit).",
            type: "compound",
            allOf: [{ $ref: "Component_Projectile" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_MinecartWithChest: {
            id: "Entity_MinecartWithChest",
            markdownDescription: "Additional fields for [minecart with chest](https://minecraft.wiki/w/minecart_with_chest).",
            type: "compound",
            allOf: [{ $ref: "Component_Inventory" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_MinecartWithCommandBlock: {
            id: "Entity_MinecartWithCommandBlock",
            markdownDescription: "Additional fields for [minecart with command block](https://minecraft.wiki/w/minecart_with_command_block).",
            type: "compound",
            required: ["CurrentTickCount", "Ticking"],
            properties: {
                CurrentTickCount: {
                    markdownDescription: "Number of ticks until it executes the command again.",
                    type: "int",
                },
                Ticking: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_MinecartWithHopper: {
            id: "Entity_MinecartWithHopper",
            markdownDescription: "Additional fields for [minecart with hopper](https://minecraft.wiki/w/minecart_with_hopper).",
            type: "compound",
            allOf: [{ $ref: "Component_Inventory" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_MinecartWithTNT: {
            id: "Entity_MinecartWithTNT",
            markdownDescription: "Additional fields for [minecart with tnt](https://minecraft.wiki/w/minecart_with_tnt).",
            type: "compound",
            allOf: [{ $ref: "Component_Explode" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Mooshroom: {
            id: "Entity_Mooshroom",
            markdownDescription: "Additional fields for [mooshroom](https://minecraft.wiki/w/mooshroom).",
            type: "compound",
            allOf: [{ $ref: "Component_Ageable" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Mule: {
            id: "Entity_Mule",
            markdownDescription: "Additional fields for [mule](https://minecraft.wiki/w/mule).",
            type: "compound",
            required: ["Temper"],
            properties: {
                Temper: {
                    markdownDescription: "Random number that ranges from 0 to 100; increases with feeding or trying to tame it. Higher values make the mule easier to tame.",
                    type: "int",
                },
            },
            allOf: [
                {
                    $ref: "Component_Ageable",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_NPC: {
            id: "Entity_NPC",
            markdownDescription: "Additional fields for [NPC](https://minecraft.wiki/w/NPC).",
            type: "compound",
            properties: {
                Actions: {
                    markdownDescription: "(May not exist) The actions.",
                    type: "string",
                },
                InterativeText: {
                    markdownDescription: "(May not exist) The interactive text.",
                    type: "string",
                },
                PlayerSceneMapping: {
                    markdownDescription: "(May not exist) UNDOCUMENTED.",
                    type: "list",
                    items: {
                        markdownDescription: "A key-value pair.",
                        type: "compound",
                        required: ["PlayerID", "SceneName"],
                        properties: {
                            PlayerID: {
                                markdownDescription: "A player's Unique ID.",
                                type: "long",
                            },
                            SceneName: {
                                markdownDescription: "UNDOCUMENTED.",
                                type: "string",
                            },
                        },
                    },
                },
                RawtextName: {
                    markdownDescription: "(May not exist) The name.",
                    type: "string",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Ocelot: {
            id: "Entity_Ocelot",
            markdownDescription: "Additional fields for [ocelot](https://minecraft.wiki/w/ocelot).",
            type: "compound",
            allOf: [{ $ref: "Component_Ageable" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Painting: {
            id: "Entity_Painting",
            markdownDescription: "Additional fields for [painting](https://minecraft.wiki/w/painting).",
            type: "compound",
            required: ["Dir", "Direction"],
            properties: {
                Dir: {
                    markdownDescription: "The direction the painting faces: 0 is south, 1 is west, 2 is north, 3 is east. *needs testing*",
                    type: "byte",
                },
                Direction: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
                Motif: {
                    markdownDescription: "(May not exist) The ID of the painting's artwork.",
                    type: "string",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Panda: {
            id: "Entity_Panda",
            markdownDescription: "Additional fields for [panda](https://minecraft.wiki/w/panda).",
            type: "compound",
            allOf: [{ $ref: "Component_Ageable" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Pig: {
            id: "Entity_Pig",
            markdownDescription: "Additional fields for [pig](https://minecraft.wiki/w/pig).",
            type: "compound",
            allOf: [{ $ref: "Component_Ageable" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Piglin: {
            id: "Entity_Piglin",
            markdownDescription: "Additional fields for [piglin](https://minecraft.wiki/w/piglin).",
            type: "compound",
            allOf: [{ $ref: "Component_Inventory" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_PiglinBrute: {
            id: "Entity_PiglinBrute",
            markdownDescription: "Additional fields for [piglin brute](https://minecraft.wiki/w/piglin_brute).",
            type: "compound",
            allOf: [{ $ref: "Component_Home" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Pillager: {
            id: "Entity_Pillager",
            markdownDescription: "Additional fields for [pillager](https://minecraft.wiki/w/pillager).",
            type: "compound",
            allOf: [{ $ref: "Component_Dweller" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Player: {
            id: "Entity_Player",
            markdownDescription: "Additional fields for [player](https://minecraft.wiki/w/player).",
            type: "compound",
            required: [
                "AgentID",
                "DimensionId",
                "EnchantmentSeed",
                "EnderChestInventory",
                "fogCommandStack",
                "format_version",
                "HasSeenCredits",
                "Inventory",
                "LeftShoulderRiderID",
                "MapIndex",
                "PlayerGameMode",
                "PlayerLevel",
                "PlayerLevelProgress",
                "PlayerUIItems",
                "recipe_unlocking",
                "RideID",
                "RightShoulderRiderID",
                "SelectedContainerId",
                "SelectedInventorySlot",
                "Sleeping",
                "SleepTimer",
                "Sneaking",
                "SpawnBlockPositionX",
                "SpawnBlockPositionY",
                "SpawnBlockPositionZ",
                "SpawnDimension",
                "SpawnX",
                "SpawnY",
                "SpawnZ",
                "TimeSinceRest",
                "WardenThreatDecreaseTimer",
                "WardenThreatLevel",
                "WardenThreatLevelIncreaseCooldown",
            ],
            properties: {
                AgentID: {
                    markdownDescription: "The Unique ID of the player's agent.",
                    type: "long",
                },
                DimensionId: {
                    markdownDescription: "The ID of the dimension the player is in.",
                    type: "int",
                },
                EnchantmentSeed: {
                    markdownDescription: "The seed used for the next enchantment in [enchantment table](https://minecraft.wiki/w/enchantment_table)s.",
                    type: "int",
                },
                EnderChestInventory: {
                    markdownDescription: "Each compound tag in this list is an item in the player's 27-slot ender chest inventory.",
                    type: "list",
                    items: {
                        markdownDescription: "An item in the inventory.",
                        type: "compound",
                        required: ["Slot"],
                        properties: {
                            Slot: {
                                markdownDescription: "The slot the item is in.",
                                type: "byte",
                            },
                        },
                        allOf: [{ $ref: "Item_ItemStack" }],
                    },
                },
                fogCommandStack: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "list",
                    items: {
                        markdownDescription: "UNDOCUMENTED.",
                        type: "string",
                    },
                },
                format_version: {
                    markdownDescription: "The format version of this NBT.",
                    type: "string",
                },
                HasSeenCredits: {
                    markdownDescription: "1 or 0 (true/false) - true if the player has traveled to the [Overworld](https://minecraft.wiki/w/Overworld) via an [End portal](https://minecraft.wiki/w/End_portal).",
                    type: "byte",
                },
                Inventory: {
                    markdownDescription: "Each compound tag in this list is an item in the player's inventory.",
                    type: "list",
                    items: {
                        markdownDescription: "An item in the inventory, including the slot tag.",
                        type: "compound",
                        required: ["Slot"],
                        properties: {
                            Slot: {
                                markdownDescription: "The slot the item is in.",
                                type: "byte",
                            },
                        },
                        allOf: [{ $ref: "Item_ItemStack" }],
                    },
                },
                LeftShoulderRiderID: {
                    markdownDescription: "The Unique ID of the entity that is on the player's left shoulder.",
                    type: "long",
                },
                MapIndex: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                PlayerGameMode: {
                    markdownDescription: "The game mode of the player.",
                    type: "int",
                },
                PlayerLevel: {
                    markdownDescription: "The level shown on the [XP](https://minecraft.wiki/w/XP) bar.",
                    type: "int",
                },
                PlayerLevelProgress: {
                    markdownDescription: "The progress/percent across the XP bar to the next level.",
                    type: "float",
                },
                PlayerUIItems: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "list",
                    items: {
                        markdownDescription: "An item in the UI, including the slot tag.",
                        type: "compound",
                        required: ["Slot"],
                        properties: {
                            Slot: {
                                markdownDescription: "The slot the item is in.",
                                type: "byte",
                            },
                        },
                    },
                },
                recipe_unlocking: {
                    markdownDescription: "Contains information about the recipes that the player has unlocked.",
                    type: "compound",
                    required: ["unlocked_recipes", "used_contexts"],
                    properties: {
                        unlocked_recipes: {
                            markdownDescription: "A list of all recipes the player has unlocked.",
                            type: "list",
                            items: {
                                markdownDescription: "The name of a recipe, for instance `minecraft:stick` or `minecraft:ladder`.",
                                type: "string",
                            },
                        },
                        used_contexts: {
                            markdownDescription: "UNDOCUMENTED. Defaults to 2.",
                            type: "int",
                        },
                    },
                },
                RideID: {
                    markdownDescription: "The Unique ID of the entity that the player is riding.",
                    type: "long",
                },
                RightShoulderRiderID: {
                    markdownDescription: "The Unique ID of the entity that is on the player's right shoulder.",
                    type: "long",
                },
                SelectedContainerId: {
                    markdownDescription: "The ID of the selected container. *needs testing*",
                    type: "int",
                },
                SelectedInventorySlot: {
                    markdownDescription: "The selected inventory slot of the player.",
                    type: "int",
                },
                Sleeping: {
                    markdownDescription: "1 or 0 (true/false) - true if the player is sleeping.",
                    type: "byte",
                },
                SleepTimer: {
                    markdownDescription: "The number of ticks the player had been in bed. 0 when the player is not sleeping. In bed, increases up to 100, then stops. Skips the night after all players in bed have reached 100. When getting out of bed, instantly changes to 100 and then increases for another 9 ticks (up to 109) before returning to 0. *needs testing*",
                    type: "short",
                },
                Sneaking: {
                    markdownDescription: "1 or 0 (true/false) - true if the player is sneaking.",
                    type: "byte",
                },
                SpawnBlockPositionX: {
                    markdownDescription: "The X coordinate of the player's spawn block.",
                    type: "int",
                },
                SpawnBlockPositionY: {
                    markdownDescription: "The Y coordinate of the player's spawn block.",
                    type: "int",
                },
                SpawnBlockPositionZ: {
                    markdownDescription: "The Z coordinate of the player's spawn block.",
                    type: "int",
                },
                SpawnDimension: {
                    markdownDescription: "The dimension of the player's spawn point.",
                    type: "int",
                },
                SpawnX: {
                    markdownDescription: "The X coordinate of the player's spawn point.",
                    type: "int",
                },
                SpawnY: {
                    markdownDescription: "The Y coordinate of the player's spawn point.",
                    type: "int",
                },
                SpawnZ: {
                    markdownDescription: "The Z coordinate of the player's spawn point.",
                    type: "int",
                },
                TimeSinceRest: {
                    markdownDescription: "The time in ticks since last rest.",
                    type: "int",
                },
                WardenThreatDecreaseTimer: {
                    markdownDescription: "The number of ticks since the player was threatened for warden spawning. Increases by 1 every tick. After 12000 ticks (10 minutes) it will be set back to 0, and the `WardenThreatLevel` will be decreased by 1.",
                    type: "int",
                },
                WardenThreatLevel: {
                    markdownDescription: "A threat level between 0 and 4 (inclusive). The warden will spawn at level 4.",
                    type: "int",
                },
                WardenThreatLevelIncreaseCooldown: {
                    markdownDescription: "The number of ticks before the `WardenThreatLevel` can be increased again. Decreases by 1 every tick. It is set 200 ticks (10 seconds) every time the threat level is increased.",
                    type: "int",
                },
            },
            allOf: [
                {
                    $ref: "Abilities",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_PolarBear: {
            id: "Entity_PolarBear",
            markdownDescription: "Additional fields for [polar bear](https://minecraft.wiki/w/polar_bear).",
            type: "compound",
            allOf: [{ $ref: "Component_Ageable" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Pufferfish: {
            id: "Entity_Pufferfish",
            markdownDescription: "Additional fields for [pufferfish](https://minecraft.wiki/w/pufferfish).",
            type: "compound",
            allOf: [{ $ref: "Component_Timer" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Rabbit: {
            id: "Entity_Rabbit",
            markdownDescription: "Additional fields for [rabbit](https://minecraft.wiki/w/rabbit).",
            type: "compound",
            required: ["CarrotsEaten", "MoreCarrotTicks"],
            properties: {
                CarrotsEaten: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                MoreCarrotTicks: {
                    markdownDescription: "Set to 40 when a carrot crop is eaten, decreases by 0–2 every tick until it reaches 0. *needs testing*",
                    type: "int",
                },
            },
            allOf: [
                {
                    $ref: "Component_Ageable",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Ravager: {
            id: "Entity_Ravager",
            markdownDescription: "Additional fields for [ravager](https://minecraft.wiki/w/ravager).",
            type: "compound",
            allOf: [{ $ref: "Component_Dweller" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Sheep: {
            id: "Entity_Sheep",
            markdownDescription: "Additional fields for [sheep](https://minecraft.wiki/w/sheep).",
            type: "compound",
            allOf: [{ $ref: "Component_Ageable" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_ShulkerBullet: {
            id: "Entity_ShulkerBullet",
            markdownDescription: "Additional fields for [shulker bullet](https://minecraft.wiki/w/shulker_bullet).",
            type: "compound",
            allOf: [{ $ref: "Component_Projectile" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Skeleton: {
            id: "Entity_Skeleton",
            markdownDescription: "Additional fields for [skeleton](https://minecraft.wiki/w/skeleton).",
            type: "compound",
            required: ["ItemInHand"],
            properties: {
                ItemInHand: {
                    markdownDescription: "The item in its hand. Defaults to a bow.",
                    type: "compound",
                    $ref: "Item_ItemStack",
                },
            },
            allOf: [
                {
                    $ref: "Component_Timer",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_SkeletonHorse: {
            id: "Entity_SkeletonHorse",
            markdownDescription: "Additional fields for [skeleton horse](https://minecraft.wiki/w/skeleton_horse).",
            type: "compound",
            allOf: [{ $ref: "Component_Ageable" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Slime: {
            id: "Entity_Slime",
            markdownDescription: "Additional fields for [slime](https://minecraft.wiki/w/slime).",
            type: "compound",
            required: ["Size"],
            properties: {
                Size: {
                    markdownDescription: "The size of the slime. Note that this value is zero-based, so 0 is the smallest slime, 1 is the next larger, etc.",
                    type: "byte",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Sniffer: {
            id: "Entity_Sniffer",
            markdownDescription: "Additional fields for [sniffer](https://minecraft.wiki/w/sniffer).",
            type: "compound",
            allOf: [{ $ref: "Component_Ageable" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Snowball: {
            id: "Entity_Snowball",
            markdownDescription: "Additional fields for [snowball](https://minecraft.wiki/w/snowball).",
            type: "compound",
            allOf: [{ $ref: "Component_Projectile" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Strider: {
            id: "Entity_Strider",
            markdownDescription: "Additional fields for [strider](https://minecraft.wiki/w/strider).",
            type: "compound",
            allOf: [{ $ref: "Component_Ageable" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Tadpole: {
            id: "Entity_Tadpole",
            markdownDescription: "Additional fields for [tadpole](https://minecraft.wiki/w/tadpole).",
            type: "compound",
            allOf: [{ $ref: "Component_Ageable" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_ThrownEnderPearl: {
            id: "Entity_ThrownEnderPearl",
            markdownDescription: "Additional fields for thrown [ender pearl](https://minecraft.wiki/w/ender_pearl).",
            type: "compound",
            allOf: [{ $ref: "Component_Projectile" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_ThrownPotion: {
            id: "Entity_ThrownPotion",
            markdownDescription: "Additional fields for thrown [potion](https://minecraft.wiki/w/potion).",
            type: "compound",
            required: ["PotionId"],
            properties: {
                PotionId: {
                    markdownDescription: "The [ID of the potion effect](https://minecraft.wiki/w/Potion#Item_data).",
                    type: "short",
                },
            },
            allOf: [
                {
                    $ref: "Component_Projectile",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_ThrownTrident: {
            id: "Entity_ThrownTrident",
            markdownDescription: "Additional fields for thrown [trident](https://minecraft.wiki/w/trident).",
            type: "compound",
            required: ["favoredSlot", "Trident"],
            properties: {
                favoredSlot: {
                    markdownDescription: "The slot id when it is thrown out.This means thrown trident with [Loyalty](https://minecraft.wiki/w/Loyalty) prefers to return to this slot when this slot is empty. Set to -1 when without [Loyalty](https://minecraft.wiki/w/Loyalty) enchantment.",
                    type: "int",
                },
                Trident: {
                    markdownDescription: "The item that is given when the entity is picked up.",
                    type: "compound",
                    $ref: "Item_ItemStack",
                },
            },
            allOf: [
                {
                    $ref: "Component_Projectile",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_TNT: {
            id: "Entity_TNT",
            markdownDescription: "Additional fields for [tnt](https://minecraft.wiki/w/tnt).",
            type: "compound",
            allOf: [{ $ref: "Component_Explode" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Turtle: {
            id: "Entity_Turtle",
            markdownDescription: "Additional fields for [turtle](https://minecraft.wiki/w/turtle).",
            type: "compound",
            required: ["IsPregnant"],
            properties: {
                IsPregnant: {
                    markdownDescription: "1 or 0 (true/false) - true if the turtle has eggs.",
                    type: "byte",
                },
            },
            allOf: [
                {
                    $ref: "Component_Ageable",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Vex: {
            id: "Entity_Vex",
            markdownDescription: "Additional fields for [vex](https://minecraft.wiki/w/vex).",
            type: "compound",
            required: ["ItemInHand"],
            properties: {
                ItemInHand: {
                    markdownDescription: "The item in its hand. Defaults to an iron sword.",
                    type: "compound",
                    $ref: "Item_ItemStack",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Villager_V2: {
            id: "Entity_Villager_V2",
            markdownDescription: "Additional fields for [villager](https://minecraft.wiki/w/villager) (v2).",
            type: "compound",
            required: ["HasResupplied", "IsInRaid", "ReactToBell"],
            properties: {
                HasResupplied: {
                    markdownDescription: "1 or 0 (true/false) - true if the villager's trade has been resupplied.",
                    type: "byte",
                },
                IsInRaid: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
                ReactToBell: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
            },
            allOf: [
                {
                    $ref: "Component_Ageable",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Vindicator: {
            id: "Entity_Vindicator",
            markdownDescription: "Additional fields for [vindicator](https://minecraft.wiki/w/vindicator).",
            type: "compound",
            allOf: [{ $ref: "Component_Dweller" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_WanderingTrader: {
            id: "Entity_WanderingTrader",
            markdownDescription: "Additional fields for [wandering trader](https://minecraft.wiki/w/wandering_trader).",
            type: "compound",
            properties: {
                entries: {
                    type: "list",
                    items: {
                        markdownDescription: "An entry.",
                        type: "compound",
                        required: ["SpawnTimer", "StopSpawning"],
                        properties: {
                            SpawnTimer: {
                                markdownDescription: "UNDOCUMENTED.",
                                type: "int",
                            },
                            StopSpawning: {
                                markdownDescription: "UNDOCUMENTED.",
                                type: "byte",
                            },
                        },
                    },
                },
            },
            allOf: [
                {
                    $ref: "Component_Economy_trade_table",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Warden: {
            id: "Entity_Warden",
            markdownDescription: "Additional fields for [warden](https://minecraft.wiki/w/warden).",
            type: "compound",
            required: ["Nuisances", "VibrationListener"],
            properties: {
                Nuisances: {
                    markdownDescription: "List of nuisances that have angered the warden.",
                    type: "list",
                    items: {
                        markdownDescription: "A nuisance.",
                        type: "compound",
                        required: ["ActorId", "Anger", "Priority"],
                        properties: {
                            ActorId: {
                                markdownDescription: "The Unique ID of the entity that is associated with the anger.",
                                type: "long",
                            },
                            Anger: {
                                markdownDescription: "The level of anger. It has a maximum value of 150 and decreases by 1 every second.",
                                type: "int",
                            },
                            Priority: {
                                markdownDescription: "1 or 0 (true/false) - true if the nuisance is priority.",
                                type: "byte",
                            },
                        },
                    },
                },
                VibrationListener: {
                    markdownDescription: "The vibration event listener of the warden.",
                    type: "compound",
                    required: ["event", "pending", "selector", "ticks"],
                    properties: {
                        event: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "int",
                        },
                        pending: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "compound",
                            required: ["distance", "source", "vibration", "x", "y", "z"],
                            properties: {
                                distance: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "float",
                                },
                                source: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "long",
                                },
                                vibration: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "int",
                                },
                                x: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "int",
                                },
                                y: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "int",
                                },
                                z: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "int",
                                },
                            },
                        },
                        selector: {
                            markdownDescription: "UNKNOWN.",
                            type: "compound",
                        },
                        ticks: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "int",
                        },
                    },
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_WindChargeProjectile: {
            id: "Entity_WindChargeProjectile",
            markdownDescription: "Additional fields for [wind charge projectile](https://minecraft.wiki/w/wind_charge_projectile).",
            type: "compound",
            allOf: [{ $ref: "Component_Projectile" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Witch: {
            id: "Entity_Witch",
            markdownDescription: "Additional fields for [witch](https://minecraft.wiki/w/witch).",
            type: "compound",
            allOf: [{ $ref: "Component_Dweller" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Wither: {
            id: "Entity_Wither",
            markdownDescription: "Additional fields for [wither](https://minecraft.wiki/w/wither).",
            type: "compound",
            required: [
                "AirAttack",
                "dyingFrames",
                "firerate",
                "Invul",
                "lastHealthInterval",
                "maxHealth",
                "oldSwellAmount",
                "overlayAlpha",
                "Phase",
                "ShieldHealth",
                "SpawningFrames",
                "swellAmount",
            ],
            properties: {
                AirAttack: {
                    markdownDescription: "Whether the wither exhibits first or second phase behavior, as well as whether the shield effect is visible - 1 for first phase and shield invisible, 0 for second phase and shield visible.",
                    type: "byte",
                },
                dyingFrames: {
                    markdownDescription: "The number of ticks remaining before the wither explodes during its death animation.",
                    type: "int",
                },
                firerate: {
                    markdownDescription: "The delay in ticks between wither skull shots. Does not affect the delay between volleys.",
                    type: "int",
                },
                Invul: {
                    markdownDescription: "The remaining number of ticks the wither will be invulnerable for. Updated to match SpawningFrames or dyingFrames every tick during spawn/death animation, otherwise remains static.",
                    type: "int",
                },
                lastHealthInterval: {
                    markdownDescription: "The greatest multiple of 75 that is fewer than the wither's lowest health. Does not increase if the wither is healed.",
                    type: "int",
                },
                maxHealth: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                oldSwellAmount: {
                    markdownDescription: "The swellAmount in the previous tick.",
                    type: "float",
                },
                overlayAlpha: {
                    markdownDescription: "The alpha/brightness of the wither texture overlay during its death animation. Has no effect outside the death animation.",
                    type: "float",
                },
                Phase: {
                    markdownDescription: "Which phase the wither is in. Has no effect on wither behavior or shield visibility. Has a value of 1 during spawning and first phase and 0 during second phase and death.",
                    type: "int",
                },
                ShieldHealth: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                SpawningFrames: {
                    markdownDescription: "The number of ticks remaining before the wither finishes its spawning animation and becomes vulnerable.",
                    type: "int",
                },
                swellAmount: {
                    markdownDescription: "How much the wither has swelled during its death animation. Has no effect outside the death animation.",
                    type: "float",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_WitherSkull: {
            id: "Entity_WitherSkull",
            markdownDescription: "Additional fields for [wither skull](https://minecraft.wiki/w/Wither).",
            type: "compound",
            allOf: [{ $ref: "Component_Explode" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Wolf: {
            id: "Entity_Wolf",
            markdownDescription: "Additional fields for [wolf](https://minecraft.wiki/w/wolf).",
            type: "compound",
            required: ["properties"],
            properties: {
                properties: {
                    markdownDescription: "The wolf `properties`.",
                    type: "compound",
                    required: ["minecraft:has_armor", "minecraft:has_increased_max_health", "minecraft:is_armorable"],
                    properties: {
                        "minecraft:has_armor": {
                            markdownDescription: "1 or 0 (true/false) - true if the wolf has [wolf armor](https://minecraft.wiki/w/wolf_armor).",
                            type: "byte",
                        },
                        "minecraft:has_increased_max_health": {
                            markdownDescription: "1 or 0 (true/false) - true if the wolf's maximum health is 40.",
                            type: "byte",
                        },
                        "minecraft:is_armorable": {
                            markdownDescription: "1 or 0 (true/false) - true if the wolf can be equipped with [wolf armor](https://minecraft.wiki/w/wolf_armor).",
                            type: "byte",
                        },
                    },
                },
            },
            allOf: [
                {
                    $ref: "Component_Ageable",
                },
            ],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_Zombie: {
            id: "Entity_Zombie",
            markdownDescription: "Additional fields for [zombie](https://minecraft.wiki/w/zombie).",
            type: "compound",
            allOf: [{ $ref: "Component_Timer" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_ZombieHorse: {
            id: "Entity_ZombieHorse",
            markdownDescription: "Additional fields for [zombie horse](https://minecraft.wiki/w/zombie_horse).",
            type: "compound",
            allOf: [{ $ref: "Component_Ageable" }],
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_ZombieVillager: {
            id: "Entity_ZombieVillager",
            markdownDescription: "Additional fields for [zombie villager](https://minecraft.wiki/w/zombie_villager).",
            type: "compound",
            required: ["SpawnedFromVillage"],
            properties: {
                SpawnedFromVillage: {
                    markdownDescription: "1 or 0 (true/false) - true if spawned from village.",
                    type: "byte",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        Entity_ZombifiedPiglin: {
            id: "Entity_ZombifiedPiglin",
            markdownDescription: "Additional fields for [zombified piglin](https://minecraft.wiki/w/zombified_piglin).",
            type: "compound",
            required: ["Anger"],
            properties: {
                Anger: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "short",
                },
            },
            $ref: "ActorPrefix",
            $fragment: false,
        },
        //#endregion
        //#region Block NBT Schemas
        Block_Banner: {
            id: "Block_Banner",
            markdownDescription: "Additional fields for [banner](https://minecraft.wiki/w/banner).",
            type: "compound",
            required: ["Base", "Type"],
            properties: {
                Base: {
                    markdownDescription: "The base color of the banner. See [Banner#Block_data](https://minecraft.wiki/w/Banner#Block_data).",
                    type: "int",
                },
                Patterns: {
                    markdownDescription: "(May not exist) List of all patterns applied to the banner.",
                    type: "list",
                    items: {
                        markdownDescription: "An individual pattern.",
                        type: "compound",
                        required: ["Color", "Pattern"],
                        properties: {
                            Color: {
                                markdownDescription: "The base color of the pattern. See [Banner#Block_data](https://minecraft.wiki/w/Banner#Block_data).",
                                type: "int",
                            },
                            Pattern: {
                                markdownDescription: "The pattern ID code. See [Banner#Block_data](https://minecraft.wiki/w/Banner#Block_data).",
                                type: "string",
                            },
                        },
                    },
                },
                Type: {
                    markdownDescription: "The type of the block entity. 0 is normal banner. 1 is ominous banner.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Block_Beacon: {
            id: "Block_Beacon",
            markdownDescription: "Additional fields for [beacon](https://minecraft.wiki/w/beacon).",
            type: "compound",
            required: ["primary", "secondary"],
            properties: {
                primary: {
                    markdownDescription: "The primary effect selected, see [Potion effects](https://minecraft.wiki/w/Status_effect) for IDs. Set to 0 when no effect is selected.",
                    type: "int",
                },
                secondary: {
                    markdownDescription: "The secondary effect selected, see [Potion effects](https://minecraft.wiki/w/Status_effect) for IDs. Set to 0 when no effect is selected. When set without a primary effect, does nothing. When set to the same as the primary, the effect is given at level 2 (the normally available behavior for 5 effects). When set to a different value than the primary (normally only Regeneration), gives the effect at level 1. *needs testing*",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Block_Bed: {
            id: "Block_Bed",
            markdownDescription: "Additional fields for [bed](https://minecraft.wiki/w/bed).",
            type: "compound",
            required: ["color"],
            properties: {
                color: {
                    markdownDescription: "The data value that determines the color of the half-bed block. When a bed is broken, the color of the block entity at the bed's head becomes the color of the bed item when it drops. See [Bed#Metadata](https://minecraft.wiki/w/Bed#Metadata).",
                    type: "byte",
                },
            },
            $fragment: false,
        },
        Block_BeehiveAndBeeNest: {
            id: "Block_BeehiveAndBeeNest",
            markdownDescription: "Additional fields for [beehive](https://minecraft.wiki/w/beehive) and bee nest.",
            type: "compound",
            required: ["ShouldSpawnBees"],
            properties: {
                Occupants: {
                    markdownDescription: "(May not exist) Entities currently in the hive.",
                    type: "list",
                    items: {
                        markdownDescription: "An entity in the hive.",
                        type: "compound",
                        required: ["ActorIdentifier", "SaveData", "TicksLeftToStay"],
                        properties: {
                            ActorIdentifier: {
                                markdownDescription: "The entity in the hive. Always `minecraft:bee<>` in vanilla game. more info",
                                type: "string",
                            },
                            SaveData: {
                                markdownDescription: "The NBT data of the entity in the hive.",
                                type: "compound",
                                $ref: "ActorPrefix",
                            },
                            TicksLeftToStay: {
                                markdownDescription: "The time in ticks until the entity leave the beehive.",
                                type: "int",
                            },
                        },
                    },
                },
                ShouldSpawnBees: {
                    markdownDescription: "1 or 0 (true/false) - true if new bees will be spawned.",
                    type: "byte",
                },
            },
            $fragment: false,
        },
        Block_Bell: {
            id: "Block_Bell",
            markdownDescription: "Additional fields for [bell](https://minecraft.wiki/w/bell).",
            type: "compound",
            required: ["Direction", "Ringing", "Ticks"],
            properties: {
                Direction: {
                    markdownDescription: "The direction data of this bell.",
                    type: "int",
                },
                Ringing: {
                    markdownDescription: "1 or 0 (true/false) - true if it is ringing.",
                    type: "byte",
                },
                Ticks: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Block_BrewingStand: {
            id: "Block_BrewingStand",
            markdownDescription: "Additional fields for [brewing stand](https://minecraft.wiki/w/brewing_stand).",
            type: "compound",
            required: ["CookTime", "FuelAmount", "FuelTotal", "Items"],
            properties: {
                CookTime: {
                    markdownDescription: "The number of ticks until the potions are finished.",
                    type: "short",
                },
                FuelAmount: {
                    markdownDescription: "Remaining fuel for the brewing stand.",
                    type: "short",
                },
                FuelTotal: {
                    markdownDescription: "The max fuel numder for the fuel bar.",
                    type: "short",
                },
                Items: {
                    markdownDescription: "List of items in brewing stand.",
                    type: "list",
                    items: {
                        markdownDescription: "An item in the brewing stand, including the slot tag.",
                        type: "compound",
                        required: ["Slot"],
                        properties: {
                            Slot: {
                                markdownDescription: "The slot the item is in.",
                                type: "byte",
                            },
                        },
                        allOf: [{ $ref: "Item_ItemStack" }],
                    },
                },
            },
            $fragment: false,
        },
        Block_CampfireAndSoulCampfire: {
            id: "Block_CampfireAndSoulCampfire",
            markdownDescription: "Additional fields for [campfire](https://minecraft.wiki/w/campfire) and [soul campfire](https://minecraft.wiki/w/soul_campfire).",
            type: "compound",
            required: ["ItemTime[0-9]+"],
            patternProperties: {
                "Item[0-9]+": {
                    markdownDescription: "(May not exist) An items currently cooking. `<_num_>` is 1, 2, 3, and 4.",
                    type: "compound",
                    $ref: "Item_ItemStack",
                },
                "ItemTime[0-9]+": {
                    markdownDescription: "How long each item has been cooking. `<_num_>` is 1, 2, 3, and 4.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Block_Cauldron: {
            id: "Block_Cauldron",
            markdownDescription: "Additional fields for [cauldron](https://minecraft.wiki/w/cauldron).",
            type: "compound",
            required: ["Items", "PotionId", "PotionType"],
            properties: {
                CustomColor: {
                    markdownDescription: "(May not exist) This tag exists only if the cauldron stores dyed water; stores a 32-bit ARGB encoded color.",
                    type: "int",
                },
                Items: {
                    markdownDescription: "List of items in this container.",
                    type: "list",
                    items: {
                        markdownDescription: "An item, including the slot tag.",
                        type: "compound",
                        required: ["Slot"],
                        properties: {
                            Slot: {
                                markdownDescription: "The inventory slot the item is in.",
                                type: "byte",
                            },
                        },
                    },
                },
                PotionId: {
                    markdownDescription: "If the cauldron contains a potion, this tag stores the ID of that potion. If there is no potion stored, then this tag is set to -1.",
                    type: "short",
                },
                PotionType: {
                    markdownDescription: "If the cauldron contains a potion, this tag stores the type of that potion. 0 is normal, 1 is splash, 2 is lingering. If there is no potion stored, then this tag is set to -1.",
                    type: "short",
                },
            },
            $fragment: false,
        },
        Block_Chalkboard: {
            id: "Block_Chalkboard",
            markdownDescription: "Additional fields for [chalkboard](https://minecraft.wiki/w/chalkboard).",
            type: "compound",
            required: ["BaseX", "BaseY", "BaseZ", "Locked", "OnGround", "Owner", "Size", "Text"],
            properties: {
                BaseX: {
                    markdownDescription: "The X position of its base.",
                    type: "int",
                },
                BaseY: {
                    markdownDescription: "The Y position of its base.",
                    type: "int",
                },
                BaseZ: {
                    markdownDescription: "The Z position of its base.",
                    type: "int",
                },
                Locked: {
                    markdownDescription: "1 or 0 (true/false) - true if it is on locked.",
                    type: "byte",
                },
                OnGround: {
                    markdownDescription: "1 or 0 (true/false) - true if it is on ground.",
                    type: "byte",
                },
                Owner: {
                    markdownDescription: "The Unique ID of its owner.",
                    type: "long",
                },
                Size: {
                    markdownDescription: "The size of this chalkboard.",
                    type: "int",
                },
                Text: {
                    markdownDescription: "The text on the chalkboard.",
                    type: "string",
                },
            },
            $fragment: false,
        },
        Block_ChemistryTables: {
            id: "Block_ChemistryTables",
            markdownDescription: "Additional fields for chemistry tables ([compound creator](https://minecraft.wiki/w/compound_creator), [element constructor](https://minecraft.wiki/w/element_constructor), [lab table](https://minecraft.wiki/w/lab_table), [material reducer](https://minecraft.wiki/w/material_reducer)).",
            type: "compound",
            required: ["itemAux", "itemId", "itemStack"],
            properties: {
                itemAux: {
                    markdownDescription: "(Only for Lab Table) UNDOCUMENTED.",
                    type: "short",
                },
                itemId: {
                    markdownDescription: "(Only for Lab Table) UNDOCUMENTED.",
                    type: "int",
                },
                itemStack: {
                    markdownDescription: "(Only for Lab Table) UNDOCUMENTED.",
                    type: "byte",
                },
            },
            $fragment: false,
        },
        Block_Chests: {
            id: "Block_Chests",
            markdownDescription: "Additional fields for [chest](https://minecraft.wiki/w/chest), [trapped chest](https://minecraft.wiki/w/trapped_chest), [barrel](https://minecraft.wiki/w/barrel), and [ender chest](https://minecraft.wiki/w/ender_chest).",
            type: "compound",
            required: ["Findable", "forceunpair", "Items"],
            properties: {
                Findable: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
                forceunpair: {
                    markdownDescription: "1 or 0 (true/false) - (may not exist) true if this chest is unpair with chest next to it.",
                    type: "byte",
                },
                Items: {
                    markdownDescription: "List of items in this container.",
                    type: "list",
                    items: {
                        markdownDescription: "An item, including the slot tag.",
                        type: "compound",
                        required: ["Slot"],
                        properties: {
                            Slot: {
                                markdownDescription: "The inventory slot the item is in.",
                                type: "byte",
                            },
                        },
                    },
                },
                LootTable: {
                    markdownDescription: "(May not exist) Loot table to be used to fill the chest when it is next opened, or the items are otherwise interacted with.",
                    type: "string",
                },
                LootTableSeed: {
                    markdownDescription: "(May not exist) Seed for generating the loot table. 0 or omitted use a random seed.",
                    type: "int",
                },
                pairlead: {
                    markdownDescription: "(May not exist) UNDOCUMENTED.",
                    type: "byte",
                },
                pairx: {
                    markdownDescription: "(May not exist) The X position of the chest paired with.",
                    type: "int",
                },
                pairz: {
                    markdownDescription: "(May not exist) The Z position of the chest paired with.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Block_ChiseledBookshelf: {
            id: "Block_ChiseledBookshelf",
            markdownDescription: "Additional fields for [chiseled bookshelf](https://minecraft.wiki/w/chiseled_bookshelf).",
            type: "compound",
            required: ["Items", "LastInteractedSlot"],
            properties: {
                Items: {
                    markdownDescription: "List of books in the bookshelf.",
                    type: "list",
                    items: {
                        markdownDescription: "An item in the chiseled bookshelf.",
                        type: "compound",
                        $ref: "Item_ItemStack",
                    },
                },
                LastInteractedSlot: {
                    markdownDescription: "Last interacted slot (1-6), or 0 if no slot has been interacted with yet.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Block_CommandBlock: {
            id: "Block_CommandBlock",
            markdownDescription: "Additional fields for [command block](https://minecraft.wiki/w/command_block).",
            type: "compound",
            required: ["auto", "conditionMet", "LPCondionalMode", "LPRedstoneMode", "LPCommandMode", "powered"],
            properties: {
                auto: {
                    markdownDescription: "1 or 0 (true/false) - Allows to activate the command without the requirement of a redstone signal.",
                    type: "byte",
                },
                conditionalMode: {
                    markdownDescription: "(May not exist) UNDOCUMENTED.",
                    type: "byte",
                },
                conditionMet: {
                    markdownDescription: "1 or 0 (true/false) - if a conditional command block had its condition met when last activated. True if not a conditional command block.",
                    type: "byte",
                },
                LPCondionalMode: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
                LPRedstoneMode: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
                LPCommandMode: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
                powered: {
                    markdownDescription: "1 or 0 (true/false) - true if the command block is powered by redstone.",
                    type: "byte",
                },
            },
            allOf: [
                {
                    $ref: "CommandBlock",
                },
            ],
            $fragment: false,
        },
        Block_Comparator: {
            id: "Block_Comparator",
            markdownDescription: "Additional fields for [comparator](https://minecraft.wiki/w/comparator).",
            type: "compound",
            required: ["OutputSignal"],
            properties: {
                OutputSignal: {
                    markdownDescription: "Represents the strength of the analog signal output of this redstone comparator.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Block_Conduit: {
            id: "Block_Conduit",
            markdownDescription: "Additional fields for [conduit](https://minecraft.wiki/w/conduit).",
            type: "compound",
            required: ["Active", "Target"],
            properties: {
                Active: {
                    markdownDescription: "1 or 0 (true/false) - true if it is active.",
                    type: "byte",
                },
                Target: {
                    markdownDescription: "The Unique ID of the hostile mob the conduit is currently attacking. If there's no target, defaults to -1.",
                    type: "long",
                },
            },
            $fragment: false,
        },
        Block_Crafter: {
            id: "Block_Crafter",
            markdownDescription: "Additional fields for [crafter](https://minecraft.wiki/w/crafter).",
            type: "compound",
            required: ["disabled_slots", "Items"],
            properties: {
                disabled_slots: {
                    markdownDescription: "Indexes of slots that are disabled.",
                    type: "short",
                },
                Items: {
                    markdownDescription: "List of items in the crafter.",
                    type: "list",
                    items: {
                        markdownDescription: "An item in the crafter, including the slot tag. Crafter slots are numbered 0-8. 0 starts in the top left corner.",
                        type: "compound",
                        required: ["Slot"],
                        properties: {
                            Slot: {
                                markdownDescription: "The inventory slot the item is in.",
                                type: "byte",
                            },
                        },
                    },
                },
            },
            $fragment: false,
        },
        Block_DecoratedPot: {
            id: "Block_DecoratedPot",
            markdownDescription: "Additional fields for [decorated pot](https://minecraft.wiki/w/decorated_pot).",
            type: "compound",
            required: ["item", "sherds"],
            properties: {
                item: {
                    markdownDescription: "The item in the decorated pot.",
                    type: "compound",
                    $ref: "Item_ItemStack",
                },
                sherds: {
                    markdownDescription: "List of sherds on this decorated pot.",
                    type: "list",
                    items: {
                        markdownDescription: "[Item ID](https://minecraft.wiki/w/Bedrock_Edition_data_values) of this face. Defaults to `minecraft:brick`.",
                        type: "string",
                    },
                },
            },
            $fragment: false,
        },
        Block_DispenserAndDropper: {
            id: "Block_DispenserAndDropper",
            markdownDescription: "Additional fields for [dispenser](https://minecraft.wiki/w/dispenser) and [dropper](https://minecraft.wiki/w/dropper).",
            type: "compound",
            required: ["Items"],
            properties: {
                Items: {
                    markdownDescription: "List of items in this container.",
                    type: "list",
                    items: {
                        markdownDescription: "An item, including the slot tag.",
                        type: "compound",
                        required: ["Slot"],
                        properties: {
                            Slot: {
                                markdownDescription: "The inventory slot the item is in.",
                                type: "byte",
                            },
                        },
                    },
                },
                LootTable: {
                    markdownDescription: "(May not exist) Loot table to be used to fill the chest when it is next opened, or the items are otherwise interacted with.",
                    type: "string",
                },
                LootTableSeed: {
                    markdownDescription: "(May not exist) Seed for generating the loot table. 0 or omitted use a random seed.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Block_EnchantmentTable: {
            id: "Block_EnchantmentTable",
            markdownDescription: "Additional fields for [Enchantment table](https://minecraft.wiki/w/Enchantment_table).",
            type: "compound",
            required: ["rott"],
            properties: {
                CustomName: {
                    markdownDescription: "(May not exist) The name of this enchantment table.",
                    type: "string",
                },
                rott: {
                    markdownDescription: "The clockwise rotation of the book in radians. Top of the book points West when 0.",
                    type: "float",
                },
            },
            $fragment: false,
        },
        Block_EndGateway: {
            id: "Block_EndGateway",
            markdownDescription: "Additional fields for [end gateway](https://minecraft.wiki/w/end_gateway).",
            type: "compound",
            required: ["Age", "ExitPortal"],
            properties: {
                Age: {
                    markdownDescription: "Age of the portal, in ticks. This is used to determine when the beam is rendered.",
                    type: "int",
                },
                ExitPortal: {
                    markdownDescription: "Location entities are teleported to when entering the portal.",
                    type: "list",
                    items: [
                        {
                            markdownDescription: "X coordinate of target location.",
                            type: "int",
                        },
                        {
                            markdownDescription: "Y coordinate of target location.",
                            type: "int",
                        },
                        {
                            markdownDescription: "Z coordinate of target location.",
                            type: "int",
                        },
                    ],
                },
            },
            $fragment: false,
        },
        Block_FlowerPot: {
            id: "Block_FlowerPot",
            markdownDescription: "Additional fields for [flower pot](https://minecraft.wiki/w/flower_pot).",
            type: "compound",
            properties: {
                PlantBlock: {
                    markdownDescription: "(May not exist) The block in the pot.",
                    type: "compound",
                    $ref: "Block",
                },
            },
            $fragment: false,
        },
        Block_Furnace: {
            id: "Block_Furnace",
            markdownDescription: "Additional fields for [furnace](https://minecraft.wiki/w/furnace), [smoker](https://minecraft.wiki/w/smoker), and [blast furnace](https://minecraft.wiki/w/blast_furnace).",
            type: "compound",
            required: ["BurnDuration", "BurnTime", "CookTime", "Items", "StoredXPInt"],
            properties: {
                BurnDuration: {
                    markdownDescription: "The total time that in ticks that the currently used fuel can burn.",
                    type: "short",
                },
                BurnTime: {
                    markdownDescription: "Number of ticks left before the current fuel runs out.",
                    type: "short",
                },
                CookTime: {
                    markdownDescription: "Number of ticks the item has been smelting for. The item finishes smelting when this value reaches 200 (10 seconds). Is reset to 0 if BurnTime reaches 0. *needs testing*",
                    type: "short",
                },
                Items: {
                    markdownDescription: "List of items in this container.",
                    type: "list",
                    items: {
                        markdownDescription: "An item in the furnace, including the slot tag.",
                        type: "compound",
                        required: ["Slot"],
                        properties: {
                            Slot: {
                                markdownDescription: "The inventory slot the item is in.",
                                type: "byte",
                            },
                        },
                    },
                },
                StoredXPInt: {
                    markdownDescription: "The number of experiences it stores.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Block_Hopper: {
            id: "Block_Hopper",
            markdownDescription: "Additional fields for [hopper](https://minecraft.wiki/w/hopper).",
            type: "compound",
            required: ["Items", "TransferCooldown"],
            properties: {
                Items: {
                    markdownDescription: "List of items in this container.",
                    type: "list",
                    items: {
                        markdownDescription: "An item, including the slot tag.",
                        type: "compound",
                        required: ["Slot"],
                        properties: {
                            Slot: {
                                markdownDescription: "The inventory slot the item is in.",
                                type: "byte",
                            },
                        },
                    },
                },
                TransferCooldown: {
                    markdownDescription: "Time until the next transfer in game ticks, naturally between 1 and 8 or 0 if there is no transfer.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Block_ItemFrame: {
            id: "Block_ItemFrame",
            markdownDescription: "Additional fields for [item frame](https://minecraft.wiki/w/item_frame).",
            type: "compound",
            required: ["Item"],
            properties: {
                Item: {
                    markdownDescription: "The items in this item frame.",
                    type: "compound",
                    $ref: "Item_ItemStack",
                },
                ItemDropChance: {
                    markdownDescription: "(May not exist) The chance of item dropping when the item frame is broken.",
                    type: "float",
                },
                ItemRotation: {
                    markdownDescription: "(May not exist) The rotation of the item in the item frame.",
                    type: "float",
                },
            },
            $fragment: false,
        },
        Block_Jigsaw: {
            id: "Block_Jigsaw",
            markdownDescription: "Additional fields for [jigsaw](https://minecraft.wiki/w/jigsaw).",
            type: "compound",
            required: ["final_state", "joint", "name", "target", "target_pool"],
            properties: {
                final_state: {
                    markdownDescription: "The block that this jigsaw block becomes.",
                    type: "string",
                },
                joint: {
                    markdownDescription: 'The joint option value, either "rollable" or "aligned".',
                    type: "string",
                },
                name: {
                    markdownDescription: "The jigsaw block's name. This jigsaw block will be aligned with another structure's jigsaw block which has this value in the target tag.",
                    type: "string",
                },
                target: {
                    markdownDescription: "The jigsaw block's target name. This jigsaw block will be aligned with another structure's jigsaw block which has this value in the name tag.",
                    type: "string",
                },
                target_pool: {
                    markdownDescription: "The jigsaw block's target pool to select a structure from.",
                    type: "string",
                },
            },
            $fragment: false,
        },
        Block_Jukebox: {
            id: "Block_Jukebox",
            markdownDescription: "Additional fields for [jukebox](https://minecraft.wiki/w/jukebox).",
            type: "compound",
            properties: {
                RecordItem: {
                    markdownDescription: "(May not exist) The record item in it.",
                    type: "compound",
                    $ref: "Item_ItemStack",
                },
            },
            $fragment: false,
        },
        Block_Lectern: {
            id: "Block_Lectern",
            markdownDescription: "Additional fields for [lectern](https://minecraft.wiki/w/lectern).",
            type: "compound",
            required: ["hasBook"],
            properties: {
                book: {
                    markdownDescription: "(May not exist) The book item currently on the lectern.",
                    type: "compound",
                    $ref: "Item_ItemStack",
                },
                hasBook: {
                    markdownDescription: "1 or 0 (true/false) - (may not exist) true if it has a book.",
                    type: "byte",
                },
                page: {
                    markdownDescription: "(May not exist) The page the book is currently on, starting from 0.",
                    type: "int",
                },
                totalPages: {
                    markdownDescription: "(May not exist) The total pages the book has.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Block_Lodestone: {
            id: "Block_Lodestone",
            markdownDescription: "Additional fields for [lodestone](https://minecraft.wiki/w/lodestone).",
            type: "compound",
            properties: {
                trackingHandle: {
                    markdownDescription: "(May not exist) The id of lodestone.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Block_MonsterSpawner: {
            id: "Block_MonsterSpawner",
            markdownDescription: "Additional fields for [monster spawner](https://minecraft.wiki/w/monster_spawner).",
            type: "compound",
            $ref: "MonsterSpawner",
            $fragment: false,
        },
        Block_MovingBlock: {
            id: "Block_MovingBlock",
            markdownDescription: "Additional fields for [moving block](https://minecraft.wiki/w/moving_block).",
            type: "compound",
            required: ["movingBlock", "movingBlockExtra", "pistonPosX", "pistonPosY", "pistonPosZ"],
            properties: {
                movingBlock: {
                    markdownDescription: "The main layer of moving block represented by this block entity.",
                    type: "compound",
                    $ref: "Block",
                },
                movingBlockExtra: {
                    markdownDescription: "The [extra moving block layer](https://minecraft.wiki/w/Waterlogging) represented by this block entity.",
                    type: "compound",
                    $ref: "Block",
                },
                movingEntity: {
                    markdownDescription: "(May not exist) The block entity stored in this moving block.",
                    type: "compound",
                    $ref: "BlockEntity",
                },
                pistonPosX: {
                    markdownDescription: "X coordinate of the piston base.",
                    type: "int",
                },
                pistonPosY: {
                    markdownDescription: "Y coordinate of the piston base.",
                    type: "int",
                },
                pistonPosZ: {
                    markdownDescription: "Z coordinate of the piston base.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Block_NoteBlock: {
            id: "Block_NoteBlock",
            markdownDescription: "Additional fields for [note block](https://minecraft.wiki/w/note_block).",
            type: "compound",
            required: ["note"],
            properties: {
                note: {
                    markdownDescription: "The pitch of the note block.",
                    type: "byte",
                },
            },
            $fragment: false,
        },
        Block_NetherReactor: {
            id: "Block_NetherReactor",
            markdownDescription: "Additional fields for [nether reactor](https://minecraft.wiki/w/nether_reactor).",
            type: "compound",
            required: ["HasFinished", "IsInitialized", "Progress"],
            properties: {
                HasFinished: {
                    markdownDescription: "1 or 0 (true/false) - true if the reactor has completed its activation phase, and has gone dark.",
                    type: "byte",
                },
                IsInitialized: {
                    markdownDescription: "1 or 0 (true/false) - true if the reactor has been activated, and has turned red.",
                    type: "byte",
                },
                Progress: {
                    markdownDescription: "Number of ticks the reactor has been active for. It finishes after 900 game ticks (45 seconds).",
                    type: "short",
                },
            },
            $fragment: false,
        },
        Block_Piston: {
            id: "Block_Piston",
            markdownDescription: "Additional fields for [piston](https://minecraft.wiki/w/piston).",
            type: "compound",
            required: ["AttachedBlocks", "BreakBlocks", "LastProgress", "NewState", "Progress", "State", "Sticky"],
            properties: {
                AttachedBlocks: {
                    markdownDescription: "The list of positions of blocks it should move.",
                    type: "list",
                    items: [
                        {
                            markdownDescription: "A block's X coordinate.",
                            type: "int",
                        },
                        {
                            markdownDescription: "A block's Y coordinate.",
                            type: "int",
                        },
                        {
                            markdownDescription: "A block's Z coordinate.",
                            type: "int",
                        },
                        {
                            markdownDescription: "Another block's X coordinate.",
                            type: "int",
                        },
                        {
                            markdownDescription: "Another block's Y coordinate.",
                            type: "int",
                        },
                        {
                            markdownDescription: "Another block's Z coordinate.",
                            type: "int",
                        },
                        {
                            markdownDescription: "etc.",
                            type: "int",
                        },
                    ],
                },
                BreakBlocks: {
                    markdownDescription: "The list of positions of blocks it should break.",
                    type: "list",
                    items: [
                        {
                            markdownDescription: "A block's X coordinate.",
                            type: "int",
                        },
                        {
                            markdownDescription: "A block's Y coordinate.",
                            type: "int",
                        },
                        {
                            markdownDescription: "A block's Z coordinate.",
                            type: "int",
                        },
                        {
                            markdownDescription: "Another block's X coordinate.",
                            type: "int",
                        },
                        {
                            markdownDescription: "Another block's Y coordinate.",
                            type: "int",
                        },
                        {
                            markdownDescription: "Another block's Z coordinate.",
                            type: "int",
                        },
                        {
                            markdownDescription: "etc.",
                            type: "int",
                        },
                    ],
                },
                LastProgress: {
                    markdownDescription: "Progress in last tick.",
                    type: "float",
                },
                NewState: {
                    markdownDescription: "Next state. Can be 0 (unextended), 1 (pushing), 2 (extended), or 3 (pulling).",
                    type: "byte",
                    markdownEnumDescriptions: ["unextended", "pushing", "extended", "pulling"],
                    enum: [
                        { type: "byte", value: 0 },
                        { type: "byte", value: 1 },
                        { type: "byte", value: 2 },
                        { type: "byte", value: 3 },
                    ],
                },
                Progress: {
                    markdownDescription: "How far the block has been moved. Can be 0.0, 0.5, and 1.0.",
                    type: "float",
                },
                State: {
                    markdownDescription: "Current state.",
                    type: "byte",
                },
                Sticky: {
                    markdownDescription: "1 or 0 (true/false) - true if this piston is sticky.",
                    type: "byte",
                },
            },
            $fragment: false,
        },
        Block_SculkCatalyst: {
            id: "Block_SculkCatalyst",
            markdownDescription: "Additional fields for [sculk catalyst](https://minecraft.wiki/w/sculk_catalyst).",
            type: "compound",
            required: ["cursors"],
            properties: {
                cursors: {
                    markdownDescription: "List of charges associated with the sculk catalyst.",
                    type: "list",
                    items: {
                        markdownDescription: "A charge.",
                        type: "compound",
                        required: ["charge", "decay", "facing", "update", "x", "y", "z"],
                        properties: {
                            charge: {
                                markdownDescription: "How much power is in the charge.",
                                type: "short",
                            },
                            decay: {
                                markdownDescription: "Be 1 if the charge was spread from a sculk or sculk vein, 0 otherwise. The charge can spread to any block if this tag is 1. If it is 0, all the powers in the charge disappear when it spreads to a block not in sculk family. *needs testing*",
                                type: "short",
                            },
                            facing: {
                                markdownDescription: "UNDOCUMENTED.",
                                type: "short",
                            },
                            update: {
                                markdownDescription: "Delay in ticks until the charge begins to travel after being created. *needs testing*",
                                type: "short",
                            },
                            x: {
                                markdownDescription: "X coordinate of the charge.",
                                type: "int",
                            },
                            y: {
                                markdownDescription: "Y coordinate of the charge.",
                                type: "int",
                            },
                            z: {
                                markdownDescription: "Z coordinate of the charge.",
                                type: "int",
                            },
                        },
                    },
                },
            },
            $fragment: false,
        },
        Block_SculkShrieker_SculkSensor_AndCalibratedSculkSensor: {
            id: "Block_SculkShrieker_SculkSensor_AndCalibratedSculkSensor",
            markdownDescription: "Additional fields for [sculk shrieker](https://minecraft.wiki/w/sculk_shrieker), [sculk sensor](https://minecraft.wiki/w/sculk_sensor), and [calibrated sculk sensor](https://minecraft.wiki/w/calibrated_sculk_sensor).",
            type: "compound",
            required: ["VibrationListener"],
            properties: {
                VibrationListener: {
                    markdownDescription: "The vibration event listener of the sculk shrieker, sculk sensor, and calibrated sculk sensor.",
                    type: "compound",
                    required: ["event", "pending", "selector", "ticks"],
                    properties: {
                        event: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "int",
                        },
                        pending: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "compound",
                            required: ["distance", "source", "vibration", "x", "y", "z"],
                            properties: {
                                distance: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "float",
                                },
                                source: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "long",
                                },
                                vibration: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "int",
                                },
                                x: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "int",
                                },
                                y: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "int",
                                },
                                z: {
                                    markdownDescription: "UNDOCUMENTED.",
                                    type: "int",
                                },
                            },
                        },
                        selector: {
                            markdownDescription: "UNKNOWN.",
                            type: "compound",
                        },
                        ticks: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "int",
                        },
                    },
                },
            },
            $fragment: false,
        },
        Block_ShulkerBox: {
            id: "Block_ShulkerBox",
            markdownDescription: "Additional fields for [shulker box](https://minecraft.wiki/w/shulker_box).",
            type: "compound",
            required: ["facing"],
            properties: {
                facing: {
                    markdownDescription: "The facing of this shulker box.",
                    type: "float",
                },
            },
            allOf: [
                {
                    $ref: "Block_Chests",
                },
            ],
            $fragment: false,
        },
        Block_SignAndHangingSign: {
            id: "Block_SignAndHangingSign",
            markdownDescription: "Additional fields for [sign](https://minecraft.wiki/w/sign) and hanging sign.",
            type: "compound",
            required: ["BackText", "FrontText", "IsWaxed"],
            properties: {
                BackText: {
                    markdownDescription: "A compound which discribes back text. The same structure as FrontText.",
                    type: "compound",
                    required: ["HideGlowOutline", "IgnoreLighting", "PersistFormatting", "SignTextColor", "Text", "TextOwner"],
                    properties: {
                        HideGlowOutline: {
                            markdownDescription: "1 or 0 (true/false) - true if the outer glow of a sign with glowing text does not show.",
                            type: "byte",
                        },
                        IgnoreLighting: {
                            markdownDescription: "1 or 0 (true/false) - true if the sign has been dyed with a [glow ink sac](https://minecraft.wiki/w/glow_ink_sac).",
                            type: "byte",
                        },
                        PersistFormatting: {
                            markdownDescription: "UNDOCUMENTED. Defaults to 1.",
                            type: "byte",
                        },
                        SignTextColor: {
                            markdownDescription: 'The color that has been used to dye the sign. Is a 32-bit encoded color, defaults to `-16777216` (black). One of `-986896` for "White", `-425955` for "Orange", `-3715395` for "Magenta", `-12930086` for "Light Blue", `-75715` for "Yellow", `-8337633` for "Lime", `-816214` for "Pink", `-12103854` for "Gray", `-6447721` for "Light Gray", `-15295332` for "Cyan", `-7785800` for "Purple", `-12827478` for "Blue", `-8170446` for "Brown", `-10585066` for "Green", `-5231066` for "Red", and `-16777216` for "Black".',
                            type: "int",
                        },
                        Text: {
                            markdownDescription: "The text on it.",
                            type: "string",
                        },
                        TextOwner: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "string",
                        },
                    },
                },
                FrontText: {
                    markdownDescription: "A compound which discribes front text.",
                    type: "compound",
                    required: ["HideGlowOutline", "IgnoreLighting", "PersistFormatting", "SignTextColor", "Text", "TextOwner"],
                    properties: {
                        HideGlowOutline: {
                            markdownDescription: "1 or 0 (true/false) - true if the outer glow of a sign with glowing text does not show.",
                            type: "byte",
                        },
                        IgnoreLighting: {
                            markdownDescription: "1 or 0 (true/false) - true if the sign has been dyed with a [glow ink sac](https://minecraft.wiki/w/glow_ink_sac).",
                            type: "byte",
                        },
                        PersistFormatting: {
                            markdownDescription: "UNDOCUMENTED. Defaults to 1.",
                            type: "byte",
                        },
                        SignTextColor: {
                            markdownDescription: 'The color that has been used to dye the sign. Is a 32-bit encoded color, defaults to `-16777216` (black). One of `-986896` for "White", `-425955` for "Orange", `-3715395` for "Magenta", `-12930086` for "Light Blue", `-75715` for "Yellow", `-8337633` for "Lime", `-816214` for "Pink", `-12103854` for "Gray", `-6447721` for "Light Gray", `-15295332` for "Cyan", `-7785800` for "Purple", `-12827478` for "Blue", `-8170446` for "Brown", `-10585066` for "Green", `-5231066` for "Red", and `-16777216` for "Black".',
                            type: "int",
                        },
                        Text: {
                            markdownDescription: "The text on it.",
                            type: "string",
                        },
                        TextOwner: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "string",
                        },
                    },
                },
                IsWaxed: {
                    markdownDescription: "1 or 0 (true/false) - true if the text is locked with [honeycomb](https://minecraft.wiki/w/honeycomb).",
                    type: "byte",
                },
            },
            $fragment: false,
        },
        Block_Skull: {
            id: "Block_Skull",
            markdownDescription: "Additional fields for [skull](https://minecraft.wiki/w/skull).",
            type: "compound",
            required: ["MouthMoving", "MouthTickCount", "Rotation"],
            properties: {
                MouthMoving: {
                    markdownDescription: "1 or 0 (true/false) - true if this dragon head's mouth is moving.",
                    type: "byte",
                },
                MouthTickCount: {
                    markdownDescription: "The animation frame of the dragon head's mouth movement. *needs testing*",
                    type: "int",
                },
                Rotation: {
                    markdownDescription: "The rotation of this skull.",
                    type: "float",
                },
            },
            $fragment: false,
        },
        Block_StructureBlock: {
            id: "Block_StructureBlock",
            markdownDescription: "Additional fields for [structure block](https://minecraft.wiki/w/structure_block).",
            type: "compound",
            required: [
                "animationMode",
                "animationSeconds",
                "data",
                "dataField",
                "ignoreEntities",
                "integrity",
                "isPowered",
                "mirror",
                "redstoneSaveMode",
                "removeBlocks",
                "rotation",
                "seed",
                "showBoundingBox",
                "structureName",
                "xStructureOffset",
                "yStructureOffset",
                "zStructureOffset",
                "xStructureSize",
                "yStructureSize",
                "zStructureSize",
            ],
            properties: {
                animationMode: {
                    markdownDescription: "The mode of animation.",
                    type: "byte",
                },
                animationSeconds: {
                    markdownDescription: "The duration of the animation.",
                    type: "float",
                },
                data: {
                    markdownDescription: "The mode of the structure block, values for data are the same as the data values for the item. Ex. 0 = Data, 1 = Save, 2 = Load, 3 = Corner, 4 = Inventory, 5 = Export.",
                    type: "int",
                },
                dataField: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "string",
                },
                ignoreEntities: {
                    markdownDescription: "1 or 0 (true/false) - true if the entities should be ignored in the structure.",
                    type: "byte",
                },
                integrity: {
                    markdownDescription: "How complete the structure is that gets placed.",
                    type: "float",
                },
                isPowered: {
                    markdownDescription: "1 or 0 (true/false) - true if this structure block is being powered by redstone.",
                    type: "byte",
                },
                mirror: {
                    markdownDescription: "How the structure is mirrored.",
                    type: "byte",
                },
                redstoneSaveMode: {
                    markdownDescription: "The current redstone mode of this structure block.",
                    type: "int",
                },
                removeBlocks: {
                    markdownDescription: "1 or 0 (true/false) - true if the blocks should be removed in the structure.",
                    type: "byte",
                },
                rotation: {
                    markdownDescription: "Rotation of the structure.",
                    type: "byte",
                },
                seed: {
                    markdownDescription: "The seed to use for the structure integrity, 0 means random. *needs testing*",
                    type: "long",
                },
                showBoundingBox: {
                    markdownDescription: "1 or 0 (true/false) - true if show the structure's bounding box to players in Creative mode.",
                    type: "byte",
                },
                structureName: {
                    markdownDescription: "Name of the structure.",
                    type: "string",
                },
                xStructureOffset: {
                    markdownDescription: "X-offset of the structure.",
                    type: "int",
                },
                yStructureOffset: {
                    markdownDescription: "Y-offset of the structure.",
                    type: "int",
                },
                zStructureOffset: {
                    markdownDescription: "Z-offset of the structure.",
                    type: "int",
                },
                xStructureSize: {
                    markdownDescription: "X-size of the structure.",
                    type: "int",
                },
                yStructureSize: {
                    markdownDescription: "Y-size of the structure.",
                    type: "int",
                },
                zStructureSize: {
                    markdownDescription: "Z-size of the structure.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Block_SuspiciousBlock: {
            id: "Block_SuspiciousBlock",
            markdownDescription: "Additional fields for [suspicious sand](https://minecraft.wiki/w/suspicious_sand) and [suspicious gravel](https://minecraft.wiki/w/suspicious_gravel).",
            type: "compound",
            required: ["brush_count", "brush_direction", "type"],
            properties: {
                brush_count: {
                    markdownDescription: "The number of times the suspicious block is being brushed by the player, from 1 to 10 (the item will be extracted when it reaches 10). If the player stops brushing, it will progressively return to 0. And if it hasn't been brushed yet, defaults to 0.",
                    type: "int",
                },
                brush_direction: {
                    markdownDescription: "The direction of the suspicious block that was brushed. 0 = Down, 1 = Up, 2 = North, 3 = South, 4 = West, 5 = East, or 6 if it has not been brushed yet.",
                    type: "byte",
                },
                item: {
                    markdownDescription: "(May not exist) The item in the suspicious block.",
                    type: "compound",
                    $ref: "Item_ItemStack",
                },
                LootTable: {
                    markdownDescription: "(May not exist) Loot table to be used to generate the hidden item when brushed.",
                    type: "string",
                },
                LootTableSeed: {
                    markdownDescription: "(May not exist) Seed for generating the loot table. 0 or omitted use a random seed.",
                    type: "int",
                },
                type: {
                    markdownDescription: "The type of suspicious block. Valid types are `minecraft:suspicious_sand` and `minecraft:suspicious_gravel`.",
                    type: "string",
                },
            },
            $fragment: false,
        },
        Block_TrialSpawner: {
            id: "Block_TrialSpawner",
            markdownDescription: "Additional fields for [trial spawner](https://minecraft.wiki/w/trial_spawner) and [ominous trial spawner](https://minecraft.wiki/w/ominous_trial_spawner).",
            type: "compound",
            required: [
                "required_player_range",
                "normal_config",
                "ominous_config",
                "registered_players",
                "current_mobs",
                "cooldown_end_at",
                "next_mob_spawns_at",
                "spawn_data",
                "selected_loot_table",
            ],
            properties: {
                required_player_range: {
                    markdownDescription: "Between 1 and 128. Defaults to 14. &mdash; Maximum distance in blocks for players to join the battle.",
                    type: "int",
                },
                normal_config: {
                    markdownDescription: "Optional, see configuration for defaults. &mdash; The configuration to use when not ominous.",
                    type: "compound",
                    required: [
                        "spawn_range",
                        "total_mobs",
                        "simultaneous_mobs",
                        "total_mobs_added_per_player",
                        "simultaneous_mobs_added_per_player",
                        "ticks_between_spawn",
                        "target_cooldown_length",
                        "spawn_potentials",
                        "loot_tables_to_eject",
                        "items_to_drop_when_ominous",
                    ],
                    properties: {
                        spawn_range: {
                            markdownDescription: "Between 1 and 128. Defaults to 4. &mdash; Maximum distance in blocks that mobs can spawn.",
                            type: "int",
                        },
                        total_mobs: {
                            markdownDescription: "Defaults to 6. &mdash; Total amount of mobs spawned before cooldown for a single player.",
                            type: "float",
                        },
                        simultaneous_mobs: {
                            markdownDescription: "Defaults to 2. &mdash; The amount of spawned mobs from this spawner that are allowed to exist simultaneously.",
                            type: "float",
                        },
                        total_mobs_added_per_player: {
                            markdownDescription: "Defaults to 2. &mdash; Amount of total mobs added for each additional player.",
                            type: "float",
                        },
                        simultaneous_mobs_added_per_player: {
                            markdownDescription: "Defaults to 1. &mdash; Amount of simultaneous mobs added for each additional player.",
                            type: "float",
                        },
                        ticks_between_spawn: {
                            markdownDescription: "Defaults to 20. &mdash; Time in ticks between spawn attempts.",
                            type: "int",
                        },
                        target_cooldown_length: {
                            markdownDescription: "Defaults to 36000. &mdash; Time in ticks of the cooldown period. Includes the time spend dispensing the reward.",
                            type: "int",
                        },
                        spawn_potentials: {
                            markdownDescription: "List of possible entities to spawn.",
                            type: "list",
                            items: {
                                markdownDescription: "A potential future spawn. _After_ the spawner makes an attempt at spawning, it chooses one of these entries at random and uses it to prepare for the next spawn.",
                                type: "compound",
                                required: ["Weight", "TypeID", "equipment_loot_table"],
                                properties: {
                                    Weight: {
                                        markdownDescription: "The chance that this spawn gets picked in comparison to other spawn weights. Must be positive and at least 1.",
                                        type: "int",
                                    },
                                    TypeID: {
                                        markdownDescription: "An entity ID.",
                                        type: "string",
                                    },
                                    equipment_loot_table: {
                                        markdownDescription: "Optional path to a [loot table](https://minecraft.wiki/w/loot_table). Determines the equipment the entity will wear.",
                                        type: "string",
                                    },
                                },
                            },
                        },
                        loot_tables_to_eject: {
                            markdownDescription: "List of possible loot tables to give as reward.",
                            type: "list",
                            items: {
                                markdownDescription: "A potential loot table.",
                                type: "compound",
                                required: ["weight", "data"],
                                properties: {
                                    weight: {
                                        markdownDescription: "The chance that this loot table gets picked in comparison to other loot table weights. Must be positive and at least 1.",
                                        type: "int",
                                    },
                                    data: {
                                        markdownDescription: "A path to a [loot table](https://minecraft.wiki/w/loot_table).",
                                        type: "string",
                                    },
                                },
                            },
                        },
                        items_to_drop_when_ominous: {
                            markdownDescription: "Defaults to `loot_tables/spawners/trial_chamber/items_to_drop_when_ominous.json` &mdash; A path to a [loot table](https://minecraft.wiki/w/loot_table). Determines the items used by [ominous item spawner](https://minecraft.wiki/w/ominous_item_spawner)s spawned during the active phase when ominous. Ignored in normal mode.",
                            type: "string",
                        },
                    },
                },
                ominous_config: {
                    markdownDescription: "Optional, defaults to normal_config. When individual entries are omitted, they also default to their setting in normal_config. &mdash; The configuration to use when ominous.",
                    type: "compound",
                },
                registered_players: {
                    markdownDescription: "A set of player UUIDs. &mdash; All the players that have joined the battle. The length of this array determines the amount of mobs and amount of reward.",
                    type: "list",
                    items: {
                        markdownDescription: "A player UUID.",
                        type: "compound",
                        required: ["uuid"],
                        properties: {
                            uuid: {
                                markdownDescription: "The UUID.",
                                type: "long",
                            },
                        },
                    },
                },
                current_mobs: {
                    markdownDescription: "A set of mob UUIDs. &mdash; The mobs that were spawned by this spawner and are still alive.",
                    type: "list",
                    items: {
                        markdownDescription: "An entity UUID.",
                        type: "compound",
                        required: ["uuid"],
                        properties: {
                            uuid: {
                                markdownDescription: "The UUID.",
                                type: "long",
                            },
                        },
                    },
                },
                cooldown_end_at: {
                    markdownDescription: "Gametime in ticks when the cooldown ends. 0 if not currently in cooldown.",
                    type: "long",
                },
                next_mob_spawns_at: {
                    markdownDescription: "Gametime in ticks when the next spawn attempt happens. 0 if not currently active.",
                    type: "long",
                },
                spawn_data: {
                    markdownDescription: "The next mob to attempt to spawn. Selected from spawn_potentials after the last attempt. Determines the mob displayed in the spawner.",
                    type: "compound",
                    required: ["Weight", "TypeID", "equipment_loot_table"],
                    properties: {
                        Weight: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "int",
                        },
                        TypeID: {
                            markdownDescription: "An entity ID.",
                            type: "string",
                        },
                        equipment_loot_table: {
                            markdownDescription: "Optional path to a [loot table](https://minecraft.wiki/w/loot_table). Determines the equipment the entity will wear.",
                            type: "string",
                        },
                    },
                },
                selected_loot_table: {
                    markdownDescription: "A path to the [loot table](https://minecraft.wiki/w/loot_table) that is given as reward. Unset if not currently giving rewards. Selected from loot_tables_to_eject after all mobs are defeated.",
                    type: "string",
                },
            },
            $fragment: false,
        },
        Block_Vault: {
            id: "Block_Vault",
            markdownDescription: "Additional fields for [vault](https://minecraft.wiki/w/vault) and [ominous vault](https://minecraft.wiki/w/ominous_vault).",
            type: "compound",
            required: ["config", "data"],
            properties: {
                config: {
                    markdownDescription: "Configuration data that does not automatically change. All fields are optional.",
                    type: "compound",
                    required: ["activation_range", "deactivation_range", "loot_table", "override_loot_table_to_display", "key_item"],
                    properties: {
                        activation_range: {
                            markdownDescription: "The range in blocks when the vault should activate. Defaults to 4.",
                            type: "float",
                        },
                        deactivation_range: {
                            markdownDescription: "The range in blocks when the vault should deactivate. Defaults to 4.5.",
                            type: "float",
                        },
                        loot_table: {
                            markdownDescription: "A path to the [loot table](https://minecraft.wiki/w/loot_table) that is ejected when unlocking the vault. Defaults to `loot_tables/chests/trial_chambers/reward.json` for _normal_ vaults and `loot_tables/chests/trial_chambers/reward_ominous.json` for _ominous_ vaults.",
                            type: "string",
                        },
                        override_loot_table_to_display: {
                            markdownDescription: "A path to the loot table that is used to display items in the vault. If not present, the game will use the loot_table field.",
                            type: "string",
                        },
                        key_item: {
                            markdownDescription: "The key item that is used to check for valid keys. Defaults to `minecraft:trial_key` for _normal_ vaults and `minecraft:ominous_trial_key` for _ominous_ vaults.",
                            type: "compound",
                            $ref: "Item_ItemStack",
                        },
                    },
                },
                data: {
                    markdownDescription: "Data that is used to keep track of the current state of the vault.",
                    type: "compound",
                    required: ["display_item", "items_to_eject", "rewarded_players", "state_updating_resumes_at", "total_ejections_needed"],
                    properties: {
                        display_item: {
                            markdownDescription: "The item that is currently being displayed.",
                            type: "compound",
                            $ref: "Item_ItemStack",
                        },
                        items_to_eject: {
                            markdownDescription: "List of item stacks that have been rolled by the loot table and are waiting to be ejected.",
                            type: "list",
                            items: {
                                markdownDescription: "An item stack.",
                                type: "compound",
                                $ref: "Item_ItemStack",
                            },
                        },
                        rewarded_players: {
                            markdownDescription: "A set of player UUIDs that have already received their rewards from this vault.",
                            type: "list",
                            items: {
                                markdownDescription: "A UUID.",
                                type: "long",
                            },
                        },
                        state_updating_resumes_at: {
                            markdownDescription: "The game time when the vault will process block state changes, such as changing from `unlocking` to `ejecting` after a delay.",
                            type: "long",
                        },
                        total_ejections_needed: {
                            markdownDescription: "The total amount of item stacks that need to be ejected.",
                            type: "long",
                        },
                    },
                },
            },
            $fragment: false,
        },
        //#endregion
        //#region Item NBT Schemas
        Item_ItemStackBase: {
            id: "Item_ItemStackBase",
            markdownDescription: "All items share this base.",
            type: "compound",
            required: ["Count", "Damage", "Name", "WasPickedUp"],
            properties: {
                Block: {
                    markdownDescription: "(May not exist) What block is placed when placing a block item.",
                    type: "compound",
                    $ref: "Block",
                },
                CanDestroy: {
                    markdownDescription: "(May not exist) Controls what block types this item can destroy.",
                    type: "list",
                    items: {
                        markdownDescription: "A block ID.",
                        type: "string",
                    },
                },
                CanPlaceOn: {
                    markdownDescription: "(May not exist) Controls what block types this block may be placed on.",
                    type: "list",
                    items: {
                        markdownDescription: "A block ID.",
                        type: "string",
                    },
                },
                Count: {
                    markdownDescription: "Number of items stacked in this inventory slot.",
                    type: "byte",
                },
                Damage: {
                    markdownDescription: "The metadata value. Note that this tag does not store items' damage value.",
                    type: "short",
                },
                Name: {
                    markdownDescription: "The item ID.",
                    type: "string",
                },
                tag: {
                    markdownDescription: "(May not exist) Additional information about the item.",
                    type: "compound",
                },
                WasPickedUp: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
            },
            $fragment: true,
        },
        Item_ItemStack: {
            id: "Item_ItemStack",
            markdownDescription: "All items share this base.",
            type: "compound",
            anyOf: [
                { $ref: "Item_GeneralTags" },
                { $ref: "Item_EnchantmentTags" },
                // { $ref: "Item_ArmorTrim" },
                // { $ref: "Item_BookAndQuills" },
                // { $ref: "Item_BucketOfAquaticMob" },
                // { $ref: "Item_Crossbow" },
                // { $ref: "Item_FilledMap" },
                // { $ref: "Item_FireworkRocket" },
                // { $ref: "Item_FireworkStar" },
                // { $ref: "Item_GlowStick" },
                // { $ref: "Item_HorseArmor" },
                // { $ref: "Item_LodestoneCompass" },
                // { $ref: "Item_Potion" },
                // { $ref: "Item_Shield" },
                // { $ref: "Item_WrittenBook" },
            ],
            allOf: [{ $ref: "Item_ItemStackBase" }],
            $fragment: true,
        },
        Item_GeneralTags: {
            id: "Item_GeneralTags",
            type: "compound",
            properties: {
                tag: {
                    type: "compound",
                    properties: {
                        Damage: {
                            markdownDescription: "(May not exist) The damage value for this item. Defaults to 0.",
                            type: "int",
                            default: { type: "int", value: 0 },
                        },
                        display: {
                            description: "(May not exist) Display properties.",
                            type: "compound",
                            properties: {
                                Lore: {
                                    description: "(May not exist) List of strings to display as lore for the item.",
                                    type: "list",
                                    items: {
                                        markdownDescription: "(May not exist) A line of text for the lore of an item.",
                                        type: "string",
                                    },
                                },
                                Name: {
                                    markdownDescription: "(May not exist) The JSON text component to use to display the item name.",
                                    type: "string",
                                },
                            },
                        },
                        "minecraft:item_lock": {
                            markdownDescription: '1 for "lock in slot". 2 for "lock in inventory".',
                            type: "byte",
                            default: { type: "byte", value: 0 },
                            markdownEnumDescriptions: ["none", "lock in slot", "lock in inventory"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                                { type: "byte", value: 2 },
                            ],
                        },
                        "minecraft:keep_on_death": {
                            markdownDescription: "1 if keeping on death.*needs testing*",
                            type: "byte",
                            default: { type: "byte", value: 0 },
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                        RepairCost: {
                            markdownDescription: "(May not exist) Number of experience levels to add to the base level cost when repairing, combining, or renaming this item with an [Anvil](https://minecraft.wiki/w/Anvil).",
                            type: "int",
                            default: { type: "int", value: 0 },
                        },
                        Unbreakable: {
                            markdownDescription: "1 or 0 (true/false) - (may not exist) if this item's durability is allowed to take damage.",
                            type: "byte",
                            default: { type: "byte", value: 0 },
                            markdownEnumDescriptions: ["false", "true"],
                            enum: [
                                { type: "byte", value: 0 },
                                { type: "byte", value: 1 },
                            ],
                        },
                    },
                },
            },
            $fragment: true,
            markdownDescription: "Items with durability store their damage value in NBT. Additionally, items can have custom display names and lore. There is also the **RepairCost** tag which tracks anvil usage for items, making them more costly with every use of the anvil.",
        },
        Item_EnchantmentTags: {
            id: "Item_EnchantmentTags",
            type: "compound",
            properties: {
                tag: {
                    type: "compound",
                    required: ["ench"],
                    properties: {
                        ench: {
                            description: "Contains enchantments on this item.",
                            type: "list",
                            items: {
                                description: "A single enchantment.",
                                type: "compound",
                                required: ["id", "lvl"],
                                properties: {
                                    id: {
                                        markdownDescription: "The ID of the enchantment. See [Bedrock Edition data values#Enchantment IDs](https://minecraft.wiki/w/Bedrock_Edition_data_values#Enchantment_IDs).",
                                        type: "short",
                                        markdownEnumDescriptions: [
                                            "Protection (protection)",
                                            "Fire Protection (fire_protection)",
                                            "Feather Falling (feather_falling)",
                                            "Blast Protection (blast_protection)",
                                            "Projectile Protection (projectile_protection)",
                                            "Thorns (thorns)",
                                            "Respiration (respiration)",
                                            "Depth Strider (depth_strider)",
                                            "Aqua Affinity (aqua_affinity)",
                                            "Sharpness (sharpness)",
                                            "Smite (smite)",
                                            "Bane of Arthropods (bane_of_arthropods)",
                                            "Knockback (knockback)",
                                            "Fire Aspect (fire_aspect)",
                                            "Looting (looting)",
                                            "Efficiency (efficiency)",
                                            "Silk Touch (silk_touch)",
                                            "Unbreaking (unbreaking)",
                                            "Fortune (fortune)",
                                            "Power (power)",
                                            "Punch (punch)",
                                            "Flame (flame)",
                                            "Infinity (infinity)",
                                            "Luck of the Sea (luck_of_the_sea)",
                                            "Lure (lure)",
                                            "Frost Walker (frost_walker)",
                                            "Mending (mending)",
                                            "Curse of Binding (binding)",
                                            "Curse of Vanishing (vanishing)",
                                            "Impaling (impaling)",
                                            "Riptide (riptide)",
                                            "Loyalty (loyalty)",
                                            "Channeling (channeling)",
                                            "Multishot (multishot)",
                                            "Piercing (piercing)",
                                            "Quick Charge (quick_charge)",
                                            "Soul Speed (soul_speed)",
                                            "Swift Sneak (swift_sneak)",
                                            "Wind Burst (wind_burst)",
                                            "Density (density)",
                                            "Breach (breach)",
                                            "Lunge (lunge)",
                                        ],
                                        enum: [
                                            { type: "byte", value: 0 },
                                            { type: "byte", value: 1 },
                                            { type: "byte", value: 2 },
                                            { type: "byte", value: 3 },
                                            { type: "byte", value: 4 },
                                            { type: "byte", value: 5 },
                                            { type: "byte", value: 6 },
                                            { type: "byte", value: 7 },
                                            { type: "byte", value: 8 },
                                            { type: "byte", value: 9 },
                                            { type: "byte", value: 10 },
                                            { type: "byte", value: 11 },
                                            { type: "byte", value: 12 },
                                            { type: "byte", value: 13 },
                                            { type: "byte", value: 14 },
                                            { type: "byte", value: 15 },
                                            { type: "byte", value: 16 },
                                            { type: "byte", value: 17 },
                                            { type: "byte", value: 18 },
                                            { type: "byte", value: 19 },
                                            { type: "byte", value: 20 },
                                            { type: "byte", value: 21 },
                                            { type: "byte", value: 22 },
                                            { type: "byte", value: 23 },
                                            { type: "byte", value: 24 },
                                            { type: "byte", value: 25 },
                                            { type: "byte", value: 26 },
                                            { type: "byte", value: 27 },
                                            { type: "byte", value: 28 },
                                            { type: "byte", value: 29 },
                                            { type: "byte", value: 30 },
                                            { type: "byte", value: 31 },
                                            { type: "byte", value: 32 },
                                            { type: "byte", value: 33 },
                                            { type: "byte", value: 34 },
                                            { type: "byte", value: 35 },
                                            { type: "byte", value: 36 },
                                            { type: "byte", value: 37 },
                                            { type: "byte", value: 38 },
                                            { type: "byte", value: 39 },
                                            { type: "byte", value: 40 },
                                            { type: "byte", value: 41 },
                                        ],
                                    },
                                    lvl: {
                                        markdownDescription: "The level of the enchantment, where 1 is level 1. Values are clamped between -32768 and 32767 when reading.",
                                        type: "short",
                                    },
                                },
                            },
                        },
                    },
                },
            },
            $fragment: true,
            markdownDescription: "In [Bedrock Edition](https://minecraft.wiki/w/Bedrock_Edition), there's only one way to store enchantment NBTs: both enchanted items and [Enchanted Book](https://minecraft.wiki/w/Enchanted_Book) share the ench tag.",
        },
        Item_ArmorTrim: {
            id: "Item_ArmorTrim",
            markdownDescription: "Additional fields when an [armor](https://minecraft.wiki/w/armor) is [trimmed](https://minecraft.wiki/w/Smithing_Template).",
            type: "compound",
            properties: {
                tag: {
                    type: "compound",
                    required: ["Trim"],
                    properties: {
                        Trim: {
                            markdownDescription: "Properties of the armor trim.",
                            type: "compound",
                            required: ["Material", "Pattern"],
                            properties: {
                                Material: {
                                    markdownDescription: "The material which decides the color of armor trim.",
                                    type: "string",
                                },
                                Pattern: {
                                    markdownDescription: "The pattern of armor trim.",
                                    type: "string",
                                },
                            },
                        },
                    },
                },
            },
            $ref: "Item_ItemStack",
            $fragment: true,
        },
        Item_BookAndQuills: {
            id: "Item_BookAndQuills",
            markdownDescription: "Additional fields for [book and quill](https://minecraft.wiki/w/book_and_quill)s.",
            type: "compound",
            properties: {
                tag: {
                    type: "compound",
                    properties: {
                        pages: {
                            markdownDescription: "(May not exist) The list of pages in the book.",
                            type: "list",
                            items: {
                                markdownDescription: "A single page in the book.",
                                type: "compound",
                                required: ["photoname", "text"],
                                properties: {
                                    photoname: {
                                        markdownDescription: "Filename of a [photo](https://minecraft.wiki/w/photo) in this page if included.",
                                        type: "string",
                                    },
                                    text: {
                                        markdownDescription: "The text in this page.",
                                        type: "string",
                                    },
                                },
                            },
                        },
                    },
                },
            },
            $ref: "Item_ItemStack",
            $fragment: true,
        },
        Item_BucketOfAquaticMob: {
            id: "Item_BucketOfAquaticMob",
            markdownDescription: "Additional fields for [bucket](https://minecraft.wiki/w/bucket).",
            type: "compound",
            properties: {
                tag: {
                    type: "compound",
                    required: ["AppendCustomName"],
                    properties: {
                        AppendCustomName: {
                            markdownDescription: "1 or 0 (true/false) - true if the entity color, state, and id are used to generate the bucket item's name.",
                            type: "byte",
                        },
                        BodyID: {
                            markdownDescription: "(May not exist) The translation key of entity's state. Used to generate the bucket item's name.",
                            type: "string",
                        },
                        ColorID: {
                            markdownDescription: "(May not exist) The translation key of a color. Used to generate the bucket item's name.",
                            type: "string",
                        },
                        Color2ID: {
                            markdownDescription: "(May not exist) The translation key of another color. Used to generate the bucket item's name.",
                            type: "string",
                        },
                        CustomName: {
                            markdownDescription: "(May not exist) The custom name of entity in it. Used to generate the bucket item's name.",
                            type: "string",
                        },
                        GroupName: {
                            markdownDescription: "(May not exist) UNDOCUMENTED. Used to generate the bucket item's name.",
                            type: "string",
                        },
                    },
                    allOf: [
                        {
                            $ref: "ActorPrefix",
                        },
                    ],
                },
            },
            $ref: "Item_ItemStack",
            $fragment: true,
        },
        Item_Crossbow: {
            id: "Item_Crossbow",
            markdownDescription: "Additional fields for [crossbow](https://minecraft.wiki/w/crossbow).",
            type: "compound",
            properties: {
                tag: {
                    type: "compound",
                    required: ["chargedItem"],
                    properties: {
                        chargedItem: {
                            markdownDescription: "The items this crossbow has charged.",
                            type: "compound",
                            $ref: "Item_ItemStack",
                        },
                    },
                },
            },
            $ref: "Item_ItemStack",
            $fragment: true,
        },
        Item_FilledMap: {
            id: "Item_FilledMap",
            markdownDescription: "Additional fields for [filled map](https://minecraft.wiki/w/filled_map).",
            type: "compound",
            properties: {
                tag: {
                    type: "compound",
                    required: ["map_display_players", "map_name_index", "map_uuid"],
                    properties: {
                        map_display_players: {
                            markdownDescription: "1 or 0 (true/false) - (may not exist) true if the map displays player markers.",
                            type: "byte",
                        },
                        map_is_init: {
                            markdownDescription: "(May not exist) UNDOCUMENTED.",
                            type: "byte",
                        },
                        map_is_scaling: {
                            markdownDescription: "(May not exist) UNDOCUMENTED.",
                            type: "byte",
                        },
                        map_name_index: {
                            markdownDescription: "The index of the map's name.",
                            type: "int",
                        },
                        map_scale: {
                            markdownDescription: "(May not exist) UNDOCUMENTED.",
                            type: "int",
                        },
                        map_uuid: {
                            markdownDescription: "The UUID of the map used in this item.",
                            type: "long",
                        },
                    },
                },
            },
            $ref: "Item_ItemStack",
            $fragment: true,
        },
        Item_FireworkRocket: {
            id: "Item_FireworkRocket",
            markdownDescription: "Additional fields for [firework rocket](https://minecraft.wiki/w/firework_rocket).",
            type: "compound",
            properties: {
                tag: {
                    type: "compound",
                    properties: {
                        Fireworks: {
                            type: "compound",
                            required: ["Explosions", "Flight"],
                            properties: {
                                Explosions: {
                                    markdownDescription: "List of compounds representing each explosion this firework causes.",
                                    type: "list",
                                    items: {
                                        markdownDescription: "A explosion effect.",
                                        type: "compound",
                                        $ref: "FireworkExplosion",
                                    },
                                },
                                Flight: {
                                    markdownDescription: "Indicates the flight duration of the firework (equals the amount of gunpowder used in crafting the rocket). Can be anything from -128 to 127.",
                                    type: "byte",
                                },
                            },
                        },
                    },
                },
            },
            $ref: "Item_ItemStack",
            $fragment: true,
        },
        Item_FireworkStar: {
            id: "Item_FireworkStar",
            markdownDescription: "Additional fields for [firework star](https://minecraft.wiki/w/firework_star).",
            type: "compound",
            properties: {
                tag: {
                    type: "compound",
                    required: ["customColor", "FireworksItem"],
                    properties: {
                        customColor: {
                            markdownDescription: "The color of this firework star.",
                            type: "int",
                        },
                        FireworksItem: {
                            markdownDescription: "The explosion effect contributed by this firework star.",
                            type: "compound",
                            $ref: "FireworkExplosion",
                        },
                    },
                },
            },
            $ref: "Item_ItemStack",
            $fragment: true,
        },
        Item_GlowStick: {
            id: "Item_GlowStick",
            markdownDescription: "Additional fields for [glow stick](https://minecraft.wiki/w/glow_stick).",
            type: "compound",
            properties: {
                active_time: {
                    markdownDescription: "(May not exist) UNDOCUMENTED.",
                    type: "long",
                },
            },
            $ref: "Item_ItemStack",
            $fragment: true,
        },
        Item_HorseArmor: {
            id: "Item_HorseArmor",
            markdownDescription: "Additional fields for [horse armor](https://minecraft.wiki/w/horse_armor).",
            type: "compound",
            properties: {
                tag: {
                    type: "compound",
                    properties: {
                        customColor: {
                            markdownDescription: "(May not exist) The color of the leather armor.",
                            type: "int",
                        },
                    },
                },
            },
            $ref: "Item_ItemStack",
            $fragment: true,
        },
        Item_LodestoneCompass: {
            id: "Item_LodestoneCompass",
            markdownDescription: "Additional fields for [lodestone compass](https://minecraft.wiki/w/lodestone_compass).",
            type: "compound",
            properties: {
                tag: {
                    type: "compound",
                    required: ["trackingHandle"],
                    properties: {
                        trackingHandle: {
                            markdownDescription: "The ID of lodestone to track.",
                            type: "int",
                        },
                    },
                },
            },
            $ref: "Item_ItemStack",
            $fragment: true,
        },
        Item_Potion: {
            id: "Item_Potion",
            markdownDescription: "Additional fields for [potion](https://minecraft.wiki/w/potion).",
            type: "compound",
            properties: {
                tag: {
                    type: "compound",
                    required: ["wasJustBrewed"],
                    properties: {
                        wasJustBrewed: {
                            markdownDescription: "1 or 0 (true/false) - (may not exist) true if item is brewed in brewing stand.",
                            type: "byte",
                        },
                    },
                },
            },
            $ref: "Item_ItemStack",
            $fragment: true,
        },
        Item_Shield: {
            id: "Item_Shield",
            markdownDescription: "Additional fields for [shield](https://minecraft.wiki/w/shield).",
            type: "compound",
            properties: {
                tag: {
                    type: "compound",
                    required: ["Base"],
                    properties: {
                        Base: {
                            markdownDescription: "The base color of the banner on the shield. See [Banner#Block_data](https://minecraft.wiki/w/Banner#Block_data).",
                            type: "int",
                        },
                        Patterns: {
                            markdownDescription: "(May not exist) List of all patterns applied to the banner on the shield.",
                            type: "list",
                            items: {
                                markdownDescription: "An individual pattern.",
                                type: "compound",
                                required: ["Color", "Pattern"],
                                properties: {
                                    Color: {
                                        markdownDescription: "The base color of the pattern. See [Banner#Block_data](https://minecraft.wiki/w/Banner#Block_data).",
                                        type: "int",
                                    },
                                    Pattern: {
                                        markdownDescription: "The pattern ID code. See [Banner#Block_data](https://minecraft.wiki/w/Banner#Block_data).",
                                        type: "string",
                                    },
                                },
                            },
                        },
                    },
                },
            },
            $ref: "Item_ItemStack",
            $fragment: true,
        },
        Item_WrittenBook: {
            id: "Item_WrittenBook",
            markdownDescription: "Additional fields for [written book](https://minecraft.wiki/w/written_book).",
            type: "compound",
            properties: {
                tag: {
                    type: "compound",
                    required: ["author", "generation", "pages", "title", "xuid"],
                    properties: {
                        author: {
                            markdownDescription: "The author of this book.",
                            type: "string",
                        },
                        generation: {
                            markdownDescription: "The copy tier of the book. 0 = Original, 1 = Copy of original, 2 = Copy of copy.",
                            type: "int",
                        },
                        pages: {
                            markdownDescription: "The list of pages in the book.",
                            type: "list",
                            items: {
                                markdownDescription: "A single page in the book.",
                                type: "compound",
                                required: ["photoname", "text"],
                                properties: {
                                    photoname: {
                                        markdownDescription: "Filename of a [photo](https://minecraft.wiki/w/photo) in this page if included.",
                                        type: "string",
                                    },
                                    text: {
                                        markdownDescription: "The text in this page.",
                                        type: "string",
                                    },
                                },
                            },
                        },
                        title: {
                            markdownDescription: "The title of this book.",
                            type: "string",
                        },
                        xuid: {
                            markdownDescription: "UNDOCUMENTED.",
                            type: "long",
                        },
                    },
                },
            },
            $ref: "Item_ItemStack",
            $fragment: true,
        },
        //#endregion
        //#region Component NBT Schemas
        Component_Economy_trade_table: {
            id: "Component_Economy_trade_table",
            markdownDescription: "This component is used by villagers and wandering traders.",
            type: "compound",
            required: ["Riches"],
            properties: {
                Riches: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                Offers: {
                    markdownDescription: "(May not exist) The trade info.",
                    type: "compound",
                    required: ["Recipes", "TierExpRequirements"],
                    properties: {
                        Recipes: {
                            markdownDescription: "The list of trade recipes.",
                            type: "list",
                            items: {
                                markdownDescription: "A recipe.",
                                type: "compound",
                                required: [
                                    "buyA",
                                    "sell",
                                    "tier",
                                    "uses",
                                    "maxUses",
                                    "traderExp",
                                    "rewardExp",
                                    "demand",
                                    "buyCountA",
                                    "buyCountB",
                                    "priceMultiplierA",
                                    "priceMultiplierB",
                                ],
                                properties: {
                                    buyA: {
                                        markdownDescription: "The first 'cost' item.",
                                        type: "compound",
                                        $ref: "Item_ItemStack",
                                    },
                                    buyB: {
                                        markdownDescription: "(May not exist) The second 'cost' item",
                                        type: "compound",
                                        $ref: "Item_ItemStack",
                                    },
                                    sell: {
                                        markdownDescription: "The item being sold for each set of cost items.",
                                        type: "compound",
                                        $ref: "Item_ItemStack",
                                    },
                                    tier: {
                                        markdownDescription: "The tier that the trader needs to reach to access this recipe.",
                                        type: "int",
                                    },
                                    uses: {
                                        markdownDescription: "The number of times this trade has been used. The trade becomes disabled when this is greater or equal to maxUses.",
                                        type: "int",
                                    },
                                    maxUses: {
                                        markdownDescription: "The maximum number of times this trade can be used before it is disabled. Increases by a random amount from 2 to 12 when offers are refreshed. *needs testing*",
                                        type: "int",
                                    },
                                    traderExp: {
                                        markdownDescription: "The trade experiences to be rewarded to this trader entity.",
                                        type: "int",
                                    },
                                    rewardExp: {
                                        markdownDescription: "1 or 0 (true/false) - true if this trade provides XP orb drops.",
                                        type: "byte",
                                    },
                                    demand: {
                                        markdownDescription: "The price adjuster of the first 'cost' item based on demand. Updated when a villager resupply.",
                                        type: "int",
                                    },
                                    buyCountA: {
                                        markdownDescription: "The count needed for the first 'cost' item.",
                                        type: "int",
                                    },
                                    buyCountB: {
                                        markdownDescription: "The count needed for the second 'cost' item.",
                                        type: "int",
                                    },
                                    priceMultiplierA: {
                                        markdownDescription: "The multiplier on the demand and discount price adjuster; the final adjusted price is added to the first 'cost' item's price.",
                                        type: "float",
                                    },
                                    priceMultiplierB: {
                                        markdownDescription: "The multiplier on the demand and discount price adjuster; the final adjusted price is added to the second 'cost' item's price.",
                                        type: "float",
                                    },
                                },
                            },
                        },
                        TierExpRequirements: {
                            markdownDescription: "Trade experiences required to become each trade tier.",
                            type: "list",
                            items: {
                                markdownDescription: "A tier.",
                                type: "compound",
                                required: ["<''tier_level_num''>"],
                                properties: {
                                    "<''tier_level_num''>": {
                                        markdownDescription: "Trade xperiences required to become this tier.",
                                        type: "int",
                                    },
                                },
                            },
                        },
                    },
                },
                ConvertedFromVillagerV1: {
                    markdownDescription: "(May not exist) UNDOCUMENTED.",
                    type: "byte",
                },
                TradeTablePath: {
                    markdownDescription: "(May not exist) The path of the json file of the trade table.",
                    type: "string",
                },
                LowTierCuredDiscount: {
                    markdownDescription: "(May not exist) The discount price adjuster gained by curing zombie villagers",
                    type: "int",
                },
                HighTierCuredDiscount: {
                    markdownDescription: "(May not exist) The discount price adjuster gained by curing zombie villagers",
                    type: "int",
                },
                NearbyCuredDiscount: {
                    markdownDescription: "(May not exist) The discount price adjuster gained by curing nearby zombie villagers",
                    type: "int",
                },
                NearbyCuredDiscountTimeStamp: {
                    markdownDescription: "(May not exist) The discount price adjuster gained by curing nearby zombie villagers",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Component_Ageable: {
            id: "Component_Ageable",
            markdownDescription: "This component is used by axolotls, bees, cats, chickens, cows, dolphins, donkeys, foxes, goats, hoglins, horses, llamas, mooshrooms, mules, ocelots, pandas, pigs, polar bears, rabbits, sheep, skeleton horses, sniffers, striders, tadpoles, turtles, villagers, wolves, and zombie horses.",
            type: "compound",
            required: ["Age"],
            properties: {
                Age: {
                    markdownDescription: "Represents the age of the entity in ticks; when negative, the entity is a baby. When 0, the entity becomes an adult.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Component_Balloon: {
            id: "Component_Balloon",
            markdownDescription: "This component is used by allays, bees, chickens, cows, donkeys, foxes, glow squids, horses, iron golems, llamas, mooshrooms, mules, pandas, pigs, rabbits, sheep, skeleton horses, snow golems, and zombie horses.",
            type: "compound",
            required: ["ballon_attached", "ballon_max_height", "ballon_should_drop"],
            properties: {
                ballon_attached: {
                    markdownDescription: "The Unique ID of the attached entity.",
                    type: "long",
                },
                ballon_max_height: {
                    markdownDescription: "Max height.",
                    type: "float",
                },
                ballon_should_drop: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
            },
            $fragment: false,
        },
        Component_Breathable: {
            id: "Component_Breathable",
            markdownDescription: "This component is used by axolotls, bats, bees, cats, cave spiders, chickens, cows, creepers, dolphins, donkeys, drowned, elder guardians, endermen, endermites, evokers, fish, foxes, frogs, ghasts, glow squids, goats, guardians, hoglins, horses, husks, llamas, magma cubes, mooshrooms, mules, ocelots, pandas, parrots, phantoms, piglins, piglin brutes, pillagers, pigs, players, polar bears, pufferfish, rabbits, ravagers, salmon, sheep, shulkers, silverfish, skeletons, skeleton horses, slimes, sniffers, snow golems, tropical fish, spiders, squids, sea turtles, strays, villagers, vindicators, wardens, wandering traders, withers, wither skeletons, tadpoles, witches, wolves, zombies, zoglins, zombie horses, zombified piglins, and zombie villagers.",
            type: "compound",
            required: ["Air"],
            properties: {
                Air: {
                    markdownDescription: "How much air the living entity has, in ticks.",
                    type: "short",
                },
            },
            $fragment: false,
        },
        Component_Breedable: {
            id: "Component_Breedable",
            markdownDescription: "This component is used by axolotls, bees, cats, chickens, cows, dolphins, donkeys, foxes, goats, hoglins, horses, llamas, mooshrooms, mules, ocelots, pandas, pigs, polar bears, rabbits, sheep, skeleton horses, sniffers, striders, tadpoles, turtles, villagers, wolves, and zombie horses.",
            type: "compound",
            required: ["InLove", "LoveCause", "BreedCooldown"],
            properties: {
                InLove: {
                    markdownDescription: "Number of ticks until the entity loses its breeding hearts and stops searching for a mate. 0 when not searching for a mate *needs testing*.",
                    type: "int",
                },
                LoveCause: {
                    markdownDescription: "The Unique ID of the entity that caused this animal to breed.",
                    type: "long",
                },
                BreedCooldown: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Component_Bribeable: {
            id: "Component_Bribeable",
            markdownDescription: "This component is only used by dolphins.",
            type: "compound",
            required: ["BribeTime"],
            properties: {
                BribeTime: {
                    markdownDescription: "Time in ticks before the Entity can be bribed again. *needs testing*",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Component_Inventory: {
            id: "Component_Inventory",
            markdownDescription: "This component is used by minecarts with chest, minecarts with command block, minecarts with hopper, horses, donkeys, llamas, mules, pandas, and villagers.",
            type: "compound",
            required: ["InventoryVersion", "LootTable", "LootTableSeed"],
            properties: {
                ChestItems: {
                    type: "list",
                    items: {
                        markdownDescription: "An item in the inventory, including the slot tag.",
                        type: "compound",
                        required: ["Slot"],
                        properties: {
                            Slot: {
                                markdownDescription: "The slot the item is in.",
                                type: "byte",
                            },
                        },
                        allOf: [{ $ref: "Item_ItemStack" }],
                    },
                },
                InventoryVersion: {
                    markdownDescription: "e.g. 1.17.20-beta23",
                    type: "string",
                },
                LootTable: {
                    markdownDescription: "Loot table to be used to fill the inventory when it is next opened, or the items are otherwise interacted with.",
                    type: "string",
                },
                LootTableSeed: {
                    markdownDescription: "Seed for generating the loot table. 0 or omitted uses a random seed *needs testing*.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Component_Damage_over_time: {
            id: "Component_Damage_over_time",
            markdownDescription: "This component is used by axolotls and dolphins.",
            type: "compound",
            required: ["DamageTime"],
            properties: {
                DamageTime: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "short",
                },
            },
            $fragment: false,
        },
        Component_Drying_out_timer: {
            id: "Component_Drying_out_timer",
            markdownDescription: "This component is used by axolotls and dolphins.",
            type: "compound",
            required: ["CompleteTick", "State"],
            properties: {
                CompleteTick: {
                    markdownDescription: "The time when this entity completely dries out.",
                    type: "long",
                },
                State: {
                    markdownDescription: "Must be a boolean. 1 if it already dried out.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Component_Dweller: {
            id: "Component_Dweller",
            markdownDescription: 'This component is used by cats, iron golems, villagers, evokers, pillagers, ravagers, vindicators, and witches. These mobs are classified into "roles" in the component, with cats being "passive", iron golems being "defenders", evokers, pillagers, ravagers, vindicators, and witches being "hostile", and villagers being "inhabitants".',
            type: "compound",
            required: ["DwellingUniqueID", "RewardPlayersOnFirstFounding"],
            properties: {
                DwellingUniqueID: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "string",
                },
                RewardPlayersOnFirstFounding: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
                PreferredProfession: {
                    markdownDescription: "(May not exist) UNDOCUMENTED.",
                    type: "string",
                },
            },
            $fragment: false,
        },
        Component_Explode: {
            id: "Component_Explode",
            markdownDescription: "This component is used by TNT, minecarts with TNT, creepers, ghast fireballs, end crystals, and wither skulls.",
            type: "compound",
            properties: {
                Fuse: {
                    markdownDescription: "(May not exist)  Number of ticks before the explosion",
                    type: "byte",
                },
                IsFuseLit: {
                    markdownDescription: "(May not exist)  Does the time before the explosion started decreasing",
                    type: "byte",
                },
                AllowUnderwater: {
                    markdownDescription: "(May not exist)  Explosion will cause damage to territory even underwater",
                    type: "byte",
                },
            },
            $fragment: false,
        },
        Component_Genetics: {
            id: "Component_Genetics",
            markdownDescription: "This component is used by goat and pandas.",
            type: "compound",
            properties: {
                GeneArray: {
                    type: "list",
                    items: {
                        markdownDescription: "A gene pair",
                        type: "compound",
                        required: ["HiddenAllele", "MainAllele"],
                        properties: {
                            HiddenAllele: {
                                markdownDescription: "the hidden allele.",
                                type: "int",
                            },
                            MainAllele: {
                                markdownDescription: "the main allele.",
                                type: "int",
                            },
                        },
                    },
                },
            },
            $fragment: false,
        },
        Component_Home: {
            id: "Component_Home",
            markdownDescription: "This component is used by bees, elder guardians, guardians, piglin brutes, and turtles.",
            type: "compound",
            required: ["HomePos", "HomeDimensionId"],
            properties: {
                HomePos: {
                    markdownDescription: "The position of the entity's home.",
                    type: "list",
                    items: [
                        {
                            markdownDescription: "X",
                            type: "float",
                        },
                        {
                            markdownDescription: "Y",
                            type: "float",
                        },
                        {
                            markdownDescription: "Z",
                            type: "float",
                        },
                    ],
                },
                HomeDimensionId: {
                    markdownDescription: "The dimension where the entity's home is.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Component_Insomnia: {
            id: "Component_Insomnia",
            markdownDescription: "This component is only used by players.",
            type: "compound",
            required: ["TimeSinceRest"],
            properties: {
                TimeSinceRest: {
                    markdownDescription: "The time in ticks since last rest.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Component_Trade_table: {
            id: "Component_Trade_table",
            markdownDescription: "This component is used by old villagers.",
            type: "compound",
            required: ["sizeOfTradeFirstTimeVector", "TradeTier", "Riches", "Willing"],
            properties: {
                sizeOfTradeFirstTimeVector: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                FirstTimeTrade: {
                    markdownDescription: "(May not exist) UNDOCUMENTED.",
                    type: "int",
                },
                TradeTier: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                Riches: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "int",
                },
                Willing: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
                Offers: {
                    markdownDescription: "(May not exist) UNDOCUMENTED.",
                    type: "list",
                },
            },
            $fragment: false,
        },
        Component_Tamemount: {
            id: "Component_Tamemount",
            markdownDescription: "This component is used by horses, donkeys, mules, and llamas.",
            type: "compound",
            required: ["Temper"],
            properties: {
                Temper: {
                    markdownDescription: "Random number that ranges from 0 to 100; increases with feeding or trying to tame it. Higher values make a horse easier to tame.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Component_Npc: {
            id: "Component_Npc",
            markdownDescription: "This component is only used by NPCs.",
            type: "compound",
            properties: {
                RawtextName: {
                    markdownDescription: "(May not exist) The name.",
                    type: "string",
                },
                InteractiveText: {
                    markdownDescription: "(May not exist) The interactive text.",
                    type: "string",
                },
                Actions: {
                    markdownDescription: "(May not exist) The actions.",
                    type: "string",
                },
                PlayerSceneMapping: {
                    markdownDescription: "(May not exist) UNDOCUMENTED.",
                    type: "list",
                    items: {
                        markdownDescription: "A key-value pair.",
                        type: "compound",
                        required: ["PlayerID", "SceneName"],
                        properties: {
                            PlayerID: {
                                markdownDescription: "A player's Unique ID.",
                                type: "long",
                            },
                            SceneName: {
                                markdownDescription: "UNDOCUMENTED.",
                                type: "string",
                            },
                        },
                    },
                },
            },
            $fragment: false,
        },
        Component_Projectile: {
            id: "Component_Projectile",
            markdownDescription: "The entity's root tag.",
            type: "compound",
            required: ["TargetID", "StuckToBlockPos", "CollisionPos"],
            properties: {
                TargetID: {
                    markdownDescription: "Optional. The UniqueID of the entity which the projectile was launched to.",
                    type: "long",
                },
                StuckToBlockPos: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "list",
                    items: [
                        {
                            markdownDescription: "X",
                            type: "int",
                        },
                        {
                            markdownDescription: "Y",
                            type: "int",
                        },
                        {
                            markdownDescription: "Z",
                            type: "int",
                        },
                    ],
                },
                CollisionPos: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "list",
                    items: [
                        {
                            markdownDescription: "X",
                            type: "float",
                        },
                        {
                            markdownDescription: "Y",
                            type: "float",
                        },
                        {
                            markdownDescription: "Z",
                            type: "float",
                        },
                    ],
                },
            },
            $fragment: false,
        },
        Component_Spawn_entity: {
            id: "Component_Spawn_entity",
            markdownDescription: "This component is used by chickens and wandering traders.",
            type: "compound",
            properties: {
                entries: {
                    type: "list",
                    items: {
                        markdownDescription: "An entry.",
                        type: "compound",
                        required: ["SpawnTimer", "StopSpawning"],
                        properties: {
                            SpawnTimer: {
                                markdownDescription: "UNDOCUMENTED.",
                                type: "int",
                            },
                            StopSpawning: {
                                markdownDescription: "UNDOCUMENTED.",
                                type: "byte",
                            },
                        },
                    },
                },
            },
            $fragment: false,
        },
        Component_Timer: {
            id: "Component_Timer",
            markdownDescription: "This component is used by bees, boats, guardians, hoglins, husks, piglins, piglin brutes, players, pufferfish, ravagers, skeletons, wandering traders, and zombies.",
            type: "compound",
            required: ["TimeStamp", "HasExecuted", "CountTime"],
            properties: {
                TimeStamp: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "long",
                },
                HasExecuted: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
                CountTime: {
                    markdownDescription: "Deprecated. UNDOCUMENTED.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Component_Trade_resupply: {
            id: "Component_Trade_resupply",
            markdownDescription: "This component is only used by villagers.",
            type: "compound",
            required: ["HasResupplied"],
            properties: {
                HasResupplied: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
            },
            $fragment: false,
        },
        Component_Trust: {
            id: "Component_Trust",
            markdownDescription: "This component is only used by foxes.",
            type: "compound",
            required: ["TrustedPlayersAmount", "TrustedPlayer[0-9]+"],
            properties: {
                TrustedPlayersAmount: {
                    markdownDescription: "The number of players who are trusted by this entity.",
                    type: "int",
                },
            },
            patternProperties: {
                "TrustedPlayer[0-9]+": {
                    markdownDescription: "A player's Unique ID. Note that <num> counts from 0.",
                    type: "long",
                },
            },
            $fragment: false,
        },
        Component_CommandBlockComponent: {
            id: "Component_CommandBlockComponent",
            markdownDescription: "This component may be not accessable with [Behavior Pack](https://minecraft.wiki/w/Add-on). But it is used by activated [Minecart with Command Block](https://minecraft.wiki/w/Minecart_with_Command_Block)",
            type: "compound",
            required: ["Ticking", "CurrentTickCount"],
            properties: {
                Ticking: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
                CurrentTickCount: {
                    markdownDescription: "Number of ticks until it executes the command again.",
                    type: "int",
                },
            },
            $fragment: false,
        },
        Component_FogCommandComponent: {
            id: "Component_FogCommandComponent",
            markdownDescription: "This component may be not accessable with [Behavior Pack](https://minecraft.wiki/w/Add-on). But it is used by player entity.",
            type: "compound",
            required: ["fogCommandStack"],
            properties: {
                fogCommandStack: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "list",
                    items: {
                        markdownDescription: "UNDOCUMENTED.",
                        type: "string",
                    },
                },
            },
            $fragment: false,
        },
        Component_Hide: {
            id: "Component_Hide",
            markdownDescription: "This component is only used by villagers.",
            type: "compound",
            required: ["IsInRaid", "ReactToBell"],
            properties: {
                IsInRaid: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
                ReactToBell: {
                    markdownDescription: "UNDOCUMENTED.",
                    type: "byte",
                },
            },
            $fragment: false,
        },
        //#endregion
        //#region Custom NBT Schemas
        // NOTE: Verified.
        AABBVolumes: {
            id: "AABBVolumes",
            title: "The AABBVolumes schema.",
            markdownDescription: "A custom schema for the NBT structure used by the custom parser and serializer for the AABBVolumes content type.",
            type: "compound",
            required: ["version", "StructureTypes", "ChunkBoundingBoxes", "DynamicSpawnAreas", "StaticSpawnAreas"],
            properties: {
                version: {
                    title: "Format Version",
                    markdownDescription: "The format version of the AABBVolumes data.",
                    type: "int",
                    enum: [{ type: "int", value: 1 }],
                },
                StructureTypes: {
                    title: "Structure Types",
                    markdownDescription: "The list of structure types in the associated chunk.",
                    type: "list",
                    items: {
                        title: "Structure Type",
                        markdownDescription: "A structure type.",
                        type: "compound",
                        required: ["Id", "Type"],
                        properties: {
                            Id: {
                                title: "ID",
                                markdownDescription: "The ID of the structure type. This is used to reference this structure type in DynamicSpawnAreas and StaticSpawnAreas.",
                                type: "int",
                            },
                            Type: {
                                type: "string",
                                // Enum source: https://github.com/MiemieMethod/bedrock-docs/blob/8cd37dacbd064f5fb2a4953548739a258b31dd21/.knowledge/wiki%E6%91%98%E5%BD%95/%E4%B8%AD%E6%96%87Minecraft%20Wiki/%E5%9F%BA%E5%B2%A9%E7%89%88LevelDB%E6%A0%BC%E5%BC%8F.wikitext?plain=1#L644
                                enum: [
                                    { type: "string", value: "minecraft:ancient_city" },
                                    { type: "string", value: "minecraft:bastion_remnant" },
                                    { type: "string", value: "minecraft:buried_treasure" },
                                    { type: "string", value: "minecraft:end_city" },
                                    { type: "string", value: "minecraft:mineshaft" },
                                    { type: "string", value: "minecraft:fortress" },
                                    { type: "string", value: "minecraft:monument" },
                                    { type: "string", value: "minecraft:ocean_ruin" },
                                    { type: "string", value: "minecraft:pillager_outpost" },
                                    { type: "string", value: "minecraft:jungle_pyramid" },
                                    { type: "string", value: "minecraft:swamp_hut" },
                                    { type: "string", value: "minecraft:desert_pyramid" },
                                    { type: "string", value: "minecraft:igloo" },
                                    { type: "string", value: "minecraft:ruined_portal" },
                                    { type: "string", value: "minecraft:shipwreck" },
                                    { type: "string", value: "minecraft:stronghold" },
                                    { type: "string", value: "minecraft:village" },
                                    { type: "string", value: "minecraft:mansion" },
                                    { type: "string", value: "minecraft:trail_ruins" },
                                    { type: "string", value: "minecraft:trial_chambers" },
                                ],
                                markdownEnumDescriptions: [
                                    "Ancient City",
                                    "Bastion Remnant",
                                    "Buried Treasure",
                                    "End City",
                                    "Mineshaft",
                                    "Nether Fortress",
                                    "Ocean Monument",
                                    "Ocean Ruin",
                                    "Pillager Outpost",
                                    "Jungle Pyramid",
                                    "Swamp Hut",
                                    "Desert Pyramid",
                                    "Igloo",
                                    "Ruined Portal",
                                    "Shipwreck",
                                    "Stronghold",
                                    "Village",
                                    "Woodland Mansion",
                                    "Trail Ruins",
                                    "Trial Chambers",
                                ],
                            },
                        },
                    },
                },
                ChunkBoundingBoxes: {
                    title: "Chunk Bounding Boxes",
                    markdownDescription: "The list of bounding boxes of the structures in the associated chunk.",
                    type: "list",
                    items: {
                        title: "Chunk Bounding Box",
                        markdownDescription: "A chunk bounding box.",
                        type: "compound",
                        required: ["Id", "AABBMinX", "AABBMinY", "AABBMinZ", "AABBMaxX", "AABBMaxY", "AABBMaxZ"],
                        properties: {
                            Id: {
                                title: "ID",
                                markdownDescription: "The ID of the bounding box. This is used to reference this bounding box in DynamicSpawnAreas and StaticSpawnAreas.",
                                type: "int",
                            },
                            AABBMinX: {
                                title: "Min X",
                                markdownDescription: "The minimum X coordinate of the bounds of this hardcoded spawning area.",
                                type: "int",
                            },
                            AABBMinY: {
                                title: "Min Y",
                                markdownDescription: "The minimum Y coordinate of the bounds of this hardcoded spawning area.",
                                type: "int",
                            },
                            AABBMinZ: {
                                title: "Min Z",
                                markdownDescription: "The minimum Z coordinate of the bounds of this hardcoded spawning area.",
                                type: "int",
                            },
                            AABBMaxX: {
                                title: "Max X",
                                markdownDescription: "The maximum X coordinate of the bounds of this hardcoded spawning area.",
                                type: "int",
                            },
                            AABBMaxY: {
                                title: "Max Y",
                                markdownDescription: "The maximum Y coordinate of the bounds of this hardcoded spawning area.",
                                type: "int",
                            },
                            AABBMaxZ: {
                                title: "Max Z",
                                markdownDescription: "The maximum Z coordinate of the bounds of this hardcoded spawning area.",
                                type: "int",
                            },
                        },
                    },
                },
                DynamicSpawnAreas: {
                    title: "Dynamic Spawn Areas",
                    markdownDescription: "The list of dynamic spawn areas in the associated chunk.",
                    type: "list",
                    items: {
                        title: "Dynamic Spawn Area",
                        markdownDescription: "A dynamic spawn area.",
                        type: "compound",
                        required: ["BoundingBoxId", "StructureId", "FullBoundingBox"],
                        properties: {
                            BoundingBoxId: {
                                title: "Bounding Box ID",
                                markdownDescription: "The ID of the bounding box (in ChunkBoundingBoxes) corresponding to this dynamic spawn area.",
                                type: "int",
                            },
                            StructureId: {
                                title: "Structure ID",
                                markdownDescription: "The ID of the structure type (in StructureTypes) corresponding to this dynamic spawn area.",
                                type: "int",
                            },
                            FullBoundingBox: {
                                title: "Full Bounding Box",
                                markdownDescription: "Whether the structure bounding box is the full bounding box of the structure in the chunk (as opposed to being a piece of it).",
                                type: "int",
                                markdownEnumDescriptions: ["false", "true"],
                                enum: [
                                    { type: "int", value: 0 },
                                    { type: "int", value: 1 },
                                ],
                            },
                        },
                    },
                },
                StaticSpawnAreas: {
                    title: "Static Spawn Areas",
                    markdownDescription: "The list of static spawn areas in the associated chunk.",
                    type: "list",
                    items: {
                        title: "Static Spawn Area",
                        markdownDescription: "A static spawn area.",
                        type: "compound",
                        required: ["BoundingBoxId", "StructureId", "HeightDifference", "FullBoundingBox"],
                        properties: {
                            BoundingBoxId: {
                                title: "Bounding Box ID",
                                markdownDescription: "The ID of the bounding box (in ChunkBoundingBoxes) corresponding to this dynamic spawn area.",
                                type: "int",
                            },
                            StructureId: {
                                title: "Structure ID",
                                markdownDescription: "The ID of the structure type (in StructureTypes) corresponding to this dynamic spawn area.",
                                type: "int",
                            },
                            HeightDifference: {
                                title: "Height Difference",
                                markdownDescription: `The bounding box where spawns can occur may be slightly different from the corresponding
bounding box of the structure; in particular, the static spawn area may have a different
height. This value is the spawn area's height minus the structure bounding box's height
(so, if it is negative, the static spawn area is shorter than the full structure).

The value \`-3\` is used to prevent pillagers and witches from spawning on the roof of a
pillager outpost or witch hut; for most structures, this is \`0\`.`,
                                type: "int",
                            },
                            FullBoundingBox: {
                                title: "Full Bounding Box",
                                markdownDescription: "Whether the structure bounding box is the full bounding box of the structure in the chunk (as opposed to being a piece of it).",
                                type: "int",
                                markdownEnumDescriptions: ["false", "true"],
                                enum: [
                                    { type: "int", value: 0 },
                                    { type: "int", value: 1 },
                                ],
                            },
                        },
                    },
                },
            },
        },
        // NOTE: Verified.
        BiomeState: {
            id: "BiomeState",
            title: "The BiomeState schema.",
            markdownDescription: "A custom schema for the NBT structure used by the custom parser and serializer for the BiomeState content type.",
            type: "compound",
            oneOf: [
                {
                    title: "Pre-v1.21.4 BiomeState",
                    markdownDescription: "The BiomeState data before version 1.21.4.",
                    type: "compound",
                    required: ["format", "entries"],
                    properties: {
                        format: {
                            title: "Format Version",
                            markdownDescription: "The format version of the BiomeState data.",
                            type: "byte",
                            enum: [{ type: "byte", value: 1 }],
                            markdownEnumDescriptions: ["Pre-v1.21.4"],
                        },
                        entries: {
                            title: "Structure Types",
                            markdownDescription: "The list of structure types in the associated chunk.",
                            type: "list",
                            items: {
                                title: "Structure Type",
                                markdownDescription: "A structure type.",
                                type: "compound",
                                required: ["biome_id", "state"],
                                properties: {
                                    biome_id: {
                                        title: "Biome ID",
                                        markdownDescription: "The ID of the biome.",
                                        type: "byte",
                                        oneOf: [
                                            {
                                                markdownDescription: "A vanilla biome numeric ID.",
                                                type: "byte",
                                                markdownEnumDescriptions: Object.entries(__biome_data__.int_map)
                                                    .sort((a, b) => a[1] - b[1])
                                                    .map(([biome, id]) => `${biome} (${id})`),
                                                enum: Object.values(__biome_data__.int_map)
                                                    .sort((a, b) => a - b)
                                                    .map((v) => ({ type: "byte", value: v })),
                                                errorMessage: "Unknown vanilla biome numeric ID. If you meant to enter the ID of a custom biome, it should be at least 10000.",
                                            },
                                        ],
                                    },
                                    state: {
                                        title: "State",
                                        markdownDescription: "The state. This might be the maximum snow level of the biome.",
                                        type: "byte",
                                    },
                                },
                            },
                        },
                    },
                },
                {
                    title: "v1.21.4 BiomeState",
                    markdownDescription: "The BiomeState data for version 1.21.4 and later.",
                    type: "compound",
                    required: ["format", "entries"],
                    properties: {
                        format: {
                            title: "Format Version",
                            markdownDescription: "The format version of the BiomeState data.",
                            type: "byte",
                            enum: [{ type: "byte", value: 2 }],
                            markdownEnumDescriptions: ["v1.21.4"],
                        },
                        entries: {
                            title: "Structure Types",
                            markdownDescription: "The list of structure types in the associated chunk.",
                            type: "list",
                            items: {
                                title: "Structure Type",
                                markdownDescription: "A structure type.",
                                type: "compound",
                                required: ["biome_id", "state"],
                                properties: {
                                    biome_id: {
                                        title: "Biome ID",
                                        markdownDescription: "The ID of the biome.",
                                        type: "short",
                                        oneOf: [
                                            {
                                                markdownDescription: "A vanilla biome numeric ID.",
                                                type: "short",
                                                markdownEnumDescriptions: Object.entries(__biome_data__.int_map)
                                                    .sort((a, b) => a[1] - b[1])
                                                    .map(([biome, id]) => `${biome} (${id})`),
                                                enum: Object.values(__biome_data__.int_map)
                                                    .sort((a, b) => a - b)
                                                    .map((v) => ({ type: "short", value: v })),
                                                errorMessage: "Unknown vanilla biome numeric ID. If you meant to enter the ID of a custom biome, it should be at least 10000.",
                                            },
                                            {
                                                markdownDescription: "A custom biome numeric ID.",
                                                type: "short",
                                                minimum: 10000,
                                            },
                                        ],
                                    },
                                    state: {
                                        title: "State",
                                        markdownDescription: "The state. This might be the maximum snow level of the biome.",
                                        type: "byte",
                                    },
                                },
                            },
                        },
                    },
                },
            ],
        },
        // NOTE: Verified.
        BorderBlocks: {
            // Documentation source: https://github.com/MiemieMethod/bedrock-docs/blob/8cd37dacbd064f5fb2a4953548739a258b31dd21/.knowledge/wiki%E6%91%98%E5%BD%95/%E4%B8%AD%E6%96%87Minecraft%20Wiki/%E5%9F%BA%E5%B2%A9%E7%89%88LevelDB%E6%A0%BC%E5%BC%8F.wikitext?plain=1#L397
            id: "BorderBlocks",
            title: "The BorderBlocks schema.",
            markdownDescription: "A custom schema for the NBT structure used by the custom parser and serializer for the BorderBlocks content type.",
            type: "compound",
            required: ["BorderBlocks"],
            properties: {
                BorderBlocks: {
                    title: "Border Blocks",
                    markdownDescription: "The list of boundaries of border blocks in the associated chunk.",
                    type: "list",
                    items: {
                        title: "Border Block",
                        markdownDescription: "The relative (X, Z) coordinates of the boundary of a border block in the associated chunk.",
                        type: "compound",
                        required: ["x", "z"],
                        properties: {
                            x: {
                                title: "X",
                                markdownDescription: "The relative X coordinate of the boundary of this border block in the associated chunk.",
                                type: "byte",
                                minimum: 0,
                                maximum: 15,
                                enum: [
                                    { type: "byte", value: 0x0 },
                                    { type: "byte", value: 0x1 },
                                    { type: "byte", value: 0x2 },
                                    { type: "byte", value: 0x3 },
                                    { type: "byte", value: 0x4 },
                                    { type: "byte", value: 0x5 },
                                    { type: "byte", value: 0x6 },
                                    { type: "byte", value: 0x7 },
                                    { type: "byte", value: 0x8 },
                                    { type: "byte", value: 0x9 },
                                    { type: "byte", value: 0xa },
                                    { type: "byte", value: 0xb },
                                    { type: "byte", value: 0xc },
                                    { type: "byte", value: 0xd },
                                    { type: "byte", value: 0xe },
                                    { type: "byte", value: 0xf },
                                ],
                            },
                            z: {
                                title: "Z",
                                markdownDescription: "The relative Z coordinate of the boundary of this border block in the associated chunk.",
                                type: "byte",
                                minimum: 0,
                                maximum: 15,
                                enum: [
                                    { type: "byte", value: 0x0 },
                                    { type: "byte", value: 0x1 },
                                    { type: "byte", value: 0x2 },
                                    { type: "byte", value: 0x3 },
                                    { type: "byte", value: 0x4 },
                                    { type: "byte", value: 0x5 },
                                    { type: "byte", value: 0x6 },
                                    { type: "byte", value: 0x7 },
                                    { type: "byte", value: 0x8 },
                                    { type: "byte", value: 0x9 },
                                    { type: "byte", value: 0xa },
                                    { type: "byte", value: 0xb },
                                    { type: "byte", value: 0xc },
                                    { type: "byte", value: 0xd },
                                    { type: "byte", value: 0xe },
                                    { type: "byte", value: 0xf },
                                ],
                            },
                        },
                    },
                },
            },
        },
        // NOTE: Verified.
        Data2DLegacy: {
            id: "Data2DLegacy",
            title: "The Data2DLegacy schema.",
            markdownDescription: "The NBT structure of the parsed data of the Data2DLegacy content type.\n\nNote: This NBT structure is specific to the parser and serializer implemented by this module.\nThis is because the actual data is stored in binary format.",
            type: "compound",
            required: ["heightMap", "biomeData"],
            properties: {
                heightMap: {
                    markdownDescription: "The height map data.\n\nIn it is stored as a 2D matrix with [x][z] height values.",
                    type: "list",
                    minItems: 16,
                    maxItems: 16,
                    items: {
                        markdownDescription: "A height map row. Its index corresponds to the offset on the x axis.",
                        type: "list",
                        minItems: 16,
                        maxItems: 16,
                        items: {
                            markdownDescription: "A height value. Its index corresponds to the offset on the z axis.",
                            type: `${NBT.TagType.Short}`,
                        },
                    },
                },
                biomeData: {
                    markdownDescription: "The biome data.\n\nIn it is stored as a 2D matrix with [x][z] tuples of a biome numeric ID followed by red, green and blue values.",
                    type: "list",
                    minItems: 16,
                    maxItems: 16,
                    items: {
                        markdownDescription: "A biome data row. Its index corresponds to the offset on the x axis.",
                        type: "list",
                        minItems: 16,
                        maxItems: 16,
                        items: {
                            markdownDescription: "A tuple of the biome data for this xz column. Its index corresponds to the offset on the z axis.",
                            type: "list",
                            items: [
                                {
                                    title: "Biome ID",
                                    markdownDescription: "A biome numeric ID value.",
                                    type: `${NBT.TagType.Byte}`,
                                },
                                {
                                    title: "Red",
                                    markdownDescription: "The red channel of the biome color.",
                                    type: `${NBT.TagType.Byte}`,
                                },
                                {
                                    title: "Green",
                                    markdownDescription: "The green channel of the biome color.",
                                    type: `${NBT.TagType.Byte}`,
                                },
                                {
                                    title: "Blue",
                                    markdownDescription: "The blue channel of the biome color.",
                                    type: `${NBT.TagType.Byte}`,
                                },
                            ],
                        },
                    },
                },
            },
        },
        // NOTE: Verified.
        Data2D: {
            id: "Data2D",
            title: "The Data2D schema.",
            markdownDescription: "The NBT structure of the parsed data of the Data2D content type.\n\nNote: This NBT structure is specific to the parser and serializer implemented by this module.\nThis is because the actual data is stored in binary format.",
            type: "compound",
            oneOf: [
                {
                    type: "compound",
                    required: ["version", "heightMap", "biomeData"],
                    properties: {
                        version: {
                            // TODO: Figure out what version the format version changed in. 1.18.0 uses format version 1.
                            title: "Format Version",
                            markdownDescription: "The format version of the Data2D data. For older Minecraft versions, this is format version 1. For modern Minecraft versions this is format version 2 but it is only used for worlds using the Old world type or an older base game version.",
                            type: "byte",
                            enumDescriptions: ["Pre-?"],
                            enum: [{ type: "byte", value: 1 }],
                        },
                        heightMap: {
                            markdownDescription: "The height map data.\n\nIn it is stored as a 2D matrix with [x][z] height values.",
                            type: "list",
                            minItems: 16,
                            maxItems: 16,
                            items: {
                                markdownDescription: "A height map row. Its index corresponds to the offset on the x axis.",
                                type: "list",
                                minItems: 16,
                                maxItems: 16,
                                items: {
                                    markdownDescription: "A height value. Its index corresponds to the offset on the z axis.",
                                    type: `${NBT.TagType.Short}`,
                                },
                            },
                        },
                        biomeData: {
                            markdownDescription: "The biome data.\n\nIn it is stored as a 2D matrix with [x][z] biome numeric ID values.",
                            type: "list",
                            minItems: 16,
                            maxItems: 16,
                            items: {
                                markdownDescription: "A biome data row. Its index corresponds to the offset on the x axis.",
                                type: "list",
                                minItems: 16,
                                maxItems: 16,
                                items: {
                                    markdownDescription: "A biome numeric ID value. Its index corresponds to the offset on the z axis.",
                                    type: `${NBT.TagType.Byte}`,
                                },
                            },
                        },
                    },
                },
                {
                    type: "compound",
                    required: ["version", "heightMap", "biomeData"],
                    properties: {
                        version: {
                            // TODO: Figure out what version the format version changed in. 1.18.0 uses format version 1.
                            title: "Format Version",
                            markdownDescription: "The format version of the Data2D data. For older Minecraft versions, this is format version 1. For modern Minecraft versions this is format version 2 but it is only used for worlds using the Old world type or an older base game version.",
                            type: "byte",
                            enumDescriptions: ["Post-?"],
                            enum: [{ type: "byte", value: 2 }],
                        },
                        heightMap: {
                            markdownDescription: "The height map data.\n\nIn it is stored as a 2D matrix with [x][z] height values.",
                            type: "list",
                            minItems: 16,
                            maxItems: 16,
                            items: {
                                markdownDescription: "A height map row. Its index corresponds to the offset on the x axis.",
                                type: "list",
                                minItems: 16,
                                maxItems: 16,
                                items: {
                                    markdownDescription: "A height value. Its index corresponds to the offset on the z axis.",
                                    type: `${NBT.TagType.Short}`,
                                },
                            },
                        },
                        biomeData: {
                            markdownDescription: "The biome data.\n\nIn it is stored as a 2D matrix with [x][z] biome numeric ID values.",
                            type: "list",
                            minItems: 16,
                            maxItems: 16,
                            items: {
                                markdownDescription: "A biome data row. Its index corresponds to the offset on the x axis.",
                                type: "list",
                                minItems: 16,
                                maxItems: 16,
                                items: {
                                    markdownDescription: "A biome numeric ID value. Its index corresponds to the offset on the z axis.",
                                    type: `${NBT.TagType.Short}`,
                                },
                            },
                        },
                    },
                },
            ],
        },
        // NOTE: Verified.
        Data3D: {
            id: "Data3D",
            title: "The Data3D schema.",
            markdownDescription: "The NBT structure of the parsed data of the Data3D content type.\n\nNote: This NBT structure is specific to the parser and serializer implemented by this module.\nThis is because the actual data is stored in binary format.",
            type: "compound",
            required: ["heightMap", "biomes"],
            properties: {
                heightMap: {
                    markdownDescription: "The height map data.\n\nIn it is stored as a 2D matrix with [x][z] height values.",
                    type: "list",
                    minItems: 16,
                    maxItems: 16,
                    items: {
                        markdownDescription: "A height map row. Its index corresponds to the offset on the x axis.",
                        type: "list",
                        minItems: 16,
                        maxItems: 16,
                        items: {
                            markdownDescription: "A height value. Its index corresponds to the offset on the z axis.",
                            type: `${NBT.TagType.Short}`,
                        },
                    },
                },
                biomes: {
                    markdownDescription: "The biome data.",
                    type: "list",
                    items: {
                        type: "compound",
                        required: ["values", "palette"],
                        properties: {
                            values: {
                                markdownDescription: "The biome values.\n\nThis is an array of indices in the biome palette, one for each block.",
                                type: "list",
                                minItems: 4096,
                                maxItems: 4096,
                                items: {
                                    type: "int",
                                },
                            },
                            palette: {
                                markdownDescription: "The biome palette.\n\nThis is an array of the biome numeric IDs.\n\nThe IDs should either be valid vanilla biome IDs or be at least 10000 if it is a custom biome ID.",
                                type: "list",
                                minItems: 4096,
                                maxItems: 4096,
                                items: {
                                    markdownDescription: "A biome numeric ID.",
                                    type: "int",
                                    oneOf: [
                                        {
                                            markdownDescription: "A vanilla biome numeric ID.",
                                            type: "int",
                                            markdownEnumDescriptions: Object.entries(__biome_data__.int_map)
                                                .sort((a, b) => a[1] - b[1])
                                                .map(([biome, id]) => `${biome} (${id})`),
                                            enum: Object.values(__biome_data__.int_map)
                                                .sort((a, b) => a - b)
                                                // HACK: This is a temporary workaround the to bug mentioned inside of the nbtSchemaToJsonSchema function, it should be making NBT.Int objects but due to the bug the raw numeric value is being entered instead.
                                                .map((v) => v),
                                            errorMessage: "Unknown vanilla biome numeric ID. If you meant to enter the ID of a custom biome, it should be at least 10000.",
                                        },
                                        {
                                            markdownDescription: "A custom biome numeric ID.",
                                            type: "int",
                                            minimum: 10000,
                                        },
                                    ],
                                },
                            },
                        },
                    },
                },
            },
        },
        // NOTE: Verified.
        Digest: {
            id: "Digest",
            title: "The Digest schema.",
            markdownDescription: "The NBT structure of the parsed data of the Digest content type.\n\nNote: This NBT structure is specific to the parser and serializer implemented by this module.\nThis is because the actual data is stored in binary format.",
            type: "compound",
            required: ["entityIds"],
            properties: {
                entityIds: {
                    title: "Entity IDs",
                    markdownDescription: "The UUIDs of all of the entities in the associated chunk.",
                    type: "list",
                    items: {
                        title: "Entity ID",
                        markdownDescription: "A UUID.",
                        type: "long",
                    },
                },
            },
        },
        // NOTE: Verified.
        HardcodedSpawners: {
            id: "HardcodedSpawners",
            title: "The HardcodedSpawners schema.",
            markdownDescription: "A custom schema for the NBT structure used by the custom parser and serializer for the HardcodedSpawners content type.",
            type: "compound",
            required: ["HardcodedSpawningAreas"],
            properties: {
                HardcodedSpawningAreas: {
                    title: "Hardcoded Spawning Areas",
                    markdownDescription: "The list of hardcoded spawning areas in the associated chunk.",
                    type: "list",
                    items: {
                        title: "Hardcoded Spawning Area",
                        markdownDescription: "A hardcoded spawning area.",
                        type: "compound",
                        required: ["AABBMinX", "AABBMinY", "AABBMinZ", "AABBMaxX", "AABBMaxY", "AABBMaxZ", "Type"],
                        properties: {
                            AABBMinX: {
                                title: "Min X",
                                markdownDescription: "The minimum X coordinate of the bounds of this hardcoded spawning area.",
                                type: "int",
                            },
                            AABBMinY: {
                                title: "Min Y",
                                markdownDescription: "The minimum Y coordinate of the bounds of this hardcoded spawning area.",
                                type: "int",
                            },
                            AABBMinZ: {
                                title: "Min Z",
                                markdownDescription: "The minimum Z coordinate of the bounds of this hardcoded spawning area.",
                                type: "int",
                            },
                            AABBMaxX: {
                                title: "Max X",
                                markdownDescription: "The maximum X coordinate of the bounds of this hardcoded spawning area.",
                                type: "int",
                            },
                            AABBMaxY: {
                                title: "Max Y",
                                markdownDescription: "The maximum Y coordinate of the bounds of this hardcoded spawning area.",
                                type: "int",
                            },
                            AABBMaxZ: {
                                title: "Max Z",
                                markdownDescription: "The maximum Z coordinate of the bounds of this hardcoded spawning area.",
                                type: "int",
                            },
                            Type: {
                                title: "Type",
                                markdownDescription: "The type of this hardcoded spawning area.",
                                type: "byte",
                                // Enum source: https://github.com/MiemieMethod/bedrock-docs/blob/8cd37dacbd064f5fb2a4953548739a258b31dd21/.knowledge/wiki%E6%91%98%E5%BD%95/%E4%B8%AD%E6%96%87Minecraft%20Wiki/%E5%9F%BA%E5%B2%A9%E7%89%88LevelDB%E6%A0%BC%E5%BC%8F.wikitext#L420
                                enum: [
                                    { type: "byte", value: 0 },
                                    { type: "byte", value: 1 },
                                    { type: "byte", value: 2 },
                                    { type: "byte", value: 3 },
                                    { type: "byte", value: 4 },
                                    { type: "byte", value: 5 },
                                    { type: "byte", value: 6 },
                                ],
                                markdownEnumDescriptions: [
                                    "None",
                                    "Nether Fortress",
                                    "Witch Hut",
                                    "Ocean Monument",
                                    "Deprecated Village",
                                    "Pillager Outpost",
                                    "Deprecated New Village",
                                ],
                            },
                        },
                    },
                },
            },
        },
        // NOTE: Verified.
        LegacyTerrain: {
            id: "LegacyTerrain",
            title: "The LegacyTerrain schema.",
            markdownDescription: "A custom schema for the NBT structure used by the custom parser and serializer for the LegacyTerrain content type.",
            type: "compound",
            required: ["block_ids", "block_data", "sky_light", "block_light", "dirty_columns", "grass_color"],
            properties: {
                block_ids: {
                    title: "Block IDs",
                    markdownDescription: "32768 block IDs representing a 16x16x128 chunk.",
                    type: "list",
                    minItems: 32768,
                    maxItems: 32768,
                    items: {
                        title: "Block ID",
                        markdownDescription: "The block ID at a given (i, j, y) coordinate.",
                        type: "byte",
                    },
                },
                block_data: {
                    title: "Block Data",
                    markdownDescription: "Metadata nibble for each block (0-15).",
                    type: "list",
                    minItems: 32768,
                    maxItems: 32768,
                    items: {
                        title: "Block Data",
                        markdownDescription: "The metadata value for a block.",
                        type: "byte",
                        minimum: 0,
                        maximum: 15,
                        enum: [
                            { type: "byte", value: 0x0 },
                            { type: "byte", value: 0x1 },
                            { type: "byte", value: 0x2 },
                            { type: "byte", value: 0x3 },
                            { type: "byte", value: 0x4 },
                            { type: "byte", value: 0x5 },
                            { type: "byte", value: 0x6 },
                            { type: "byte", value: 0x7 },
                            { type: "byte", value: 0x8 },
                            { type: "byte", value: 0x9 },
                            { type: "byte", value: 0xa },
                            { type: "byte", value: 0xb },
                            { type: "byte", value: 0xc },
                            { type: "byte", value: 0xd },
                            { type: "byte", value: 0xe },
                            { type: "byte", value: 0xf },
                        ],
                    },
                },
                sky_light: {
                    title: "Sky Light",
                    markdownDescription: "Sky light nibble for each block (0-15).",
                    type: "list",
                    minItems: 32768,
                    maxItems: 32768,
                    items: {
                        title: "Sky Light",
                        markdownDescription: "The sky light value for a block.",
                        type: "byte",
                        minimum: 0,
                        maximum: 15,
                        enum: [
                            { type: "byte", value: 0x0 },
                            { type: "byte", value: 0x1 },
                            { type: "byte", value: 0x2 },
                            { type: "byte", value: 0x3 },
                            { type: "byte", value: 0x4 },
                            { type: "byte", value: 0x5 },
                            { type: "byte", value: 0x6 },
                            { type: "byte", value: 0x7 },
                            { type: "byte", value: 0x8 },
                            { type: "byte", value: 0x9 },
                            { type: "byte", value: 0xa },
                            { type: "byte", value: 0xb },
                            { type: "byte", value: 0xc },
                            { type: "byte", value: 0xd },
                            { type: "byte", value: 0xe },
                            { type: "byte", value: 0xf },
                        ],
                    },
                },
                block_light: {
                    title: "Block Light",
                    markdownDescription: "Block light nibble for each block (0-15).",
                    type: "list",
                    minItems: 32768,
                    maxItems: 32768,
                    items: {
                        title: "Block Light",
                        markdownDescription: "The block light value for a block.",
                        type: "byte",
                        minimum: 0,
                        maximum: 15,
                        enum: [
                            { type: "byte", value: 0x0 },
                            { type: "byte", value: 0x1 },
                            { type: "byte", value: 0x2 },
                            { type: "byte", value: 0x3 },
                            { type: "byte", value: 0x4 },
                            { type: "byte", value: 0x5 },
                            { type: "byte", value: 0x6 },
                            { type: "byte", value: 0x7 },
                            { type: "byte", value: 0x8 },
                            { type: "byte", value: 0x9 },
                            { type: "byte", value: 0xa },
                            { type: "byte", value: 0xb },
                            { type: "byte", value: 0xc },
                            { type: "byte", value: 0xd },
                            { type: "byte", value: 0xe },
                            { type: "byte", value: 0xf },
                        ],
                    },
                },
                height_map: {
                    title: "Height Map",
                    markdownDescription: "256 bytes representing a 16x16 grid of height map data.",
                    type: "list",
                    minItems: 256,
                    maxItems: 256,
                    items: {
                        title: "Height",
                        markdownDescription: "A byte representing the height value.",
                        type: "byte",
                    },
                },
                grass_color: {
                    title: "Grass Color",
                    markdownDescription: "1024 bytes representing a 16x16x4 array of grass color data.",
                    type: "list",
                    minItems: 1024,
                    maxItems: 1024,
                    items: {
                        title: "Grass Color Component",
                        // REVIEW: Maybe this should be changed to be a list of tuples or compounds.
                        markdownDescription: "A byte representing one of four components for a column. The components are: BiomeID,R,G,B",
                        type: "byte",
                    },
                },
            },
        },
        // NOTE: Verified.
        LevelChunkMetaDataDictionary: {
            // TODO: Use the below source to get documentation/descriptions of each field.
            // https://github.com/MiemieMethod/bedrock-docs/blob/8cd37dacbd064f5fb2a4953548739a258b31dd21/.knowledge/wiki%E6%91%98%E5%BD%95/%E4%B8%AD%E6%96%87Minecraft%20Wiki/%E5%9F%BA%E5%B2%A9%E7%89%88LevelDB%E6%A0%BC%E5%BC%8F.wikitext#L501
            id: "LevelChunkMetaDataDictionary",
            title: "The LevelChunkMetaDataDictionary schema.",
            markdownDescription: "Stores the NBT metadata of all chunks. Maps the xxHash64 hash of NBT data to that NBT data, so that each chunk need only store 8 bytes instead of the entire NBT; most chunks have the same metadata.\n\nNote: This NBT structure is specific to the parser and serializer implemented by this module.\nThis is because the actual data is stored in binary format.",
            type: "compound",
            additionalProperties: {
                title: "Chunk Metadata Entry",
                markdownDescription: "The NBT metadata of a chunk.",
                type: "compound",
                required: [
                    "BiomeBaseGameVersion",
                    "DimensionName",
                    "GenerationSeed",
                    "GeneratorType",
                    "OriginalBaseGameVersion",
                    "OriginalDimensionHeightRange",
                    "SkullFlatteningPerformed",
                ],
                properties: {
                    BiomeBaseGameVersion: {
                        title: "Biome Base Game Version",
                        markdownDescription: 'UNDOCUMENTED. Currently observed value is "1.18.0".',
                        type: "string",
                        examples: [{ type: "string", value: "1.18.0" }],
                    },
                    DimensionName: {
                        title: "Dimension Name",
                        markdownDescription: "The name of the dimension the chunk is in.",
                        type: "string",
                        markdownEnumDescriptions: ["The Overworld dimension", "The Nether dimension", "The End dimension"],
                        enum: [
                            { type: "string", value: "Overworld" },
                            { type: "string", value: "Nether" },
                            { type: "string", value: "TheEnd" },
                        ],
                    },
                    GenerationSeed: {
                        title: "Generation Seed",
                        markdownDescription: "The seed used to generate the chunk. This is whatever the seed of the world was when the chunk was generated.",
                        type: "long",
                    },
                    GeneratorType: {
                        title: "Generator Type",
                        markdownDescription: "UNDOCUMENTED.",
                        type: "int",
                    },
                    LastSavedBaseGameVersion: {
                        title: "Last Saved Base Game Version",
                        markdownDescription: "The base game version of the world when the chunk was last saved. If no base game version was set at the time, then this is the Minecraft version that was running the world at the time.",
                        type: "string",
                    },
                    LastSavedDimensionHeightRange: {
                        title: "Last Saved Dimension Height Range",
                        markdownDescription: "The height range of the chunk's dimension when the chunk was last saved.",
                        type: "compound",
                        required: ["max", "min"],
                        properties: {
                            max: {
                                title: "Max",
                                markdownDescription: "The maximum height limit of the chunk's dimension when the chunk was last saved.",
                                type: "short",
                            },
                            min: {
                                title: "Min",
                                markdownDescription: "The minimum height limit of the chunk's dimension when the chunk was last saved.",
                                type: "short",
                            },
                        },
                    },
                    NeighborAwareBlockUpgradeVersion: {
                        title: "Neighbor Aware Block Upgrade Version",
                        markdownDescription: "UNDOCUMENTED. Currently observed value is 1.",
                        type: "int",
                        examples: [{ type: "int", value: 1 }],
                    },
                    OriginalBaseGameVersion: {
                        title: "Original Base Game Version",
                        markdownDescription: "The base game version of the world when the chunk was originally generated. If no base game version was set at the time, then this is the Minecraft version that was running the world at the time.",
                        type: "string",
                    },
                    OriginalDimensionHeightRange: {
                        title: "Original Dimension Height Range",
                        markdownDescription: "The height range of the chunk's dimension when the chunk was originally generated.",
                        type: "compound",
                        required: ["max", "min"],
                        properties: {
                            max: {
                                title: "Max",
                                markdownDescription: "The maximum height limit of the chunk's dimension when the chunk was originally generated.",
                                type: "short",
                            },
                            min: {
                                title: "Min",
                                markdownDescription: "The minimum height limit of the chunk's dimension when the chunk was originally generated.",
                                type: "short",
                            },
                        },
                    },
                    Overworld1_18HeightExtended: {
                        title: "Overworld 1.18 Height Extended",
                        markdownDescription: "UNDOCUMENTED. Currently observed value is 1.",
                        type: "short",
                        examples: [{ type: "short", value: 1 }],
                    },
                    SkullFlatteningPerformed: {
                        title: "Skull Flattening Performed",
                        markdownDescription: "UNDOCUMENTED. Currently observed value is 1.",
                        type: "short",
                        examples: [{ type: "short", value: 1 }],
                    },
                    UnderwaterLavaLakeFixed: {
                        title: "Underwater Lava Lake Fixed",
                        markdownDescription: "UNDOCUMENTED. Currently observed value is 1.",
                        type: "short",
                        examples: [{ type: "short", value: 1 }],
                    },
                    WorldGenBelowZeroFixed: {
                        title: "World Gen Below Zero Fixed",
                        markdownDescription: "UNDOCUMENTED. Currently observed value is 1.",
                        type: "short",
                        examples: [{ type: "short", value: 1 }],
                    },
                },
                additionalProperties: true,
            },
        },
        // NOTE: Verified.
        SubChunkPrefix: {
            id: "SubChunkPrefix",
            title: "The SubChunkPrefix schema.",
            markdownDescription: "A custom schema for the NBT structure used by the custom parser and serializer for the SubChunkPrefix content type.",
            type: "compound",
            oneOf: [
                {
                    $ref: "SubChunkPrefix_v0",
                },
                {
                    $ref: "SubChunkPrefix_v1",
                },
                {
                    $ref: "SubChunkPrefix_v8",
                },
            ],
            $fragment: false,
        },
        // NOTE: Verified.
        SubChunkPrefix_v0: {
            id: "SubChunkPrefix_v0",
            title: "The SubChunkPrefix schema for versions 0, 2, 3, 4, 5, 6, and 7.",
            markdownDescription: "A custom schema for the NBT structure used by the custom parser and serializer for the SubChunkPrefix content type.",
            type: "compound",
            required: ["version", "block_ids", "block_data"],
            properties: {
                version: {
                    type: "byte",
                    enum: [
                        {
                            type: "byte",
                            value: 0x00,
                        },
                        {
                            type: "byte",
                            value: 0x02,
                        },
                        {
                            type: "byte",
                            value: 0x03,
                        },
                        {
                            type: "byte",
                            value: 0x04,
                        },
                        {
                            type: "byte",
                            value: 0x05,
                        },
                        {
                            type: "byte",
                            value: 0x06,
                        },
                        {
                            type: "byte",
                            value: 0x07,
                        },
                    ],
                    markdownEnumDescriptions: [
                        "v0.17.0.1 Format",
                        "Badly Converted v0.17.0.1 Format 1",
                        "Badly Converted v0.17.0.1 Format 2",
                        "Badly Converted v0.17.0.1 Format 3",
                        "Badly Converted v0.17.0.1 Format 4",
                        "Badly Converted v0.17.0.1 Format 5",
                        "Badly Converted v0.17.0.1 Format 6",
                    ],
                },
                block_ids: {
                    title: "Block IDs",
                    markdownDescription: "The block IDs representing each block in the subchunk.",
                    type: "list",
                    minItems: 4096,
                    maxItems: 4096,
                    items: {
                        title: "Block ID",
                        markdownDescription: "The block ID of a block in the subchunk.",
                        type: "byte",
                    },
                },
                block_data: {
                    title: "Block Data",
                    markdownDescription: "The data values for each block in the subchunk.",
                    type: "list",
                    minItems: 4096,
                    maxItems: 4096,
                    items: {
                        title: "Block Data",
                        markdownDescription: "The data value for a block in the subchunk.",
                        type: "byte",
                        minimum: 0,
                        maximum: 15,
                        enum: [
                            { type: "byte", value: 0x0 },
                            { type: "byte", value: 0x1 },
                            { type: "byte", value: 0x2 },
                            { type: "byte", value: 0x3 },
                            { type: "byte", value: 0x4 },
                            { type: "byte", value: 0x5 },
                            { type: "byte", value: 0x6 },
                            { type: "byte", value: 0x7 },
                            { type: "byte", value: 0x8 },
                            { type: "byte", value: 0x9 },
                            { type: "byte", value: 0xa },
                            { type: "byte", value: 0xb },
                            { type: "byte", value: 0xc },
                            { type: "byte", value: 0xd },
                            { type: "byte", value: 0xe },
                            { type: "byte", value: 0xf },
                        ],
                    },
                },
                sky_light: {
                    title: "Sky Light",
                    markdownDescription: "The sky light values for each block in the subchunk. Only written in older versions, and is ignored in newer versions.",
                    type: "list",
                    minItems: 4096,
                    maxItems: 4096,
                    items: {
                        title: "Sky Light",
                        markdownDescription: "The sky light value for a block in the subchunk.",
                        type: "byte",
                        minimum: 0,
                        maximum: 15,
                        enum: [
                            { type: "byte", value: 0x0 },
                            { type: "byte", value: 0x1 },
                            { type: "byte", value: 0x2 },
                            { type: "byte", value: 0x3 },
                            { type: "byte", value: 0x4 },
                            { type: "byte", value: 0x5 },
                            { type: "byte", value: 0x6 },
                            { type: "byte", value: 0x7 },
                            { type: "byte", value: 0x8 },
                            { type: "byte", value: 0x9 },
                            { type: "byte", value: 0xa },
                            { type: "byte", value: 0xb },
                            { type: "byte", value: 0xc },
                            { type: "byte", value: 0xd },
                            { type: "byte", value: 0xe },
                            { type: "byte", value: 0xf },
                        ],
                    },
                },
                block_light: {
                    title: "Block Light",
                    markdownDescription: "The block light values for each block in the subchunk. Only written in older versions, and is ignored in newer versions.",
                    type: "list",
                    minItems: 4096,
                    maxItems: 4096,
                    items: {
                        title: "Block Light",
                        markdownDescription: "The block light value for a block in the subchunk.",
                        type: "byte",
                        minimum: 0,
                        maximum: 15,
                        enum: [
                            { type: "byte", value: 0x0 },
                            { type: "byte", value: 0x1 },
                            { type: "byte", value: 0x2 },
                            { type: "byte", value: 0x3 },
                            { type: "byte", value: 0x4 },
                            { type: "byte", value: 0x5 },
                            { type: "byte", value: 0x6 },
                            { type: "byte", value: 0x7 },
                            { type: "byte", value: 0x8 },
                            { type: "byte", value: 0x9 },
                            { type: "byte", value: 0xa },
                            { type: "byte", value: 0xb },
                            { type: "byte", value: 0xc },
                            { type: "byte", value: 0xd },
                            { type: "byte", value: 0xe },
                            { type: "byte", value: 0xf },
                        ],
                    },
                },
            },
        },
        // NOTE: Verified.
        SubChunkPrefix_v1: {
            id: "SubChunkPrefix_v1",
            title: "The SubChunkPrefix schema for version 1.",
            markdownDescription: "A custom schema for the NBT structure used by the custom parser and serializer for the SubChunkPrefix content type.",
            type: "compound",
            required: ["version", "layerCount", "layers"],
            properties: {
                version: {
                    type: "byte",
                    enum: [
                        {
                            type: "byte",
                            value: 0x01,
                        },
                    ],
                    markdownEnumDescriptions: ["v1.2.13 Format"],
                },
                layerCount: {
                    type: "byte",
                    enum: [
                        {
                            type: "byte",
                            value: 1,
                        },
                    ],
                },
                layers: {
                    type: "list",
                    items: [
                        {
                            $ref: "SubChunkPrefixLayer",
                        },
                    ],
                },
            },
        },
        // NOTE: Verified.
        SubChunkPrefix_v8: {
            id: "SubChunkPrefix_v8",
            title: "The SubChunkPrefix schema for versions 8 and 9.",
            markdownDescription: "A custom schema for the NBT structure used by the custom parser and serializer for the SubChunkPrefix content type.",
            type: "compound",
            required: ["version", "layerCount", "layers"],
            properties: {
                version: {
                    type: "byte",
                    enum: [
                        {
                            type: "byte",
                            value: 0x08,
                        },
                        {
                            type: "byte",
                            value: 0x09,
                        },
                    ],
                    markdownEnumDescriptions: ["v1.2.14.2 Format", "v1.18.0.20 Format & v1.16.230.50 (+Caves & Cliffs Experimental Toggle) Format"],
                },
                layerCount: {
                    type: "byte",
                },
                layers: {
                    type: "list",
                    items: {
                        $ref: "SubChunkPrefixLayer",
                    },
                },
                subChunkIndex: {
                    type: "byte",
                },
            },
        },
        // NOTE: Verified.
        SubChunkPrefixLayer: {
            id: "SubChunkPrefixLayer",
            title: "The SubChunkPrefixLayer schema.",
            markdownDescription: "A custom schema for the NBT structure used by the custom parser and serializer for the SubChunkPrefix content type.",
            type: "compound",
            required: ["palette", "block_indices"],
            properties: {
                palette: {
                    type: "compound",
                    additionalProperties: { $ref: "Block" },
                },
                block_indices: {
                    type: "list",
                    minItems: 4096,
                    maxItems: 4096,
                    items: {
                        type: "int",
                    },
                },
            },
            $fragment: true,
        },
        //#endregion
    }, {
        /**
         * This is an alias of {@link nbtSchemas.PlayerClient}, this only exists because it is what it is called on the Minecraft Wiki, so it is here for the Minecraft Wiki data to schema converter.
         *
         * @deprecated Use {@link nbtSchemas.PlayerClient} instead.
         */
        Players: {
            key: "PlayerClient",
            markdownDescription: "The players data.",
        },
        /**
         * This is an alias of {@link nbtSchemas.Entity_Player}.
         */
        Player: {
            key: "Entity_Player",
        },
        /**
         * This is an alias of {@link nbtSchemas.TickingArea}, this only exists because it is what it is called on the Minecraft Wiki, so it is here for the Minecraft Wiki data to schema converter.
         *
         * @deprecated Use {@link nbtSchemas.TickingArea} instead.
         */
        Tickingarea: {
            key: "TickingArea",
        },
        /**
         * This is an alias of {@link nbtSchemas.VillageDwellers}, this only exists because it is what it is called on the Minecraft Wiki, so it is here for the Minecraft Wiki data to schema converter.
         *
         * @deprecated Use {@link nbtSchemas.VillageDwellers} instead.
         */
        VILLAGE_DWELLERS: {
            key: "VillageDwellers",
        },
        /**
         * This is an alias of {@link nbtSchemas.VillageInfo}, this only exists because it is what it is called on the Minecraft Wiki, so it is here for the Minecraft Wiki data to schema converter.
         *
         * @deprecated Use {@link nbtSchemas.VillageInfo} instead.
         */
        VILLAGE_INFO: {
            key: "VillageInfo",
        },
        /**
         * This is an alias of {@link nbtSchemas.VillagePlayers}, this only exists because it is what it is called on the Minecraft Wiki, so it is here for the Minecraft Wiki data to schema converter.
         *
         * @deprecated Use {@link nbtSchemas.VillagePlayers} instead.
         */
        VILLAGE_PLAYERS: {
            key: "VillagePlayers",
        },
        /**
         * This is an alias of {@link nbtSchemas.VillagePOI}, this only exists because it is what it is called on the Minecraft Wiki, so it is here for the Minecraft Wiki data to schema converter.
         *
         * @deprecated Use {@link nbtSchemas.VillagePOI} instead.
         */
        VILLAGE_POI: {
            key: "VillagePOI",
        },
    });
    // Script to figure out all keys in the LevelChunkMetaDataDictionary:
    // const allKeys = [...new Set(Object.values(data).flatMap(v=>Object.keys(v.value)))];
    // const requiredKeys = allKeys.filter(k=>Object.values(data).every(v=>k in v.value));
    // const optionalKeys = allKeys.filter(v=>!requiredKeys.includes(v));
    // Script to find an object containing every found key if it is available:
    // Object.entries(data).map((v, i)=>[...v, i]).find(v=>allKeys.every(k=>k in v[1].value))
    /**
     * The JSON schema for Prismarine-NBT JSON.
     */
    NBTSchemas.GenericPrismarineJSONNBTSchema = {
        $schema: "https://json-schema.org/draft/2020-12/schema",
        $id: "GenericPrismarineJSONNBTSchema",
        title: "Prismarine NBT JSON Schema",
        type: "object",
        required: ["type", "value"],
        properties: {
            name: {
                type: "string",
                default: "",
            },
            type: {
                const: "compound",
            },
            value: {
                type: "object",
                additionalProperties: {
                    anyOf: [
                        { type: "null" },
                        {
                            type: "object",
                            oneOf: [
                                {
                                    properties: {
                                        type: { const: "byte" },
                                        value: { type: "integer" },
                                    },
                                    required: ["type", "value"],
                                },
                                {
                                    properties: {
                                        type: { const: "short" },
                                        value: { type: "integer" },
                                    },
                                    required: ["type", "value"],
                                },
                                {
                                    properties: {
                                        type: { const: "int" },
                                        value: { type: "integer" },
                                    },
                                    required: ["type", "value"],
                                },
                                {
                                    properties: {
                                        type: { const: "long" },
                                        value: {
                                            type: "array",
                                            items: { type: "integer" },
                                            minItems: 2,
                                            maxItems: 2,
                                        },
                                    },
                                    required: ["type", "value"],
                                },
                                {
                                    properties: {
                                        type: { const: "float" },
                                        value: { type: "number" },
                                    },
                                    required: ["type", "value"],
                                },
                                {
                                    properties: {
                                        type: { const: "double" },
                                        value: { type: "number" },
                                    },
                                    required: ["type", "value"],
                                },
                                {
                                    properties: {
                                        type: { const: "string" },
                                        value: { type: "string" },
                                    },
                                    required: ["type", "value"],
                                },
                                {
                                    properties: {
                                        type: { const: "list" },
                                        value: {
                                            type: "object",
                                            properties: {
                                                type: { type: "string" },
                                                value: {
                                                    type: "array",
                                                },
                                            },
                                            required: ["type", "value"],
                                        },
                                    },
                                    required: ["type", "value"],
                                },
                                {
                                    properties: {
                                        type: { const: "compound" },
                                        value: { $ref: "#" },
                                    },
                                    required: ["type", "value"],
                                },
                                {
                                    properties: {
                                        type: { const: "byteArray" },
                                        value: {
                                            type: "array",
                                            items: { type: "integer" },
                                        },
                                    },
                                    required: ["type", "value"],
                                },
                                {
                                    properties: {
                                        type: { const: "shortArray" },
                                        value: {
                                            type: "array",
                                            items: { type: "integer" },
                                        },
                                    },
                                    required: ["type", "value"],
                                },
                                {
                                    properties: {
                                        type: { const: "intArray" },
                                        value: {
                                            type: "array",
                                            items: { type: "integer" },
                                        },
                                    },
                                    required: ["type", "value"],
                                },
                                {
                                    properties: {
                                        type: { const: "longArray" },
                                        value: {
                                            type: "array",
                                            items: {
                                                type: "array",
                                                items: { type: "integer" },
                                                minItems: 2,
                                                maxItems: 2,
                                            },
                                        },
                                    },
                                    required: ["type", "value"],
                                },
                            ],
                        },
                    ],
                },
            },
        },
    };
    /**
     * Utilities for working with NBT schemas.
     */
    let Utils;
    (function (Utils) {
        /**
         * Utilities for converting to and from NBT schemas.
         */
        let Conversion;
        (function (Conversion) {
            /**
             * Utilities for converting NBT schemas to JSON schemas.
             */
            let ToJSONSchema;
            (function (ToJSONSchema) {
                ToJSONSchema.defaultConvertOptions = {
                    inlineRefs: true,
                    makeValueSchema: false,
                };
                /**
                 * Convert a custom NBT schema into JSON Schema for NBT tags.
                 *
                 * @param schema The NBT schema to convert.
                 * @param allSchemas The NBT schemas to use for resolving `$ref`s. Defaults to {@link nbtSchemas}.
                 * @param options Options for the conversion.
                 * @returns The resulting JSON Schema.
                 */
                function nbtSchemaToJsonSchema(schema, allSchemas = NBTSchemas.nbtSchemas, options = {}, isRoot = true) {
                    if (typeof schema === "boolean") {
                        return schema;
                    }
                    if (!schema)
                        throw new TypeError("schema is required, recieved " + schema);
                    const jsonSchema = {
                        id: schema.id,
                        $id: schema.$id,
                        $schema: schema.$schema,
                        title: schema.title,
                        description: schema.description,
                        markdownDescription: schema.markdownDescription,
                    };
                    if (!("id" in schema))
                        delete jsonSchema.id;
                    if (!("$id" in schema))
                        delete jsonSchema.$id;
                    if (!("$schema" in schema))
                        delete jsonSchema.$schema;
                    if (!("title" in schema))
                        delete jsonSchema.title;
                    if (!("description" in schema))
                        delete jsonSchema.description;
                    if (!("markdownDescription" in schema))
                        delete jsonSchema.markdownDescription;
                    if (schema.$ref) {
                        if (options.inlineRefs ?? ToJSONSchema.defaultConvertOptions.inlineRefs) {
                            const refTarget = allSchemas[schema.$ref];
                            if (!refTarget) {
                                throw new Error(`Unknown $ref: ${schema.$ref}`);
                            }
                            const schemaRef = nbtSchemaToJsonSchema(refTarget, allSchemas, options, isRoot);
                            if (Object.keys(schema).length === 1)
                                return schemaRef;
                            jsonSchema.allOf = [schemaRef];
                            // if (typeof schemaRef === "boolean") return schemaRef;
                            // for (const [k, v] of Object.entries(schemaRef) as [keyof JSONSchema, JSONSchema[keyof JSONSchema]][]) {
                            //     if ((k in jsonSchema)) continue;
                            //     jsonSchema[k] = v;
                            // }
                        }
                        else {
                            jsonSchema.$ref = schema.$ref;
                        }
                    }
                    // FIXME: List int value enum entries inside of a oneOf in the int value seem to only work when the enum array is just the numbers and not the full NBT.Int objects, fix this.
                    for (const key of ["oneOf", "anyOf", "allOf"]) {
                        if (!(key in schema) || !schema[key])
                            continue;
                        jsonSchema[key] = [
                            ...(jsonSchema[key] ?? []),
                            ...schema[key].map((s) => nbtSchemaToJsonSchema(s, allSchemas, options, isRoot)),
                        ];
                    }
                    for (const key of ["not"]) {
                        if (!(key in schema) || schema[key] === undefined)
                            continue;
                        jsonSchema[key] = nbtSchemaToJsonSchema(schema[key], allSchemas, options, isRoot);
                    }
                    let valueSchema;
                    let skipExtraPropertyDefs = false;
                    if (schema.type) {
                        if (Array.isArray(schema.type)) {
                            jsonSchema.oneOf = schema.type.map((t) => tagTypeToSchema(t, schema, allSchemas, options, isRoot));
                        }
                        else {
                            skipExtraPropertyDefs = true;
                            /* if (schema.type === "compound" && schema.id && !schema.properties) {
                                const data: JSONSchema = tagTypeToSchema(schema.type, schema, allSchemas, options);
                                Object.assign(jsonSchema, { ...data, ...(data.properties!.value as JSONSchema) });
                            } else  */ {
                                Object.assign(jsonSchema, tagTypeToSchema(schema.type, { ...schema, $ref: undefined }, allSchemas, options, isRoot));
                                if ((options.makeValueSchema ?? ToJSONSchema.defaultConvertOptions.makeValueSchema) && isRoot) {
                                    // REVIEW: I removed an ! before isRoot, make sure this wasn't a mistake.
                                    valueSchema = jsonSchema.properties?.value ?? jsonSchema;
                                }
                            }
                        }
                    }
                    // copy over JSON-Schema-like constraints (minItems, maxItems, etc.)
                    for (const k of [
                        "enum",
                        "enumDescriptions",
                        "markdownEnumDescriptions",
                        "const",
                        "doNotSuggest",
                        "errorMessage",
                        "deprecationMessage",
                        "examples",
                        "suggestSortText",
                    ]) {
                        if (schema[k] !== undefined) {
                            jsonSchema[k] = schema[k];
                        }
                    }
                    if (typeof valueSchema !== "object")
                        return jsonSchema;
                    if (schema.required) {
                        valueSchema.required = schema.required;
                    }
                    if (schema.properties && !skipExtraPropertyDefs) {
                        valueSchema.type = "object";
                        valueSchema.properties = {};
                        for (const [k, v] of Object.entries(schema.properties)) {
                            valueSchema.properties[k] = nbtSchemaToJsonSchema(v, allSchemas, options, false);
                        }
                    }
                    if (schema.patternProperties && !skipExtraPropertyDefs) {
                        valueSchema.patternProperties = {};
                        for (const [k, v] of Object.entries(schema.patternProperties)) {
                            valueSchema.patternProperties[k] = nbtSchemaToJsonSchema(v, allSchemas, options, false);
                        }
                    }
                    if (schema.additionalProperties !== undefined && !skipExtraPropertyDefs) {
                        if (typeof schema.additionalProperties === "boolean") {
                            valueSchema.additionalProperties = schema.additionalProperties;
                        }
                        else {
                            valueSchema.additionalProperties = nbtSchemaToJsonSchema(schema.additionalProperties, allSchemas, options, false);
                        }
                    }
                    // Only apply top-level items if this schema is a plain JSON array, not an NBT list
                    if (schema.items && schema.type !== NBT.TagType.List) {
                        if (Array.isArray(schema.items)) {
                            valueSchema.items = schema.items.map((item) => nbtSchemaToJsonSchema(item, allSchemas, options, false));
                        }
                        else if (typeof schema.items === "object") {
                            valueSchema.items = nbtSchemaToJsonSchema(schema.items, allSchemas, options, false);
                        }
                    }
                    // copy over JSON-Schema-like constraints (minItems, maxItems, etc.)
                    for (const k of [
                        "minItems",
                        "maxItems",
                        "minProperties",
                        "maxProperties",
                        "minLength",
                        "maxLength",
                        "minimum",
                        "maximum",
                        "exclusiveMinimum",
                        "exclusiveMaximum",
                        "multipleOf",
                        "errorMessage",
                        "format",
                        "pattern",
                        "patternErrorMessage",
                        "propertyNames",
                        "uniqueItems",
                    ]) {
                        if (schema[k] !== undefined) {
                            valueSchema[k] = schema[k];
                        }
                    }
                    return jsonSchema;
                }
                ToJSONSchema.nbtSchemaToJsonSchema = nbtSchemaToJsonSchema;
                function tagTypeToSchema(type, schema, allSchemas, options, isRoot = false) {
                    switch (type) {
                        case NBT.TagType.Byte:
                        case NBT.TagType.Short:
                        case NBT.TagType.Int: {
                            const valueType = { type: "integer" };
                            if ((schema.description === undefined && schema.markdownDescription === undefined) ||
                                !((options.makeValueSchema ?? ToJSONSchema.defaultConvertOptions.makeValueSchema) && isRoot)) {
                                valueType.description = valueType.markdownDescription = `A ${type}.`;
                            }
                            switch (type) {
                                case NBT.TagType.Byte:
                                    valueType.minimum = -128;
                                    valueType.maximum = 127;
                                    break;
                                case NBT.TagType.Short:
                                    valueType.minimum = -32768;
                                    valueType.maximum = 32767;
                                    break;
                                case NBT.TagType.Int:
                                    valueType.minimum = -2147483648;
                                    valueType.maximum = 2147483647;
                                    break;
                            }
                            if (schema.enum?.some((v) => v.type === type)) {
                                valueType.enum = schema.enum.filter((v) => v.type === type).map((v) => v.value);
                                if (schema.enumDescriptions) {
                                    valueType.enumDescriptions = schema.enum
                                        .map((v, i) => [v.type, i])
                                        .filter((v) => v[0] === type)
                                        .map((v) => schema.enumDescriptions[v[1]]);
                                }
                                if (schema.markdownEnumDescriptions) {
                                    valueType.markdownEnumDescriptions = schema.enum
                                        .map((v, i) => [v.type, i])
                                        .filter((v) => v[0] === type)
                                        .map((v) => schema.markdownEnumDescriptions[v[1]]);
                                }
                            }
                            if (schema.const !== undefined) {
                                valueType.const =
                                    "type" in schema.const && "value" in schema.const && schema.const.type === type ? schema.const.value : schema.const;
                            }
                            if (schema.examples?.some((v) => v.type === type)) {
                                valueType.examples = schema.examples.filter((v) => v.type === type).map((v) => v.value);
                            }
                            if (schema.default !== undefined) {
                                valueType.default =
                                    "type" in schema.default && "value" in schema.default && schema.default.type === type ?
                                        schema.default.value
                                        : schema.default;
                            }
                            let resultSchema = valueType;
                            if (!((options.makeValueSchema ?? ToJSONSchema.defaultConvertOptions.makeValueSchema) && isRoot)) {
                                resultSchema = {
                                    type: "object",
                                    properties: {
                                        type: { const: type },
                                        value: valueType,
                                    },
                                    required: ["type", "value"],
                                };
                                for (const k of ["enum", "const", "examples", "default"]) {
                                    if (schema[k] !== undefined) {
                                        resultSchema[k] = JSON.parse(JSON.stringify(schema[k], (_k, v) => (typeof v === "bigint" ? toLongParts(v) : v)));
                                    }
                                }
                                for (const k of ["enumDescriptions", "markdownEnumDescriptions"]) {
                                    if (schema[k] !== undefined) {
                                        resultSchema[k] = schema[k];
                                    }
                                }
                            }
                            for (const k of [
                                "id",
                                "$id",
                                "$schema",
                                "$ref",
                                "$comment",
                                "title",
                                "description",
                                "markdownDescription",
                                "doNotSuggest",
                                "errorMessage",
                                "deprecationMessage",
                                "suggestSortText",
                            ]) {
                                if (schema[k] !== undefined) {
                                    resultSchema[k] = schema[k];
                                }
                            }
                            for (const k of [
                                // "minItems",
                                // "maxItems",
                                // "minProperties",
                                // "maxProperties",
                                "minLength",
                                "maxLength",
                                "minimum",
                                "maximum",
                                "exclusiveMinimum",
                                "exclusiveMaximum",
                                "multipleOf",
                                "errorMessage",
                                "format",
                                "pattern",
                                "patternErrorMessage",
                                // "propertyNames",
                                // "uniqueItems",
                            ]) {
                                if (schema[k] !== undefined) {
                                    valueType[k] = schema[k];
                                }
                            }
                            return resultSchema;
                        }
                        case NBT.TagType.Long: {
                            const valueType = {
                                type: "array",
                                items: [
                                    { title: "High", type: "integer", minimum: -0x80000000, maximum: 0x7fffffff },
                                    { title: "Low", type: "integer", minimum: -0x80000000, maximum: 0x7fffffff },
                                ],
                                minItems: 2,
                                maxItems: 2,
                            };
                            if ((schema.description === undefined && schema.markdownDescription === undefined) ||
                                !((options.makeValueSchema ?? ToJSONSchema.defaultConvertOptions.makeValueSchema) && isRoot)) {
                                valueType.description = valueType.markdownDescription = `A ${type}.`;
                            }
                            if (schema.enum?.some((v) => v.type === type)) {
                                valueType.enum = schema.enum
                                    .filter((v) => v.type === type)
                                    .map((v) => (typeof v.value === "bigint" ? toLongParts(v.value) : v.value));
                                if (schema.enumDescriptions) {
                                    valueType.enumDescriptions = schema.enum
                                        .map((v, i) => [v.type, i])
                                        .filter((v) => v[0] === type)
                                        .map((v) => schema.enumDescriptions[v[1]]);
                                }
                                if (schema.markdownEnumDescriptions) {
                                    valueType.markdownEnumDescriptions = schema.enum
                                        .map((v, i) => [v.type, i])
                                        .filter((v) => v[0] === type)
                                        .map((v) => schema.markdownEnumDescriptions[v[1]]);
                                }
                            }
                            if (schema.const !== undefined) {
                                valueType.const =
                                    "type" in schema.const && "value" in schema.const && schema.const.type === type ?
                                        typeof schema.const.value === "bigint" ?
                                            toLongParts(schema.const.value)
                                            : schema.const.value
                                        : schema.const;
                            }
                            if (schema.examples?.some((v) => v.type === type)) {
                                valueType.examples = schema.examples
                                    .filter((v) => v.type === type)
                                    .map((v) => (typeof v.value === "bigint" ? toLongParts(v.value) : v.value));
                            }
                            if (schema.default !== undefined) {
                                valueType.default =
                                    "type" in schema.default && "value" in schema.default && schema.default.type === type ?
                                        typeof schema.default.value === "bigint" ?
                                            toLongParts(schema.default.value)
                                            : schema.default.value
                                        : typeof schema.default === "bigint" ? toLongParts(schema.default)
                                            : schema.default;
                            }
                            let resultSchema = valueType;
                            if (!((options.makeValueSchema ?? ToJSONSchema.defaultConvertOptions.makeValueSchema) && isRoot)) {
                                resultSchema = {
                                    type: "object",
                                    properties: {
                                        type: { const: type },
                                        value: valueType,
                                    },
                                    required: ["type", "value"],
                                };
                                for (const k of ["enum", "const", "examples", "default"]) {
                                    if (schema[k] !== undefined) {
                                        resultSchema[k] = JSON.parse(JSON.stringify(schema[k], (_k, v) => (typeof v === "bigint" ? toLongParts(v) : v)));
                                    }
                                }
                                for (const k of ["enumDescriptions", "markdownEnumDescriptions"]) {
                                    if (schema[k] !== undefined) {
                                        resultSchema[k] = schema[k];
                                    }
                                }
                            }
                            for (const k of [
                                "id",
                                "$id",
                                "$schema",
                                "$ref",
                                "$comment",
                                "title",
                                "description",
                                "markdownDescription",
                                "doNotSuggest",
                                "errorMessage",
                                "deprecationMessage",
                                "suggestSortText",
                            ]) {
                                if (schema[k] !== undefined) {
                                    resultSchema[k] = schema[k];
                                }
                            }
                            for (const k of [
                                // "minItems",
                                // "maxItems",
                                // "minProperties",
                                // "maxProperties",
                                // "minLength",
                                // "maxLength",
                                // "minimum",
                                // "maximum",
                                // "exclusiveMinimum",
                                // "exclusiveMaximum",
                                // "multipleOf",
                                "errorMessage",
                                "format",
                                "pattern",
                                "patternErrorMessage",
                                // "propertyNames",
                                // "uniqueItems",
                            ]) {
                                if (schema[k] !== undefined) {
                                    valueType[k] = schema[k];
                                }
                            }
                            return resultSchema;
                        }
                        case NBT.TagType.Float:
                        case NBT.TagType.Double: {
                            const valueType = { type: "number" };
                            if ((schema.description === undefined && schema.markdownDescription === undefined) ||
                                !((options.makeValueSchema ?? ToJSONSchema.defaultConvertOptions.makeValueSchema) && isRoot)) {
                                valueType.description = valueType.markdownDescription = `A ${type}.`;
                            }
                            if (schema.enum?.some((v) => v.type === type)) {
                                valueType.enum = schema.enum.filter((v) => v.type === type).map((v) => v.value);
                                if (schema.enumDescriptions) {
                                    valueType.enumDescriptions = schema.enum
                                        .map((v, i) => [v.type, i])
                                        .filter((v) => v[0] === type)
                                        .map((v) => schema.enumDescriptions[v[1]]);
                                }
                                if (schema.markdownEnumDescriptions) {
                                    valueType.markdownEnumDescriptions = schema.enum
                                        .map((v, i) => [v.type, i])
                                        .filter((v) => v[0] === type)
                                        .map((v) => schema.markdownEnumDescriptions[v[1]]);
                                }
                            }
                            if (schema.const !== undefined) {
                                valueType.const =
                                    "type" in schema.const && "value" in schema.const && schema.const.type === type ? schema.const.value : schema.const;
                            }
                            if (schema.examples?.some((v) => v.type === type)) {
                                valueType.examples = schema.examples.filter((v) => v.type === type).map((v) => v.value);
                            }
                            if (schema.default !== undefined) {
                                valueType.default =
                                    "type" in schema.default && "value" in schema.default && schema.default.type === type ?
                                        schema.default.value
                                        : schema.default;
                            }
                            let resultSchema = valueType;
                            if (!((options.makeValueSchema ?? ToJSONSchema.defaultConvertOptions.makeValueSchema) && isRoot)) {
                                resultSchema = {
                                    type: "object",
                                    properties: {
                                        type: { const: type },
                                        value: valueType,
                                    },
                                    required: ["type", "value"],
                                };
                                for (const k of ["enum", "const", "examples", "default"]) {
                                    if (schema[k] !== undefined) {
                                        resultSchema[k] = JSON.parse(JSON.stringify(schema[k], (_k, v) => (typeof v === "bigint" ? toLongParts(v) : v)));
                                    }
                                }
                                for (const k of ["enumDescriptions", "markdownEnumDescriptions"]) {
                                    if (schema[k] !== undefined) {
                                        resultSchema[k] = schema[k];
                                    }
                                }
                            }
                            for (const k of [
                                "id",
                                "$id",
                                "$schema",
                                "$ref",
                                "$comment",
                                "title",
                                "description",
                                "markdownDescription",
                                "doNotSuggest",
                                "errorMessage",
                                "deprecationMessage",
                                "suggestSortText",
                            ]) {
                                if (schema[k] !== undefined) {
                                    resultSchema[k] = schema[k];
                                }
                            }
                            for (const k of [
                                // "minItems",
                                // "maxItems",
                                // "minProperties",
                                // "maxProperties",
                                "minLength",
                                "maxLength",
                                "minimum",
                                "maximum",
                                "exclusiveMinimum",
                                "exclusiveMaximum",
                                "multipleOf",
                                "errorMessage",
                                "format",
                                "pattern",
                                "patternErrorMessage",
                                // "propertyNames",
                                // "uniqueItems",
                            ]) {
                                if (schema[k] !== undefined) {
                                    valueType[k] = schema[k];
                                }
                            }
                            return resultSchema;
                        }
                        case NBT.TagType.String: {
                            const valueType = { type: "string" };
                            if ((schema.description === undefined && schema.markdownDescription === undefined) ||
                                !((options.makeValueSchema ?? ToJSONSchema.defaultConvertOptions.makeValueSchema) && isRoot)) {
                                valueType.description = valueType.markdownDescription = `A ${type}.`;
                            }
                            if (schema.enum?.some((v) => v.type === type)) {
                                valueType.enum = schema.enum.filter((v) => v.type === type).map((v) => v.value);
                                if (schema.enumDescriptions) {
                                    valueType.enumDescriptions = schema.enum
                                        .map((v, i) => [v.type, i])
                                        .filter((v) => v[0] === type)
                                        .map((v) => schema.enumDescriptions[v[1]]);
                                }
                                if (schema.markdownEnumDescriptions) {
                                    valueType.markdownEnumDescriptions = schema.enum
                                        .map((v, i) => [v.type, i])
                                        .filter((v) => v[0] === type)
                                        .map((v) => schema.markdownEnumDescriptions[v[1]]);
                                }
                            }
                            if (schema.const !== undefined) {
                                valueType.const =
                                    "type" in schema.const && "value" in schema.const && schema.const.type === type ? schema.const.value : schema.const;
                            }
                            if (schema.examples?.some((v) => v.type === type)) {
                                valueType.examples = schema.examples.filter((v) => v.type === type).map((v) => v.value);
                            }
                            if (schema.default !== undefined) {
                                valueType.default =
                                    "type" in schema.default && "value" in schema.default && schema.default.type === type ?
                                        schema.default.value
                                        : schema.default;
                            }
                            let resultSchema = valueType;
                            if (!((options.makeValueSchema ?? ToJSONSchema.defaultConvertOptions.makeValueSchema) && isRoot)) {
                                resultSchema = {
                                    type: "object",
                                    properties: {
                                        type: { const: type },
                                        value: valueType,
                                    },
                                    required: ["type", "value"],
                                };
                                for (const k of ["enum", "const", "examples", "default"]) {
                                    if (schema[k] !== undefined) {
                                        resultSchema[k] = JSON.parse(JSON.stringify(schema[k], (_k, v) => (typeof v === "bigint" ? toLongParts(v) : v)));
                                    }
                                }
                                for (const k of ["enumDescriptions", "markdownEnumDescriptions"]) {
                                    if (schema[k] !== undefined) {
                                        resultSchema[k] = schema[k];
                                    }
                                }
                            }
                            for (const k of [
                                "id",
                                "$id",
                                "$schema",
                                "$ref",
                                "$comment",
                                "title",
                                "description",
                                "markdownDescription",
                                "doNotSuggest",
                                "errorMessage",
                                "deprecationMessage",
                                "suggestSortText",
                            ]) {
                                if (schema[k] !== undefined) {
                                    resultSchema[k] = schema[k];
                                }
                            }
                            for (const k of [
                                // "minItems",
                                // "maxItems",
                                // "minProperties",
                                // "maxProperties",
                                "minLength",
                                "maxLength",
                                "minimum",
                                "maximum",
                                "exclusiveMinimum",
                                "exclusiveMaximum",
                                "multipleOf",
                                "errorMessage",
                                "format",
                                "pattern",
                                "patternErrorMessage",
                                // "propertyNames",
                                // "uniqueItems",
                            ]) {
                                if (schema[k] !== undefined) {
                                    valueType[k] = schema[k];
                                }
                            }
                            return resultSchema;
                        }
                        case NBT.TagType.List: {
                            const valueType = {
                                type: "object",
                                properties: {
                                    type: (!schema.items ||
                                        schema.items === true ||
                                        (schema.items instanceof Array ?
                                            schema.items.includes(true) ||
                                                schema.items.includes(false) ||
                                                schema.items.length === 0 ||
                                                schema.items.every((v) => v.type === undefined)
                                            : schema.items.type === undefined || (schema.items.type instanceof Array && schema.items.type.length === 0))) ?
                                        { type: "string" }
                                        : {
                                            enum: [
                                                ...new Set((schema.items instanceof Array ?
                                                    schema.items.flatMap((v) => [v.type].flat())
                                                    : [schema.items.type].flat()).filter((v) => v !== undefined)),
                                                ...(!schema.minItems ? ["end"] : []),
                                            ],
                                        },
                                    value: {
                                        type: "array",
                                        items: schema.items ?
                                            nbtSchemaToJsonSchema(schema.items, allSchemas, { ...options, makeValueSchema: true }, true)
                                            : {},
                                    },
                                },
                                required: ["type", "value"],
                            };
                            if ((schema.description === undefined && schema.markdownDescription === undefined) ||
                                !((options.makeValueSchema ?? ToJSONSchema.defaultConvertOptions.makeValueSchema) && isRoot)) {
                                valueType.description = valueType.markdownDescription = `A ${type}.`;
                            }
                            if (schema.enum?.some((v) => v.type === type)) {
                                valueType.enum = schema.enum.filter((v) => v.type === type).map((v) => v.value);
                                if (schema.enumDescriptions) {
                                    valueType.enumDescriptions = schema.enum
                                        .map((v, i) => [v.type, i])
                                        .filter((v) => v[0] === type)
                                        .map((v) => schema.enumDescriptions[v[1]]);
                                }
                                if (schema.markdownEnumDescriptions) {
                                    valueType.markdownEnumDescriptions = schema.enum
                                        .map((v, i) => [v.type, i])
                                        .filter((v) => v[0] === type)
                                        .map((v) => schema.markdownEnumDescriptions[v[1]]);
                                }
                            }
                            if (schema.const !== undefined) {
                                valueType.const =
                                    "type" in schema.const && "value" in schema.const && schema.const.type === type ? schema.const.value : schema.const;
                            }
                            if (schema.examples?.some((v) => v.type === type)) {
                                valueType.examples = schema.examples.filter((v) => v.type === type).map((v) => v.value);
                            }
                            if (schema.default !== undefined) {
                                valueType.default =
                                    "type" in schema.default && "value" in schema.default && schema.default.type === type ?
                                        schema.default.value
                                        : schema.default;
                            }
                            let resultSchema = valueType;
                            if (!((options.makeValueSchema ?? ToJSONSchema.defaultConvertOptions.makeValueSchema) && isRoot)) {
                                resultSchema = {
                                    type: "object",
                                    properties: {
                                        type: { const: type },
                                        value: valueType,
                                    },
                                    required: ["type", "value"],
                                };
                                for (const k of ["enum", "const", "examples", "default"]) {
                                    if (schema[k] !== undefined) {
                                        resultSchema[k] = JSON.parse(JSON.stringify(schema[k], (_k, v) => (typeof v === "bigint" ? toLongParts(v) : v)));
                                    }
                                }
                                for (const k of ["enumDescriptions", "markdownEnumDescriptions"]) {
                                    if (schema[k] !== undefined) {
                                        resultSchema[k] = schema[k];
                                    }
                                }
                            }
                            for (const k of [
                                "id",
                                "$id",
                                "$schema",
                                "$ref",
                                "$comment",
                                "title",
                                "description",
                                "markdownDescription",
                                "doNotSuggest",
                                "errorMessage",
                                "deprecationMessage",
                                "suggestSortText",
                            ]) {
                                if (schema[k] !== undefined) {
                                    resultSchema[k] = schema[k];
                                }
                            }
                            for (const k of [
                                "minItems",
                                "maxItems",
                                // "minProperties",
                                // "maxProperties",
                                // "minLength",
                                // "maxLength",
                                // "minimum",
                                // "maximum",
                                // "exclusiveMinimum",
                                // "exclusiveMaximum",
                                // "multipleOf",
                                "errorMessage",
                                "format",
                                "pattern",
                                "patternErrorMessage",
                                // "propertyNames",
                                "uniqueItems",
                            ]) {
                                if (schema[k] !== undefined) {
                                    valueType[k] = schema[k];
                                }
                            }
                            return resultSchema;
                        }
                        case NBT.TagType.Compound: {
                            const valueType = {
                                type: "object",
                                properties: schema.properties ?
                                    Object.fromEntries(Object.entries(schema.properties).map(([k, v]) => [
                                        k,
                                        nbtSchemaToJsonSchema(v, allSchemas, options, false),
                                    ]))
                                    : {},
                                required: schema.required,
                                additionalProperties: typeof schema.additionalProperties === "object" ?
                                    nbtSchemaToJsonSchema(schema.additionalProperties, allSchemas, options, false)
                                    : true,
                            };
                            if ((schema.description === undefined && schema.markdownDescription === undefined) ||
                                !((options.makeValueSchema ?? ToJSONSchema.defaultConvertOptions.makeValueSchema) && isRoot)) {
                                valueType.description = valueType.markdownDescription = `A ${type}.`;
                            }
                            if (schema.enum?.some((v) => v.type === type)) {
                                valueType.enum = schema.enum.filter((v) => v.type === type).map((v) => v.value);
                                if (schema.enumDescriptions) {
                                    valueType.enumDescriptions = schema.enum
                                        .map((v, i) => [v.type, i])
                                        .filter((v) => v[0] === type)
                                        .map((v) => schema.enumDescriptions[v[1]]);
                                }
                                if (schema.markdownEnumDescriptions) {
                                    valueType.markdownEnumDescriptions = schema.enum
                                        .map((v, i) => [v.type, i])
                                        .filter((v) => v[0] === type)
                                        .map((v) => schema.markdownEnumDescriptions[v[1]]);
                                }
                            }
                            if (schema.const !== undefined) {
                                valueType.const =
                                    "type" in schema.const && "value" in schema.const && schema.const.type === type ? schema.const.value : schema.const;
                            }
                            if (schema.examples?.some((v) => v.type === type)) {
                                valueType.examples = schema.examples.filter((v) => v.type === type).map((v) => v.value);
                            }
                            if (schema.default !== undefined) {
                                valueType.default =
                                    "type" in schema.default && "value" in schema.default && schema.default.type === type ?
                                        schema.default.value
                                        : schema.default;
                            }
                            let resultSchema = valueType;
                            if (!((options.makeValueSchema ?? ToJSONSchema.defaultConvertOptions.makeValueSchema) && isRoot)) {
                                resultSchema = {
                                    type: "object",
                                    properties: {
                                        type: { const: type },
                                        value: valueType,
                                    },
                                    required: ["type", "value"],
                                };
                                for (const k of ["enum", "const", "examples", "default"]) {
                                    if (schema[k] !== undefined) {
                                        resultSchema[k] = JSON.parse(JSON.stringify(schema[k], (_k, v) => (typeof v === "bigint" ? toLongParts(v) : v)));
                                    }
                                }
                                for (const k of ["enumDescriptions", "markdownEnumDescriptions"]) {
                                    if (schema[k] !== undefined) {
                                        resultSchema[k] = schema[k];
                                    }
                                }
                            }
                            for (const k of [
                                "id",
                                "$id",
                                "$schema",
                                "$ref",
                                "$comment",
                                "title",
                                "description",
                                "markdownDescription",
                                "doNotSuggest",
                                "errorMessage",
                                "deprecationMessage",
                                "suggestSortText",
                            ]) {
                                if (schema[k] !== undefined) {
                                    resultSchema[k] = schema[k];
                                }
                            }
                            for (const k of [
                                // "minItems",
                                // "maxItems",
                                "minProperties",
                                "maxProperties",
                                // "minLength",
                                // "maxLength",
                                // "minimum",
                                // "maximum",
                                // "exclusiveMinimum",
                                // "exclusiveMaximum",
                                // "multipleOf",
                                "errorMessage",
                                "format",
                                "pattern",
                                "patternErrorMessage",
                                "propertyNames",
                                // "uniqueItems",
                            ]) {
                                if (schema[k] !== undefined) {
                                    valueType[k] = schema[k];
                                }
                            }
                            return resultSchema;
                        }
                        case NBT.TagType.ByteArray:
                        case NBT.TagType.ShortArray:
                        case NBT.TagType.IntArray: {
                            const valueType = {
                                type: "array",
                                items: { type: "integer" },
                            };
                            if ((schema.description === undefined && schema.markdownDescription === undefined) ||
                                !((options.makeValueSchema ?? ToJSONSchema.defaultConvertOptions.makeValueSchema) && isRoot)) {
                                valueType.description = valueType.markdownDescription = `A ${type}.`;
                            }
                            switch (type) {
                                case NBT.TagType.ByteArray:
                                    valueType.items.minimum = -128;
                                    valueType.items.maximum = 127;
                                    break;
                                case NBT.TagType.ShortArray:
                                    valueType.items.minimum = -32768;
                                    valueType.items.maximum = 32767;
                                    break;
                                case NBT.TagType.IntArray:
                                    valueType.items.minimum = -2147483648;
                                    valueType.items.maximum = 2147483647;
                                    break;
                            }
                            if (schema.enum?.some((v) => v.type === type)) {
                                valueType.enum = schema.enum.filter((v) => v.type === type).map((v) => v.value);
                                if (schema.enumDescriptions) {
                                    valueType.enumDescriptions = schema.enum
                                        .map((v, i) => [v.type, i])
                                        .filter((v) => v[0] === type)
                                        .map((v) => schema.enumDescriptions[v[1]]);
                                }
                                if (schema.markdownEnumDescriptions) {
                                    valueType.markdownEnumDescriptions = schema.enum
                                        .map((v, i) => [v.type, i])
                                        .filter((v) => v[0] === type)
                                        .map((v) => schema.markdownEnumDescriptions[v[1]]);
                                }
                            }
                            if (schema.const !== undefined) {
                                valueType.const =
                                    "type" in schema.const && "value" in schema.const && schema.const.type === type ? schema.const.value : schema.const;
                            }
                            if (schema.examples?.some((v) => v.type === type)) {
                                valueType.examples = schema.examples.filter((v) => v.type === type).map((v) => v.value);
                            }
                            if (schema.default !== undefined) {
                                valueType.default =
                                    "type" in schema.default && "value" in schema.default && schema.default.type === type ?
                                        schema.default.value
                                        : schema.default;
                            }
                            let resultSchema = valueType;
                            if (!((options.makeValueSchema ?? ToJSONSchema.defaultConvertOptions.makeValueSchema) && isRoot)) {
                                resultSchema = {
                                    type: "object",
                                    properties: {
                                        type: { const: type },
                                        value: valueType,
                                    },
                                    required: ["type", "value"],
                                };
                                for (const k of ["enum", "const", "examples", "default"]) {
                                    if (schema[k] !== undefined) {
                                        resultSchema[k] = JSON.parse(JSON.stringify(schema[k], (_k, v) => (typeof v === "bigint" ? toLongParts(v) : v)));
                                    }
                                }
                                for (const k of ["enumDescriptions", "markdownEnumDescriptions"]) {
                                    if (schema[k] !== undefined) {
                                        resultSchema[k] = schema[k];
                                    }
                                }
                            }
                            for (const k of [
                                "id",
                                "$id",
                                "$schema",
                                "$ref",
                                "$comment",
                                "title",
                                "description",
                                "markdownDescription",
                                "doNotSuggest",
                                "errorMessage",
                                "deprecationMessage",
                                "suggestSortText",
                            ]) {
                                if (schema[k] !== undefined) {
                                    resultSchema[k] = schema[k];
                                }
                            }
                            for (const k of [
                                "minItems",
                                "maxItems",
                                // "minProperties",
                                // "maxProperties",
                                // "minLength",
                                // "maxLength",
                                // "minimum",
                                // "maximum",
                                // "exclusiveMinimum",
                                // "exclusiveMaximum",
                                // "multipleOf",
                                "errorMessage",
                                "format",
                                "pattern",
                                "patternErrorMessage",
                                // "propertyNames",
                                "uniqueItems",
                            ]) {
                                if (schema[k] !== undefined) {
                                    valueType[k] = schema[k];
                                }
                            }
                            return resultSchema;
                        }
                        case NBT.TagType.LongArray: {
                            const valueType = {
                                type: "array",
                                items: {
                                    type: "array",
                                    items: { type: "integer", minimum: -0x80000000, maximum: 0x7fffffff },
                                    minItems: 2,
                                    maxItems: 2,
                                },
                            };
                            if ((schema.description === undefined && schema.markdownDescription === undefined) ||
                                !((options.makeValueSchema ?? ToJSONSchema.defaultConvertOptions.makeValueSchema) && isRoot)) {
                                valueType.description = valueType.markdownDescription = `A ${type}.`;
                            }
                            if (schema.enum?.some((v) => v.type === type)) {
                                valueType.enum = schema.enum
                                    .filter((v) => v.type === type)
                                    .map((v) => JSON.parse(JSON.stringify(v.value, (_k, v) => (typeof v === "bigint" ? toLongParts(v) : v))));
                                if (schema.enumDescriptions) {
                                    valueType.enumDescriptions = schema.enum
                                        .map((v, i) => [v.type, i])
                                        .filter((v) => v[0] === type)
                                        .map((v) => schema.enumDescriptions[v[1]]);
                                }
                                if (schema.markdownEnumDescriptions) {
                                    valueType.markdownEnumDescriptions = schema.enum
                                        .map((v, i) => [v.type, i])
                                        .filter((v) => v[0] === type)
                                        .map((v) => schema.markdownEnumDescriptions[v[1]]);
                                }
                            }
                            if (schema.const !== undefined) {
                                valueType.const =
                                    "type" in schema.const && "value" in schema.const && schema.const.type === type ?
                                        JSON.parse(JSON.stringify(schema.const.value, (_k, v) => typeof v === "bigint" ? toLongParts(v) : v))
                                        : JSON.parse(JSON.stringify(schema.const, (_k, v) => (typeof v === "bigint" ? toLongParts(v) : v)));
                            }
                            if (schema.examples?.some((v) => v.type === type)) {
                                valueType.examples = schema.examples
                                    .filter((v) => v.type === type)
                                    .map((v) => JSON.parse(JSON.stringify(v.value, (_k, v) => (typeof v === "bigint" ? toLongParts(v) : v))));
                            }
                            if (schema.default !== undefined) {
                                valueType.default =
                                    "type" in schema.default && "value" in schema.default && schema.default.type === type ?
                                        JSON.parse(JSON.stringify(schema.default.value, (_k, v) => typeof v === "bigint" ? toLongParts(v) : v))
                                        : JSON.parse(JSON.stringify(schema.default, (_k, v) => (typeof v === "bigint" ? toLongParts(v) : v)));
                            }
                            let resultSchema = valueType;
                            if (!((options.makeValueSchema ?? ToJSONSchema.defaultConvertOptions.makeValueSchema) && isRoot)) {
                                resultSchema = {
                                    type: "object",
                                    properties: {
                                        type: { const: type },
                                        value: valueType,
                                    },
                                    required: ["type", "value"],
                                };
                                for (const k of ["enum", "const", "examples", "default"]) {
                                    if (schema[k] !== undefined) {
                                        resultSchema[k] = JSON.parse(JSON.stringify(schema[k], (_k, v) => (typeof v === "bigint" ? toLongParts(v) : v)));
                                    }
                                }
                                for (const k of ["enumDescriptions", "markdownEnumDescriptions"]) {
                                    if (schema[k] !== undefined) {
                                        resultSchema[k] = schema[k];
                                    }
                                }
                            }
                            for (const k of [
                                "id",
                                "$id",
                                "$schema",
                                "$ref",
                                "$comment",
                                "title",
                                "description",
                                "markdownDescription",
                                "doNotSuggest",
                                "errorMessage",
                                "deprecationMessage",
                                "suggestSortText",
                            ]) {
                                if (schema[k] !== undefined) {
                                    resultSchema[k] = schema[k];
                                }
                            }
                            for (const k of [
                                "minItems",
                                "maxItems",
                                // "minProperties",
                                // "maxProperties",
                                // "minLength",
                                // "maxLength",
                                // "minimum",
                                // "maximum",
                                // "exclusiveMinimum",
                                // "exclusiveMaximum",
                                // "multipleOf",
                                "errorMessage",
                                "format",
                                "pattern",
                                "patternErrorMessage",
                                // "propertyNames",
                                "uniqueItems",
                            ]) {
                                if (schema[k] !== undefined) {
                                    valueType[k] = schema[k];
                                }
                            }
                            return resultSchema;
                        }
                        default:
                            throw new Error(`Unsupported NBT type: ${type}`);
                    }
                }
                /**
                 * Convert the whole nbtSchemas object.
                 *
                 * @param schemas The NBT schemas to convert.
                 * @param options The conversion options.
                 * @returns The converted NBT schemas.
                 */
                function convertAllSchemas(schemas, options = { inlineRefs: true }) {
                    const result = {};
                    for (const [name, schema] of Object.entries(schemas)) {
                        result[name] = nbtSchemaToJsonSchema(schema, schemas, options);
                    }
                    return result;
                }
                ToJSONSchema.convertAllSchemas = convertAllSchemas;
            })(ToJSONSchema = Conversion.ToJSONSchema || (Conversion.ToJSONSchema = {}));
            /**
             * Utilities for converting NBT schemas to TypeScript types.
             */
            let ToTypeScriptType;
            (function (ToTypeScriptType) {
                /**
                 * Format a value for use in a TypeScript type.
                 *
                 * @param value The value to format.
                 * @returns The formatted value.
                 *
                 * @internal
                 */
                function formatValue(value) {
                    if (Array.isArray(value)) {
                        return value.map(formatValue).join(" | ");
                    }
                    if (typeof value === "bigint") {
                        // return value.toString() + "n"; // preserve as bigint literal
                        return `[high: ${toLongParts(value).join(", low: ")}]`; // Convert the long back to the high and low parts.
                    }
                    if (typeof value === "object" && value !== null) {
                        if ("value" in value)
                            return formatValue(value.value);
                        try {
                            return JSON.stringify(value);
                        }
                        catch {
                            return String(value);
                        }
                    }
                    return typeof value === "string" ? JSON.stringify(value) : String(value);
                }
                /**
                 * Format a list of enum values for use in a TypeScript type.
                 *
                 * @param enumValues The enum values to format.
                 * @returns The formatted enum values.
                 *
                 * @internal
                 */
                function formatEnum(enumValues) {
                    return enumValues
                        .map((v) => {
                        if (typeof v === "object" && v.value !== undefined) {
                            return formatValue(v.value);
                        }
                        return formatValue(v);
                    })
                        .join(" | ");
                }
                function makeHelperName(base, ctx) {
                    ctx.helperCounter++;
                    return `${base}Variant${ctx.helperCounter}`;
                }
                /**
                 * Maps primitive NBT types to their Prismarine-NBT value representation.
                 *
                 * @internal
                 */
                function primitiveValueType(t) {
                    switch (t) {
                        case "byte":
                        case "short":
                        case "int":
                        case "float":
                        case "double":
                            return "number";
                        case "long":
                            return "[high: number, low: number]";
                        case "string":
                            return "string";
                        case "byteArray":
                        case "intArray":
                        case "shortArray":
                            return "number[]";
                        case "longArray":
                            return "[high: number, low: number][]";
                        case "end":
                            return "[]";
                        default:
                            return "any";
                    }
                }
                /**
                 * Renders a TSDoc comment block for a schema node.
                 *
                 * @internal
                 */
                function renderComment(schema, symbolReference, indent = "") {
                    if (!schema)
                        return "";
                    const parts = [];
                    if (schema.title)
                        parts.push(schema.title);
                    if (schema.markdownDescription ?? schema.description)
                        parts.push(schema.markdownDescription ?? schema.description);
                    // if (schema.description) parts.push(schema.title ? "@description\n" + schema.description : schema.description); // Alternate version if you the description should use the `description` TSDoc tag if there is a title.
                    if (symbolReference && symbolReference.length > 0)
                        parts.push(symbolReference.map((ref, i) => `@see {@link ${ref}}`).join("\n"));
                    // Handle min/max length
                    if (schema.minLength !== undefined) {
                        const val = formatValue(schema.minLength);
                        // Put on new line if contains non-alphanumeric characters
                        if (/[^a-zA-Z0-9_.=+-]/.test(val) && !/^"[a-zA-Z0-9_.=+-\s]+"$/.test(val)) {
                            parts.push(`@minLength\n${val}`);
                        }
                        else {
                            parts.push(`@minLength ${val}`);
                        }
                    }
                    if (schema.maxLength !== undefined) {
                        const val = formatValue(schema.maxLength);
                        // Put on new line if contains non-alphanumeric characters
                        if (/[^a-zA-Z0-9_.=+-]/.test(val) && !/^"[a-zA-Z0-9_.=+-\s]+"$/.test(val)) {
                            parts.push(`@maxLength\n${val}`);
                        }
                        else {
                            parts.push(`@maxLength ${val}`);
                        }
                    }
                    // Handle min/max items
                    if (schema.minItems !== undefined) {
                        const val = formatValue(schema.minItems);
                        // Put on new line if contains non-alphanumeric characters
                        if (/[^a-zA-Z0-9_.=+-]/.test(val) && !/^"[a-zA-Z0-9_.=+-\s]+"$/.test(val)) {
                            parts.push(`@minItems\n${val}`);
                        }
                        else {
                            parts.push(`@minItems ${val}`);
                        }
                    }
                    if (schema.maxItems !== undefined) {
                        const val = formatValue(schema.maxItems);
                        // Put on new line if contains non-alphanumeric characters
                        if (/[^a-zA-Z0-9_.=+-]/.test(val) && !/^"[a-zA-Z0-9_.=+-\s]+"$/.test(val)) {
                            parts.push(`@maxItems\n${val}`);
                        }
                        else {
                            parts.push(`@maxItems ${val}`);
                        }
                    }
                    // Handle min/max properties
                    if (schema.minProperties !== undefined) {
                        const val = formatValue(schema.minProperties);
                        // Put on new line if contains non-alphanumeric characters
                        if (/[^a-zA-Z0-9_.=+-]/.test(val) && !/^"[a-zA-Z0-9_.=+-\s]+"$/.test(val)) {
                            parts.push(`@minProperties\n${val}`);
                        }
                        else {
                            parts.push(`@minProperties ${val}`);
                        }
                    }
                    if (schema.maxProperties !== undefined) {
                        const val = formatValue(schema.maxProperties);
                        // Put on new line if contains non-alphanumeric characters
                        if (/[^a-zA-Z0-9_.=+-]/.test(val) && !/^"[a-zA-Z0-9_.=+-\s]+"$/.test(val)) {
                            parts.push(`@maxProperties\n${val}`);
                        }
                        else {
                            parts.push(`@maxProperties ${val}`);
                        }
                    }
                    // Handle min/max and exclusive min/max
                    if (schema.minimum !== undefined) {
                        const val = formatValue(schema.minimum);
                        // Put on new line if contains non-alphanumeric characters
                        if (/[^a-zA-Z0-9_.=+-]/.test(val) && !/^"[a-zA-Z0-9_.=+-\s]+"$/.test(val)) {
                            parts.push(`@minimum\n${val}`);
                        }
                        else {
                            parts.push(`@minimum ${val}`);
                        }
                    }
                    if (schema.maximum !== undefined) {
                        const val = formatValue(schema.maximum);
                        // Put on new line if contains non-alphanumeric characters
                        if (/[^a-zA-Z0-9_.=+-]/.test(val) && !/^"[a-zA-Z0-9_.=+-\s]+"$/.test(val)) {
                            parts.push(`@maximum\n${val}`);
                        }
                        else {
                            parts.push(`@maximum ${val}`);
                        }
                    }
                    if (schema.exclusiveMinimum !== undefined) {
                        const val = formatValue(schema.exclusiveMinimum);
                        // Put on new line if contains non-alphanumeric characters
                        if (/[^a-zA-Z0-9_.=+-]/.test(val) && !/^"[a-zA-Z0-9_.=+-\s]+"$/.test(val)) {
                            parts.push(`@exclusiveMinimum\n${val}`);
                        }
                        else {
                            parts.push(`@exclusiveMinimum ${val}`);
                        }
                    }
                    if (schema.exclusiveMaximum !== undefined) {
                        const val = formatValue(schema.exclusiveMaximum);
                        // Put on new line if contains non-alphanumeric characters
                        if (/[^a-zA-Z0-9_.=+-]/.test(val) && !/^"[a-zA-Z0-9_.=+-\s]+"$/.test(val)) {
                            parts.push(`@exclusiveMaximum\n${val}`);
                        }
                        else {
                            parts.push(`@exclusiveMaximum ${val}`);
                        }
                    }
                    // Handle other restriction properties
                    if (schema.multipleOf !== undefined) {
                        const val = formatValue(schema.multipleOf);
                        // Put on new line if contains non-alphanumeric characters
                        if (/[^a-zA-Z0-9_.=+-]/.test(val) && !/^"[a-zA-Z0-9_.=+-\s]+"$/.test(val)) {
                            parts.push(`@multipleOf\n${val}`);
                        }
                        else {
                            parts.push(`@multipleOf ${val}`);
                        }
                    }
                    // Handle deprecation
                    if (schema.deprecationMessage !== undefined) {
                        const msg = schema.deprecationMessage;
                        // Put on new line if contains non-alphanumeric characters
                        if (/[^a-zA-Z0-9_.=+-]/.test(msg) && !/^"[a-zA-Z0-9_.=+-\s]+"$/.test(msg)) {
                            parts.push(`@deprecated\n${msg}`);
                        }
                        else {
                            parts.push(`@deprecated ${msg}`);
                        }
                    }
                    // Handle default value
                    if (schema.default !== undefined) {
                        const defVal = formatValue(schema.default);
                        // Put on new line if contains non-alphanumeric characters
                        if (/[^a-zA-Z0-9_.=+-]/.test(defVal) && !/^"[a-zA-Z0-9_.=+-\s]+"$/.test(defVal)) {
                            parts.push(`@default\n${defVal}`);
                        }
                        else {
                            parts.push(`@default ${defVal}`);
                        }
                    }
                    // Handle examples
                    if (schema.examples && Array.isArray(schema.examples)) {
                        for (const ex of schema.examples) {
                            const exVal = formatValue(ex);
                            if (/[^a-zA-Z0-9_]/.test(exVal)) {
                                parts.push(`@example\n${exVal}`);
                            }
                            else {
                                parts.push(`@example ${exVal}`);
                            }
                        }
                    }
                    // Handle enum
                    if (schema.enum && Array.isArray(schema.enum)) {
                        parts.push(`@enum ${formatEnum(schema.enum)}`);
                        const enumDescriptions = schema.markdownEnumDescriptions ? [...schema.markdownEnumDescriptions]
                            : schema.enumDescriptions ? [...schema.enumDescriptions]
                                : undefined;
                        // Merge markdownEnumDescriptions and enumDescriptions if enumDescriptions is longer.
                        if (enumDescriptions &&
                            schema.markdownEnumDescriptions?.length &&
                            schema.enumDescriptions?.length &&
                            schema.enumDescriptions.length > schema.markdownEnumDescriptions.length) {
                            for (let i = 0; i < schema.enumDescriptions.length; i++) {
                                if (i in enumDescriptions)
                                    continue;
                                if (!(i in schema.enumDescriptions))
                                    continue;
                                enumDescriptions[i] = schema.enumDescriptions[i];
                            }
                        }
                        if (enumDescriptions && Array.isArray(enumDescriptions)) {
                            parts.push(`@enumDescriptions\n${enumDescriptions
                                .map((d, i) => `- ${schema.enum[i]?.value !== undefined ? `\`${schema.enum[i]?.value}\`` : `UNKNOWN_ENUM_MEMBER_${i}`}: ${d}`)
                                .join("\n")}`);
                        }
                    }
                    if (parts.length === 0)
                        return "";
                    const lines = parts
                        .join("\n\n")
                        .split("\n")
                        .map((l) => `${indent} * ${l}`);
                    return `${indent}/**\n${lines.join("\n")}\n${indent} */\n`;
                }
                function refToType(ref, indent, opts = {}, ctx = { helperTypes: [], helperCounter: 0 }, additionalInformation = {}) {
                    const refLookup = opts.refLookup ?? NBTSchemas.nbtSchemas;
                    const resolvedRef = (typeof ref === "boolean" ? ref
                        : Array.isArray(ref) ?
                            ref.map((r) => {
                                if (typeof r === "boolean" || !r.$ref || !(r.$ref in refLookup))
                                    return r;
                                const refName = resolveSchemaRefName(r.$ref, !(opts.inlineRefs ?? false), opts);
                                return typeof refLookup[refName] === "string" ?
                                    r
                                    : {
                                        type: refLookup[r.$ref].type,
                                        ...r /* Object.fromEntries(Object.entries(r).filter(([key]): boolean => key !== "$ref")) */,
                                    };
                            })
                            : ((r) => {
                                if (typeof r === "boolean" || !r.$ref || !(r.$ref in refLookup))
                                    return r;
                                const refName = resolveSchemaRefName(r.$ref, !(opts.inlineRefs ?? false), opts);
                                return typeof refLookup[refName] === "string" ?
                                    r
                                    : {
                                        type: refLookup[r.$ref].type,
                                        ...r /* Object.fromEntries(Object.entries(r).filter(([key]): boolean => key !== "$ref")) */,
                                    };
                            })(ref)); /* ref.$ref !== undefined && ref.$ref in refLookup
                    ? typeof refLookup[ref.$ref as keyof typeof refLookup] === "string"
                        ? ref
                        : {
                              ...(refLookup[ref.$ref as keyof typeof refLookup] as object),
                              ...Object.fromEntries(Object.entries(ref).filter(([key]) => key !== "$ref")),
                          }
                    : ref */
                    if (resolvedRef === true) {
                        return { type: "any", value: "any" };
                    }
                    if (resolvedRef === false) {
                        return { type: "never", value: "never" };
                    }
                    if (Array.isArray(resolvedRef)) {
                        if (resolvedRef.length === 0)
                            return { type: "never", value: "never" };
                        // tuple-style list -> union of each item
                        const children = resolvedRef.map((r) => refToType(r, indent, opts, ctx, { ...additionalInformation, isListChild: true }));
                        const allSameType = children.every((c) => c.type === children[0].type);
                        if (allSameType) {
                            // collapse into single type wrapping array of values
                            return {
                                type: '"list"',
                                value: {
                                    type: children[0].type,
                                    value: children.map((c) => ({
                                        type: c.type,
                                        value: c.value,
                                    })),
                                },
                            };
                        }
                        else {
                            // mixed types not supported in NBT, fallback to unknown
                            return {
                                type: '"list"',
                                value: {
                                    type: "unknown",
                                    value: children,
                                },
                            };
                        }
                    }
                    // single schema
                    return schemaToBuiltType(resolvedRef, indent, opts, ctx, additionalInformation);
                }
                function schemaToBuiltType(schema, indent, opts, ctx, additionalInformation = {}) {
                    const refLookup = opts.refLookup ?? NBTSchemas.nbtSchemas;
                    const st = schema.type;
                    const mainSchemaRefName = schema.$ref ? resolveSchemaRefName(schema.$ref, !(opts.inlineRefs ?? false), opts) : undefined;
                    const resolvedSchema = opts.inlineRefs && schema.$ref && mainSchemaRefName && mainSchemaRefName in refLookup ?
                        {
                            ...refLookup[mainSchemaRefName],
                            ...schema,
                        }
                        : schema;
                    let allOfRefTypes = (opts.inlineRefs ?? false) ? undefined
                        : typeof schema === "object" && schema.$ref !== undefined && mainSchemaRefName !== undefined /*  && schema.$ref in refLookup */ ?
                            [mainSchemaRefName + (additionalInformation.isListChild ? '["value"]' : "")]
                            : undefined;
                    if (!(opts.inlineRefs ?? false) && schema.allOf !== undefined) {
                        const refAllOfs = schema.allOf.filter((ref) => typeof ref === "object" && !!ref.$ref);
                        if (refAllOfs.length > 0) {
                            allOfRefTypes ??= [];
                            for (const refAllOf of refAllOfs) {
                                allOfRefTypes.push(resolveSchemaRefName(refAllOf.$ref, !(opts.inlineRefs ?? false), opts) +
                                    (additionalInformation.isListChild ? '["value"]' : ""));
                            }
                        }
                    }
                    let oneOfRefTypes = undefined;
                    if (!(opts.inlineRefs ?? false) && schema.oneOf !== undefined) {
                        const refOneOfs = schema.oneOf.filter((ref) => typeof ref === "object" && !!ref.$ref);
                        if (refOneOfs.length > 0) {
                            oneOfRefTypes ??= [];
                            for (const refOneOf of refOneOfs) {
                                oneOfRefTypes.push(resolveSchemaRefName(refOneOf.$ref, !(opts.inlineRefs ?? false), opts) +
                                    (additionalInformation.isListChild ? '["value"]' : ""));
                            }
                        }
                    }
                    let anyOfRefTypes = undefined;
                    if (!(opts.inlineRefs ?? false) && schema.anyOf !== undefined) {
                        const refAnyOfs = schema.anyOf.filter((ref) => typeof ref === "object" && !!ref.$ref);
                        if (refAnyOfs.length > 0) {
                            anyOfRefTypes ??= [];
                            for (const refAnyOf of refAnyOfs) {
                                anyOfRefTypes.push(resolveSchemaRefName(refAnyOf.$ref, !(opts.inlineRefs ?? false), opts) +
                                    (additionalInformation.isListChild ? '["value"]' : ""));
                            }
                        }
                    }
                    let allOfNonRefTypes = undefined;
                    if (schema.allOf !== undefined) {
                        const nonRefAllOfs = schema.allOf.filter((ref) => typeof ref !== "object" || ref.$ref === undefined);
                        if (nonRefAllOfs.length > 0) {
                            allOfNonRefTypes ??= [];
                            for (const nonRefAllOf of nonRefAllOfs) {
                                const types = nonRefAllOf.type ?? resolvedSchema.type;
                                if (!types)
                                    continue;
                                allOfNonRefTypes.push(Array.isArray(types) ?
                                    types.map((t) => buildBuiltTypeForTag(t, nonRefAllOf, indent, opts, ctx).value).join("|")
                                    : buildBuiltTypeForTag(types, nonRefAllOf, indent, opts, ctx).value);
                            }
                        }
                    }
                    let oneOfNonRefTypes = undefined;
                    if (schema.oneOf !== undefined) {
                        const nonRefOneOfs = schema.oneOf.filter((ref) => typeof ref !== "object" || ref.$ref === undefined);
                        if (nonRefOneOfs.length > 0) {
                            oneOfNonRefTypes ??= [];
                            for (const nonRefOneOf of nonRefOneOfs) {
                                const types = nonRefOneOf.type ?? resolvedSchema.type;
                                if (!types)
                                    continue;
                                oneOfNonRefTypes.push(Array.isArray(types) ?
                                    types.map((t) => buildBuiltTypeForTag(t, nonRefOneOf, indent, opts, ctx).value).join("|")
                                    : buildBuiltTypeForTag(types, nonRefOneOf, indent, opts, ctx).value);
                            }
                        }
                    }
                    let anyOfNonRefTypes = undefined;
                    if (schema.anyOf !== undefined) {
                        const nonRefAnyOfs = schema.anyOf.filter((ref) => typeof ref !== "object" || ref.$ref === undefined);
                        if (nonRefAnyOfs.length > 0) {
                            anyOfNonRefTypes ??= [];
                            for (const nonRefAnyOf of nonRefAnyOfs) {
                                const types = nonRefAnyOf.type ?? resolvedSchema.type;
                                if (!types)
                                    continue;
                                anyOfNonRefTypes.push(Array.isArray(types) ?
                                    types.map((t) => buildBuiltTypeForTag(t, nonRefAnyOf, indent, opts, ctx).value).join("|")
                                    : buildBuiltTypeForTag(types, nonRefAnyOf, indent, opts, ctx).value);
                            }
                        }
                    }
                    const inlineRefTypes = {
                        allOf: [],
                        oneOf: [],
                        anyOf: [],
                    };
                    if (opts.inlineRefs ?? false) {
                        if (allOfRefTypes)
                            for (const refType of allOfRefTypes) {
                                const types = refLookup[refType].type ?? resolvedSchema.type;
                                if (!types)
                                    continue;
                                inlineRefTypes.allOf.push(Array.isArray(types) ?
                                    types
                                        .map((t) => buildTypeForTag(t, refLookup[refType], indent, opts, ctx))
                                        .join("|")
                                    : buildTypeForTag(types, refLookup[refType], indent, opts, ctx));
                            }
                        if (oneOfRefTypes)
                            for (const refType of oneOfRefTypes) {
                                const types = refLookup[refType].type ?? resolvedSchema.type;
                                if (!types)
                                    continue;
                                inlineRefTypes.oneOf.push(Array.isArray(types) ?
                                    types
                                        .map((t) => buildTypeForTag(t, refLookup[refType], indent, opts, ctx))
                                        .join("|")
                                    : buildTypeForTag(types, refLookup[refType], indent, opts, ctx));
                            }
                        if (anyOfRefTypes)
                            for (const refType of anyOfRefTypes) {
                                const types = refLookup[refType].type ?? resolvedSchema.type;
                                if (!types)
                                    continue;
                                inlineRefTypes.anyOf.push(Array.isArray(types) ?
                                    types
                                        .map((t) => buildTypeForTag(t, refLookup[refType], indent, opts, ctx))
                                        .join("|")
                                    : buildTypeForTag(types, refLookup[refType], indent, opts, ctx));
                            }
                    }
                    if (!st) {
                        if (resolvedSchema.properties) {
                            const compoundType = buildBuiltTypeForTag("compound", resolvedSchema, indent, opts, ctx);
                            return {
                                type: '"compound"',
                                value: (opts.inlineRefs ?? false) ?
                                    `${(allOfRefTypes || oneOfRefTypes || anyOfRefTypes) && /^(?:\{\s*\}|object)$/.test(compoundType.value) ? "" : `(${compoundType.value})`}${inlineRefTypes.allOf ? ` & ${inlineRefTypes.allOf.join(" & ")}` : ""}${inlineRefTypes.oneOf ? ` & (ExclusifyUnion<${inlineRefTypes.oneOf.join(" | ")}>)` : ""}${inlineRefTypes.anyOf ? ` & (${inlineRefTypes.anyOf.join(" | ")})` : ""}`
                                    : `${(allOfRefTypes || oneOfRefTypes || anyOfRefTypes) && /^(?:\{\s*\}|object)$/.test(compoundType.value) ? "" : `(${compoundType.value})`}${allOfRefTypes ? ` & ${allOfRefTypes.join(" & ")}` : ""}${oneOfRefTypes ? ` & (ExclusifyUnion<${oneOfRefTypes.join(" | ")}>)` : ""}${anyOfRefTypes ? ` & (${anyOfRefTypes.join(" | ")})` : ""}`.replace(/^ & /, ""),
                            };
                        }
                        if (!(opts.inlineRefs ?? false) && schema.$ref) {
                            const refType = refLookup[resolveSchemaRefName(schema.$ref, false, opts)]
                                ?.type;
                            return {
                                type: typeof refType === "string" ? `"${refType}"` : "unknown",
                                value: mainSchemaRefName + (additionalInformation.isListChild ? '["value"]' : ""),
                            };
                        }
                        return { type: "unknown", value: "any" };
                    }
                    const builtType = buildBuiltTypeForTag(st, resolvedSchema, indent, opts, ctx);
                    return {
                        type: builtType.type,
                        value: (opts.inlineRefs ?? false) ?
                            `${(allOfRefTypes || oneOfRefTypes || anyOfRefTypes || oneOfNonRefTypes || allOfNonRefTypes || anyOfNonRefTypes) && /^(?:\{\s*\}|object)$/.test(builtType.value) ? "" : `(${builtType.value})`}${inlineRefTypes.allOf || allOfNonRefTypes ?
                                ` & ${[...(inlineRefTypes.allOf ?? []), ...(allOfNonRefTypes ?? [])].join(" & ")}`
                                : ""}${inlineRefTypes.oneOf || oneOfNonRefTypes ?
                                ` & (ExclusifyUnion<${[...(inlineRefTypes.oneOf ?? []), ...(oneOfNonRefTypes ?? [])].join(" | ")}>)`
                                : ""}${inlineRefTypes.anyOf || anyOfNonRefTypes ?
                                ` & (${[...(inlineRefTypes.anyOf ?? []), ...(anyOfNonRefTypes ?? [])].join(" | ")})`
                                : ""}`.replace(/^ & /, "")
                            : `${(allOfRefTypes || oneOfRefTypes || anyOfRefTypes || oneOfNonRefTypes || allOfNonRefTypes || anyOfNonRefTypes) && /^(?:\{\s*\}|object)$/.test(builtType.value) ? "" : `(${builtType.value})`}${allOfRefTypes || allOfNonRefTypes ? ` & ${[...(allOfRefTypes ?? []), ...(allOfNonRefTypes ?? [])].join(" & ")}` : ""}${oneOfRefTypes || oneOfNonRefTypes ?
                                ` & (ExclusifyUnion<${[...(oneOfRefTypes ?? []), ...(oneOfNonRefTypes ?? [])].join(" | ")}>)`
                                : ""}${anyOfRefTypes || anyOfNonRefTypes ? ` & (${[...(anyOfRefTypes ?? []), ...(anyOfNonRefTypes ?? [])].join(" | ")})` : ""}`.replace(/^ & /, ""),
                    };
                }
                function buildBuiltTypeForTag(tagType, schema, indent, opts, ctx) {
                    const t = tagType;
                    // primitive/simple
                    const primitiveNames = new Set([
                        "byte",
                        "short",
                        "int",
                        "long",
                        "float",
                        "double",
                        "string",
                        "byteArray",
                        "shortArray",
                        "intArray",
                        "longArray",
                        "end",
                    ]);
                    if (primitiveNames.has(t)) {
                        const enumVals = schema.enum;
                        if (enumVals && enumVals.length > 0) {
                            const literals = formatEnum(enumVals);
                            return { type: `"${t}"`, value: literals };
                        }
                        return { type: `"${t}"`, value: primitiveValueType(t) };
                    }
                    // LIST
                    if (t === "list") {
                        const items = schema.items;
                        // zero-length list
                        if (Array.isArray(items) && items.length === 0) {
                            if (opts.allowExtraArrayItems) {
                                return { type: '"list"', value: `{ type: "end", value: [] } | { type: any, value: any[] }` };
                            }
                            return { type: '"list"', value: `{ type: "end", value: [] }` };
                        }
                        // unknown list -> union of all Prismarine-NBT types
                        if (!items) {
                            const primitiveListTypes = [
                                "byte",
                                "short",
                                "int",
                                "long",
                                "float",
                                "double",
                                "string",
                                "byteArray",
                                "shortArray",
                                "intArray",
                                "longArray",
                            ];
                            const primitiveUnion = primitiveListTypes.map((pt) => {
                                const valType = pt === "long" ? "[high: number, low: number]"
                                    : pt === "longArray" ? "[high: number, low: number][]"
                                        : pt.endsWith("Array") ? "number[]"
                                            : "number";
                                return { type: `"${pt}"`, value: `${valType}[]` };
                            });
                            const compound = { type: '"compound"', value: "Record<string, any>" };
                            const list = { type: '"list"', value: "any[]" };
                            return {
                                type: '"list"',
                                value: `(${[...primitiveUnion, compound, list].map((v) => `{ type: ${v.type}, value: ${v.value} }`).join(" | ")})[]`,
                            };
                        }
                        if (items === true) {
                            return { type: '"list"', value: `{ type: any, value: any[] }` };
                        }
                        // homogeneous list
                        if (Array.isArray(items)) {
                            const child = refToType(items, indent + "    ", opts, ctx);
                            function builtTypeValueToTupleList(value) {
                                return (typeof value === "string" ? value
                                    : Array.isArray(value) ? value.map(builtTypeValueToTupleList).join(", ")
                                        : builtTypeValueToTupleList(value.value));
                            }
                            if (opts.allowExtraArrayItems) {
                                return {
                                    type: child.type,
                                    value: `{ type: ${child.value.type}, value: [${builtTypeValueToTupleList(child.value.value)}, ...any[]] }`,
                                };
                            }
                            return {
                                type: child.type,
                                value: `{ type: ${child.value.type}, value: [${builtTypeValueToTupleList(child.value.value)}] }`,
                            };
                        }
                        else {
                            // TO-DO: Test this, as it may not work correctly.
                            const child = refToType(items, indent + "    ", opts, ctx, { isListChild: true });
                            function builtTypeValueToUnionList(value) {
                                return (typeof value === "string" ?
                                    value.includes(" & ") ?
                                        `(${value})`
                                        : value
                                    : Array.isArray(value) ? "(" + value.map(builtTypeValueToUnionList).join(" | ") + ")"
                                        : builtTypeValueToUnionList(value.value));
                            }
                            return { type: '"list"', value: `{ type: ${child.type}, value: ${builtTypeValueToUnionList(child.value)}[] }` };
                        }
                    }
                    // compound
                    if (t === "compound") {
                        const props = schema.properties ?? {};
                        const parentReq = new Set(schema.required ?? []);
                        const lines = Object.entries(props).map(([key, val]) => {
                            const childSchema = val;
                            const comment = renderComment(childSchema, undefined, indent);
                            const required = parentReq.has(key) || childSchema.required === true;
                            const sep = required ? ":" : "?:";
                            return comment + `${indent}${JSON.stringify(key)}${sep} ${schemaToType(childSchema, indent + "    ", opts, ctx)};`;
                        });
                        const propLinesCount = lines.length;
                        if (schema.patternProperties) {
                            let found = [];
                            for (const [key, value] of Object.entries(schema.patternProperties)) {
                                let keyType = "string";
                                switch (true) {
                                    case key === "[0-9]+":
                                    case key === "\\d+":
                                    case key === "[+-]?[0-9]+":
                                    case key === "[+-]?\\d+":
                                    case key === "\\+[0-9]+":
                                    case key === "\\+\\d+":
                                    case key === "-[0-9]+":
                                    case key === "-\\d+":
                                        keyType = "`${bigint}`";
                                        break;
                                    case key === "[0-9]+(\\.[0-9]+)?":
                                    case key === "\\d+(\\.\\d+)?":
                                    case key === "[+-]?[0-9]+(\\.[0-9]+)?":
                                    case key === "[+-]?\\d+(\\.\\d+)?":
                                    case key === "\\+[0-9]+(\\.[0-9]+)?":
                                    case key === "\\+\\d+(\\.\\d+)?":
                                    case key === "-[0-9]+(\\.[0-9]+)?":
                                    case key === "-\\d+(\\.\\d+)?":
                                        keyType = "number";
                                        break;
                                    case key.includes("[0-9]+"):
                                        keyType = `\`${key.replaceAll("[0-9]+", "${bigint}")}\``;
                                        break;
                                    case key.includes("\\d+"):
                                        keyType = `\`${key.replaceAll("\\d+", "${number}")}\``;
                                        break;
                                }
                                found.push([keyType, schemaToType(value, indent + "    ", opts, ctx)]);
                            }
                            for (const key of new Set(found.map(([key]) => key))) {
                                if (found.filter(([key2]) => key2 === key).length === 1) {
                                    lines.push(`${propLinesCount > 0 ? `${indent}} & {\n` : ""}${indent}[key: ${key}]: ${found.find(([key2]) => key2 === key)[1]};`);
                                }
                                else {
                                    lines.push(`${propLinesCount > 0 ? `${indent}} & {\n` : ""}${indent}[key: ${key}]: (${found
                                        .filter(([key2]) => key2 === key)
                                        .map(([, value]) => value)
                                        .join(") | (")});`);
                                }
                            }
                        }
                        if (schema.additionalProperties !== undefined) {
                            if (schema.additionalProperties !== false) {
                                if (schema.additionalProperties === true) {
                                    lines.push(`${propLinesCount > 0 ? `${indent}} & {\n` : ""}${indent}[key: string]: { type: any, value: any };`);
                                }
                                else {
                                    const builtType = schemaToBuiltType(schema.additionalProperties, indent + "    ", opts, ctx);
                                    if (schema.additionalProperties.$ref) {
                                        lines.push(`${propLinesCount > 0 ? `${indent}} & {\n` : ""}${indent}[key: string]: ${builtType.value};`);
                                    }
                                    else {
                                        lines.push(`${propLinesCount > 0 ? `${indent}} & {\n` : ""}${indent}[key: string]: ${builtType.value.includes("\n") ?
                                            `{\n${indent}type: ${builtType.type},\n${indent}value: ${builtType.value}\n${indent}}`
                                            : `{ type: ${builtType.type}, value: ${builtType.value} }`};`);
                                    }
                                }
                            }
                        }
                        else if (opts.allowExtraProps) {
                            lines.push(`${propLinesCount > 0 ? `${indent}} & {\n` : ""}${indent}[key: string]: { type: string; value: any };`);
                        }
                        return { type: '"compound"', value: lines.length === 0 ? "object" : `{\n${lines.join("\n")}\n${indent}}` };
                    }
                    // fallback
                    return { type: `"${tagType}"`, value: "any" };
                }
                /**
                 * Build the TypeScript type string for a single tag type given the schema object.
                 * Does NOT handle `schema.type` arrays, that's handled by {@link schemaToType}.
                 *
                 * @internal
                 */
                function buildTypeForTag(tagType, schema, indent, opts, ctx) {
                    const builtType = buildBuiltTypeForTag(tagType, schema, indent, opts, ctx);
                    return `{ type: ${builtType.type}, value: ${builtType.value} }`;
                }
                /**
                 * Resolves a schema ref name.
                 *
                 * @param ref The schema ref to resolve.
                 * @param resolveSymbolName Whether to resolve the symbol name of the resulting TypeScript type. Defaults to `true`.
                 * @param opts Options for the conversion.
                 * @returns The resolved schema ref name.
                 */
                function resolveSchemaRefName(ref, resolveSymbolName = true, opts = {}) {
                    const refLookup = opts.refLookup ?? NBTSchemas.nbtSchemas;
                    if (ref in refLookup &&
                        typeof refLookup[ref] === "string" &&
                        !(refLookup[ref] === ref) &&
                        !(refLookup[refLookup[ref]] === ref)) {
                        return resolveSchemaRefName(refLookup[ref], resolveSymbolName, opts);
                    }
                    return resolveSymbolName ? (opts.schemaIDToSymbolNameResolver?.(ref) ?? ref) : ref;
                }
                ToTypeScriptType.resolveSchemaRefName = resolveSchemaRefName;
                // function resolveSchemaRefIsRenderedAsFragment(
                //     ref: string,
                //     originalID: string,
                //     schema?: NBTSubSchema | undefined,
                //     opts: NBTSchemaToTypeScriptInterfaceConversionOptions = {}
                // ): boolean | undefined {
                //     const refLookup = opts.refLookup ?? nbtSchemas;
                //     if (opts.schemaRefToRenderedInterfaceIsFragmentResolver) {
                //         return opts.schemaRefToRenderedInterfaceIsFragmentResolver(ref, originalID, schema);
                //     }
                //     if (typeof opts.includeRoot === "boolean") return opts.includeRoot;
                //     if (ref in refLookup) {
                //         if (typeof refLookup[ref as keyof typeof refLookup] === "string")
                //             return resolveSchemaRefIsRenderedAsFragment(refLookup[ref as keyof typeof refLookup] as string, originalID, opts);
                //         return (refLookup[ref as keyof typeof refLookup] as NBTSchema | NBTSchemaFragment).$fragment ?? true;
                //     }
                //     return undefined;
                // }
                // function resolveSchemaRefType(ref: string, schema: NBTSubSchema, type: "listitem" | "list" | "compound", opts: NBTSchemaToTypeScriptInterfaceConversionOptions = {}): string {
                //     const refLookup = opts.refLookup ?? nbtSchemas;
                //     const refName = resolveSchemaRefName(ref, opts);
                //     const isFragment = resolveSchemaRefIsRenderedAsFragment(refName, ref, schema, opts);
                //     if (isFragment !== undefined) {
                //         if (isFragment) {
                //                 switch (type) {
                //                     case "compound":
                //                         return `{ properties: ${refName} }`;
                //                     case "list":
                //                         return `{}`
                //                 }
                //         }
                //     }
                // }
                /**
                 * Recursively convert a schema into a TypeScript type string matching Prismarine-NBT JSON.
                 *
                 * @param schema The schema object to convert.
                 * @param indent The indentation string to use for nested types. Defaults to 4 spaces.
                 * @param opts Options for the conversion.
                 * @param ctx Context for the conversion.
                 * @returns The TypeScript type string.
                 *
                 * @internal
                 */
                function schemaToType(schema, indent = "s".repeat(4), opts = {}, ctx = { helperTypes: [], helperCounter: 0 }) {
                    const refLookup = opts.refLookup ?? NBTSchemas.nbtSchemas;
                    const st = schema.type;
                    const mainSchemaRefName = schema.$ref ? resolveSchemaRefName(schema.$ref, !(opts.inlineRefs ?? false), opts) : undefined;
                    const resolvedSchema = opts.inlineRefs && schema.$ref && mainSchemaRefName && mainSchemaRefName in refLookup ?
                        {
                            ...refLookup[mainSchemaRefName],
                            ...schema,
                        }
                        : schema;
                    let allOfRefTypes = (opts.inlineRefs ?? false) ? undefined
                        : typeof schema === "object" && schema.$ref !== undefined && mainSchemaRefName !== undefined /*  && schema.$ref in refLookup */ ?
                            [mainSchemaRefName]
                            : undefined;
                    if (!(opts.inlineRefs ?? false) && schema.allOf !== undefined) {
                        const refAllOfs = schema.allOf.filter((ref) => typeof ref === "object" && !!ref.$ref);
                        if (refAllOfs.length > 0) {
                            allOfRefTypes ??= [];
                            for (const refAllOf of refAllOfs) {
                                allOfRefTypes.push(resolveSchemaRefName(refAllOf.$ref, !(opts.inlineRefs ?? false), opts));
                            }
                        }
                    }
                    let oneOfRefTypes = undefined;
                    if (!(opts.inlineRefs ?? false) && schema.oneOf !== undefined) {
                        const refOneOfs = schema.oneOf.filter((ref) => typeof ref === "object" && !!ref.$ref);
                        if (refOneOfs.length > 0) {
                            oneOfRefTypes ??= [];
                            for (const refOneOf of refOneOfs) {
                                oneOfRefTypes.push(resolveSchemaRefName(refOneOf.$ref, !(opts.inlineRefs ?? false), opts));
                            }
                        }
                    }
                    let anyOfRefTypes = undefined;
                    if (!(opts.inlineRefs ?? false) && schema.anyOf !== undefined) {
                        const refAnyOfs = schema.anyOf.filter((ref) => typeof ref === "object" && !!ref.$ref);
                        if (refAnyOfs.length > 0) {
                            anyOfRefTypes ??= [];
                            for (const refAnyOf of refAnyOfs) {
                                anyOfRefTypes.push(resolveSchemaRefName(refAnyOf.$ref, !(opts.inlineRefs ?? false), opts));
                            }
                        }
                    }
                    let allOfNonRefTypes = undefined;
                    if (schema.allOf !== undefined) {
                        const nonRefAllOfs = schema.allOf.filter((ref) => typeof ref !== "object" || ref.$ref === undefined);
                        if (nonRefAllOfs.length > 0) {
                            allOfNonRefTypes ??= [];
                            for (const nonRefAllOf of nonRefAllOfs) {
                                const types = nonRefAllOf.type ?? resolvedSchema.type;
                                if (!types)
                                    continue;
                                allOfNonRefTypes.push(Array.isArray(types) ?
                                    types.map((t) => buildTypeForTag(t, nonRefAllOf, indent, opts, ctx)).join("|")
                                    : buildTypeForTag(types, nonRefAllOf, indent, opts, ctx));
                            }
                        }
                    }
                    let oneOfNonRefTypes = undefined;
                    if (schema.oneOf !== undefined) {
                        const nonRefOneOfs = schema.oneOf.filter((ref) => typeof ref !== "object" || ref.$ref === undefined);
                        if (nonRefOneOfs.length > 0) {
                            oneOfNonRefTypes ??= [];
                            for (const nonRefOneOf of nonRefOneOfs) {
                                const types = nonRefOneOf.type ?? resolvedSchema.type;
                                if (!types)
                                    continue;
                                oneOfNonRefTypes.push(Array.isArray(types) ?
                                    types.map((t) => buildTypeForTag(t, nonRefOneOf, indent, opts, ctx)).join("|")
                                    : buildTypeForTag(types, nonRefOneOf, indent, opts, ctx));
                            }
                        }
                    }
                    let anyOfNonRefTypes = undefined;
                    if (schema.anyOf !== undefined) {
                        const nonRefAnyOfs = schema.anyOf.filter((ref) => typeof ref !== "object" || ref.$ref === undefined);
                        if (nonRefAnyOfs.length > 0) {
                            anyOfNonRefTypes ??= [];
                            for (const nonRefAnyOf of nonRefAnyOfs) {
                                const types = nonRefAnyOf.type ?? resolvedSchema.type;
                                if (!types)
                                    continue;
                                anyOfNonRefTypes.push(Array.isArray(types) ?
                                    types.map((t) => buildTypeForTag(t, nonRefAnyOf, indent, opts, ctx)).join("|")
                                    : buildTypeForTag(types, nonRefAnyOf, indent, opts, ctx));
                            }
                        }
                    }
                    const inlineRefTypes = {
                        allOf: [],
                        oneOf: [],
                        anyOf: [],
                    };
                    if (opts.inlineRefs ?? false) {
                        if (allOfRefTypes)
                            for (const refType of allOfRefTypes) {
                                const types = refLookup[refType].type ?? resolvedSchema.type;
                                if (!types)
                                    continue;
                                inlineRefTypes.allOf.push(Array.isArray(types) ?
                                    types
                                        .map((t) => buildBuiltTypeForTag(t, refLookup[refType], indent, opts, ctx)
                                        .value)
                                        .join("|")
                                    : buildBuiltTypeForTag(types, refLookup[refType], indent, opts, ctx).value);
                            }
                        if (oneOfRefTypes)
                            for (const refType of oneOfRefTypes) {
                                const types = refLookup[refType].type ?? resolvedSchema.type;
                                if (!types)
                                    continue;
                                inlineRefTypes.oneOf.push(Array.isArray(types) ?
                                    types
                                        .map((t) => buildBuiltTypeForTag(t, refLookup[refType], indent, opts, ctx)
                                        .value)
                                        .join("|")
                                    : buildBuiltTypeForTag(types, refLookup[refType], indent, opts, ctx).value);
                            }
                        if (anyOfRefTypes)
                            for (const refType of anyOfRefTypes) {
                                const types = refLookup[refType].type ?? resolvedSchema.type;
                                if (!types)
                                    continue;
                                inlineRefTypes.anyOf.push(Array.isArray(types) ?
                                    types
                                        .map((t) => buildBuiltTypeForTag(t, refLookup[refType], indent, opts, ctx)
                                        .value)
                                        .join("|")
                                    : buildBuiltTypeForTag(types, refLookup[refType], indent, opts, ctx).value);
                            }
                    }
                    if (!st) {
                        if (resolvedSchema.properties) {
                            const compoundType = buildTypeForTag("compound", resolvedSchema, indent, opts, ctx);
                            return (opts.inlineRefs ?? false) ?
                                `${(allOfRefTypes || oneOfRefTypes || anyOfRefTypes) && /^(?:\{\s*\}|object)$/.test(compoundType) ? "" : `(${compoundType})`}${inlineRefTypes.allOf ? ` & ${inlineRefTypes.allOf.join(" & ")}` : ""}${inlineRefTypes.oneOf ? ` & (ExclusifyUnion<${inlineRefTypes.oneOf.join(" | ")}>)` : ""}${inlineRefTypes.anyOf ? ` & (${inlineRefTypes.anyOf.join(" | ")})` : ""}`
                                : `${(allOfRefTypes || oneOfRefTypes || anyOfRefTypes) && /^(?:\{\s*\}|object)$/.test(compoundType) ? "" : `(${compoundType})`}${allOfRefTypes ? ` & ${allOfRefTypes.join(" & ")}` : ""}${oneOfRefTypes ? ` & (ExclusifyUnion<${oneOfRefTypes.join(" | ")}>)` : ""}${anyOfRefTypes ? ` & (${anyOfRefTypes.join(" | ")})` : ""}`.replace(/^ & /, "");
                        }
                        if (!(opts.inlineRefs ?? false) && schema.$ref) {
                            const refType = refLookup[resolveSchemaRefName(schema.$ref, false, opts)]
                                ?.type;
                            return mainSchemaRefName;
                        }
                        return `{ type: unknown, value: any }`;
                    }
                    const builtType = buildTypeForTag(st, resolvedSchema, indent, opts, ctx);
                    return (opts.inlineRefs ?? false) ?
                        `${(allOfRefTypes || oneOfRefTypes || allOfNonRefTypes || oneOfNonRefTypes) && /^(?:\{\s*\}|object)$/.test(builtType) ? "" : `(${builtType})`}${inlineRefTypes.allOf || allOfNonRefTypes ? ` & ${inlineRefTypes.allOf.join(" & ")}` : ""}${inlineRefTypes.oneOf || oneOfNonRefTypes ? ` & (ExclusifyUnion<${inlineRefTypes.oneOf.join(" | ")}>)` : ""}${inlineRefTypes.anyOf || anyOfNonRefTypes ? ` & (${inlineRefTypes.anyOf.join(" | ")})` : ""}`.replace(/^ & /, "")
                        : `${(allOfRefTypes || oneOfRefTypes || allOfNonRefTypes || oneOfNonRefTypes) && /^(?:\{\s*\}|object)$/.test(builtType) ? "" : `(${builtType})`}${allOfRefTypes || allOfNonRefTypes ? ` & ${[...(allOfRefTypes ?? []), ...(allOfNonRefTypes ?? [])].join(" & ")}` : ""}${oneOfRefTypes || oneOfNonRefTypes ?
                            ` & (ExclusifyUnion<${[...(oneOfRefTypes ?? []), ...(oneOfNonRefTypes ?? [])].join(" | ")}>)`
                            : ""}${anyOfRefTypes || anyOfNonRefTypes ? ` & (${[...(anyOfRefTypes ?? []), ...(anyOfNonRefTypes ?? [])].join(" | ")})` : ""}`.replace(/^ & /, "");
                }
                /**
                 * Generates a TypeScript type from a top-level {@link NBTSchema} or {@link NBTSchemaFragment}.
                 *
                 * @param schema The schema object to convert.
                 * @param name The name of the type.
                 * @param opts Options for the conversion.
                 * @returns The TypeScript type string.
                 *
                 * @todo Add support for `oneOf`, `anyOf`, `allOf`, `not`, `patternProperties`, and `$ref`.
                 * @todo `pattern`, `deprecationMessage`, `multipleOf`, and `uniqueItems` should add a TSDoc comment.
                 * @todo Add support for using the `title` property on items of lists for their labels in their tuple types.
                 */
                function nbtSchemaToTypeScriptType(schema, name, opts = {}) {
                    if (!schema.$fragment && schema.type !== "compound") {
                        throw new Error("Top-level schema must be a compound");
                    }
                    const ctx = { helperTypes: [], helperCounter: 0 };
                    const header = renderComment(schema, opts.originalSymbolReference !== undefined ?
                        Array.isArray(opts.originalSymbolReference) ?
                            opts.originalSymbolReference
                            : [opts.originalSymbolReference]
                        : undefined);
                    const indent = "    ";
                    const typeString = schemaToType(schema, indent, opts, ctx);
                    const helpers = ctx.helperTypes.length > 0 ? ctx.helperTypes.join("\n") + "\n\n" : "";
                    return `${helpers}${header}export type ${name} = ${typeString}`;
                }
                ToTypeScriptType.nbtSchemaToTypeScriptType = nbtSchemaToTypeScriptType;
                // // v1
                // export function nbtSchemaToTypeScriptInterface(
                //     schema: NBTSchema | NBTSchemaFragment,
                //     name: string,
                //     opts: NBTSchemaToTypeScriptInterfaceConversionOptions = {}
                // ): string {
                //     if (!schema.$fragment && schema.type !== "compound") {
                //         throw new Error("Top-level schema must be a compound");
                //     }
                //     const includeRoot: boolean = opts.includeRoot === undefined || opts.includeRoot === "auto" ? !schema.$fragment : opts.includeRoot;
                //     const ctx: NBTSchemaToTypeScriptInterfaceConversionContext = { helperTypes: [], helperCounter: 0 };
                //     const props: NBTSchemaMap = schema.properties ?? {};
                //     const header: string = renderComment(
                //         schema as NBTSubSchema,
                //         opts.originalSymbolReference !== undefined
                //             ? Array.isArray(opts.originalSymbolReference)
                //                 ? opts.originalSymbolReference
                //                 : [opts.originalSymbolReference]
                //             : undefined
                //     );
                //     const baseIndent: string = "    ";
                //     const indent: string = baseIndent.repeat(1 + +includeRoot);
                //     const lines: string[] = Object.entries(props).map(([key, val]: [key: string, value: NBTSubSchema]): string => {
                //         const childSchema: NBTSubSchema = val;
                //         const comment: string = renderComment(childSchema, undefined, indent);
                //         const parentReq = new Set<string>(schema.required ?? []);
                //         const required: boolean = parentReq.has(key) || (childSchema.required as any) === true;
                //         const sep = required ? ":" : "?:";
                //         return comment + `  ${JSON.stringify(key)}${sep} ${schemaToType(childSchema, "    ", opts, ctx)};`;
                //     });
                //     const propLinesCount: number = lines.length;
                //     if (schema.patternProperties) {
                //         let found: [keyType: string, valueType: string][] = [];
                //         for (const [key, value] of Object.entries(schema.patternProperties)) {
                //             let keyType: string = "string";
                //             switch (true) {
                //                 case key === "[0-9]+":
                //                 case key === "\\d+":
                //                 case key === "[+-]?[0-9]+":
                //                 case key === "[+-]?\\d+":
                //                 case key === "\\+[0-9]+":
                //                 case key === "\\+\\d+":
                //                 case key === "-[0-9]+":
                //                 case key === "-\\d+":
                //                     keyType = "`${bigint}`";
                //                     break;
                //                 case key === "[0-9]+(\\.[0-9]+)?":
                //                 case key === "\\d+(\\.\\d+)?":
                //                 case key === "[+-]?[0-9]+(\\.[0-9]+)?":
                //                 case key === "[+-]?\\d+(\\.\\d+)?":
                //                 case key === "\\+[0-9]+(\\.[0-9]+)?":
                //                 case key === "\\+\\d+(\\.\\d+)?":
                //                 case key === "-[0-9]+(\\.[0-9]+)?":
                //                 case key === "-\\d+(\\.\\d+)?":
                //                     keyType = "number";
                //                     break;
                //                 case key.includes("[0-9]+"):
                //                     keyType = `\`${key.replaceAll("[0-9]+", "${bigint}")}\``;
                //                     break;
                //                 case key.includes("\\d+"):
                //                     keyType = `\`${key.replaceAll("\\d+", "${number}")}\``;
                //                     break;
                //             }
                //             found.push([keyType, schemaToType(value, indent, opts, ctx)]);
                //         }
                //         for (const key of new Set(found.map(([key]) => key))) {
                //             if (found.filter(([key2]) => key2 === key).length === 1) {
                //                 lines.push(`${indent}[key: ${key}]: ${found.find(([key2]) => key2 === key)![1]};`);
                //             } else {
                //                 lines.push(
                //                     `${indent}[key: ${key}]: (${found
                //                         .filter(([key2]) => key2 === key)
                //                         .map(([, value]) => value)
                //                         .join(") | (")});`
                //                 );
                //             }
                //         }
                //     }
                //     const extendsLines: string[] = [];
                //     const oneOfLines: string[] = [];
                //     if (schema.$ref) extendsLines.push(opts.schemaIDToSymbolNameResolver?.(schema.$ref) ?? schema.$ref);
                //     if (schema.allOf)
                //         extendsLines.push(
                //             ...schema.allOf
                //                 .filter((v: NBTSubSchemaRef): v is NBTSubSchema & { $ref: string } => typeof v === "object" && v.$ref !== undefined)
                //                 .map((v: NBTSubSchema & { $ref: string }): string => opts.schemaIDToSymbolNameResolver?.(v.$ref) ?? v.$ref)
                //         );
                //     if (schema.oneOf)
                //         extendsLines.push(
                //             ...schema.oneOf
                //                 .filter((v: NBTSubSchemaRef): v is NBTSubSchema & { $ref: string } => typeof v === "object" && v.$ref !== undefined)
                //                 .map((v: NBTSubSchema & { $ref: string }): string => opts.schemaIDToSymbolNameResolver?.(v.$ref) ?? v.$ref)
                //         );
                //     if (schema.additionalProperties !== undefined) {
                //         if (schema.additionalProperties !== false) {
                //             if (schema.additionalProperties === true) {
                //                 extendsLines.push(`Omit<{ [key: string]: { type: any, value: any } }, never>`);
                //             } else {
                //                 extendsLines.push(`Omit<{ [key: string]: ${schemaToType(schema.additionalProperties, indent + "    ", opts, ctx)} }, never>`);
                //             }
                //         }
                //     } else if (opts.allowExtraProps) {
                //         extendsLines.push(`Omit<{ [key: string]: { type: string; value: any } }, never>`);
                //     }
                //     // if (opts.allowExtraProps) {
                //     //     lines.push(`  [key: string]: { type: string; value: any };`);
                //     // }
                //     const helpers: string = ctx.helperTypes.length > 0 ? ctx.helperTypes.join("\n") + "\n\n" : "";
                //     if (includeRoot) {
                //         return `${helpers}${header}export type ${name} = {\n${indent}type: "${schema.type}";\n${indent}value: {\n${lines.join("\n")}\n${indent}};\n}${
                //             extendsLines.length > 0 ? ` & ${extendsLines.join(" & ")}` : ""
                //         }`;
                //     } else {
                //         return `${helpers}${header}export interface ${name}${
                //             extendsLines.length > 0 ? ` extends ${extendsLines.join(",")}` : ""
                //         } {\n${lines.join("\n")}\n}`;
                //     }
                // }
            })(ToTypeScriptType = Conversion.ToTypeScriptType || (Conversion.ToTypeScriptType = {}));
            /**
             * Utilities for converting raw Minecraft Wiki data into NBT schemas.
             */
            let FromMinecraftWikiData;
            (function (FromMinecraftWikiData) {
                /**
                 * Convert a wiki-style description to Markdown.
                 *
                 * @internal
                 */
                function wikiToMarkdown(desc) {
                    if (!desc)
                        return "";
                    return (desc
                        .trim()
                        // Replace {{info needed}} that has nothing around it with "UNDOCUMENTED."
                        .replace(/^\{\{info needed\}\}$/gi, "UNDOCUMENTED.")
                        // Replace {{info needed}} with " *info needed*"
                        .replace(/\{\{info needed\}\}/gi, " *info needed*")
                        // Replace {{needs testing}} that is not touching a word with "*needs testing*"
                        .replace(/(?<!\w)\{\{needs testing\}\}(?!\w)/gi, "*needs testing*")
                        // Replace {{needs testing}} with "*needs testing*"
                        .replace(/\{\{needs testing\}\}/gi, " *needs testing*")
                        // Replace {{code|...}} with `...`
                        .replace(/\{\{code\|([^}]*)\}\}/gi, "`$1`")
                        // TODO: The below two replacements should replace spaces in the URL with underscores.
                        // Replace [[target|label]] with [label](https://minecraft.wiki/w/target)
                        .replace(/\[\[([^\]|]+)\|([^\]]+)\]\]/g, "[$2](https://minecraft.wiki/w/$1)")
                        // Replace [[target]] with [target](https://minecraft.wiki/w/target)
                        .replace(/\[\[([^\]]+)\]\]/g, "[$1](https://minecraft.wiki/w/$1)")
                        // Handle bold/italic.
                        .replace(/'''([^']+)'''/g, "**$1**")
                        .replace(/''([^']+)''/g, "_$1_")
                        // Replace inline HTML-like <code>...</code> with `...`
                        .replace(/<code>(.*?)<\/code>/gi, "`$1`")
                        .replace(/\{\{(?:[^|}]*\|)*([^|}]+)\}\}/g, "$1")
                        // Remove remaining curly braces for safety
                        .replace(/\{\{|\}\}/g, "")
                        .trim());
                }
                /**
                 * Parse the wiki-style NBT lines into a tree of ParsedNode.
                 *
                 * @internal
                 */
                function parseWikiLines(input, options) {
                    const lines = input.split("\n").filter((l) => l.trim().startsWith("*"));
                    const root = { type: "compound", name: "root", children: [] };
                    const stack = [{ level: 0, node: root }];
                    const re = /^(\*+)\s*\{\{nbt\|([^}]*)\}\}:?\s*(.*)$/i;
                    const schemaRefRegex = /\{\{bedrock nbt\|(?<name>[^}|]*)(?:\|(?<category>[^}|]*)?)?\}\}/gi;
                    for (const raw of lines) {
                        const line = raw.trim();
                        const match = line.match(re);
                        if (!match) {
                            for (const match of line.matchAll(schemaRefRegex)) {
                                const name = match.groups.name;
                                const category = (match.groups.category ?? "others");
                                const node = {
                                    type: "schemaRef",
                                    children: [],
                                    $ref: (options.refNameResolver ?? defaultRefNameResolver)(name, category),
                                };
                                stack[stack.length - 1].node.children.push(node);
                                stack.push({ level: stack[stack.length - 1].level + 1, node });
                            }
                            continue;
                        }
                        const level = match[1].length;
                        const parts = match[2].split("|").map((s) => s.trim());
                        const type = parts[0] || "";
                        const name = parts[1] ?? ""; // optional, default empty
                        const description = match[3] ? wikiToMarkdown(match[3].trim()) : undefined;
                        const node = { type, name, description, children: [] };
                        while (stack.length > 1 && stack[stack.length - 1].level >= level) {
                            stack.pop();
                        }
                        stack[stack.length - 1].node.children.push(node);
                        stack.push({ level, node });
                    }
                    return root.children;
                }
                /**
                 * Convert parsed nodes into your NBTSchema (NBTSubSchema) structure.
                 * - unnamed compound nodes merge their children into the parent
                 * - lists use .items as either single schema or tuple array
                 *
                 * @internal
                 */
                function nodeToNBTSchema(node, options) {
                    const alternativeTagNameMapping = {
                        "byte-array": "byteArray",
                        "short-array": "shortArray",
                        "int-array": "intArray",
                        "long-array": "longArray",
                    };
                    const tagTypeList = [
                        "byte",
                        "short",
                        "int",
                        "long",
                        "float",
                        "double",
                        "string",
                        "byteArray",
                        "shortArray",
                        "intArray",
                        "longArray",
                        "list",
                        "compound",
                        "end",
                        "schemaRef",
                    ];
                    const primitiveTags = new Set([
                        "byte",
                        "short",
                        "int",
                        "long",
                        "float",
                        "double",
                        "string",
                        "byteArray",
                        "shortArray",
                        "intArray",
                        "longArray",
                        "end",
                    ]);
                    const t = tagTypeList.includes(node.type) ?
                        node.type
                        : (tagTypeList.find((t) => t.toLowerCase() === node.type.toLowerCase()) ??
                            alternativeTagNameMapping[node.type.toLowerCase()] ??
                            node.type);
                    if (primitiveTags.has(t)) {
                        const base = { type: t };
                        if (node.description)
                            base.markdownDescription = node.description;
                        return Utils.Misc.fixNBTSchemaPropertyOrder(base);
                    }
                    if (t === "list") {
                        const out = { type: "list" };
                        if (node.description)
                            out.description = node.description;
                        if (node.children.length === 0) {
                            // unknown element type
                        }
                        else if (node.children.length === 1) {
                            out.items =
                                node.children[0].type === "schemaRef" ?
                                    { ...(node.children[0].description ? { description: node.children[0].description } : {}), $ref: node.children[0].$ref }
                                    : nodeToNBTSchema(node.children[0], options);
                        }
                        else {
                            out.items = node.children.map((c) => c.type === "schemaRef" ?
                                { ...(c.description ? { description: c.description } : {}), $ref: c.$ref }
                                : nodeToNBTSchema(c, options));
                        }
                        return Utils.Misc.fixNBTSchemaPropertyOrder(out);
                    }
                    if (t === "compound") {
                        const out = { type: "compound", description: node.description, properties: {} };
                        if (!node.description)
                            delete out.description; // Remove description if empty instead of adding if present to make it positioned before properties when JSON.stringified.
                        for (const child of node.children) {
                            const type = tagTypeList.includes(child.type) ?
                                child.type
                                : (tagTypeList.find((t) => t.toLowerCase() === child.type.toLowerCase()) ??
                                    alternativeTagNameMapping[child.type.toLowerCase()] ??
                                    child.type);
                            if (child.$ref) {
                                out.allOf ??= [];
                                out.allOf.push({ $ref: child.$ref });
                                if (type === "schemaRef")
                                    continue;
                            }
                            if (!child.name) {
                                if (type === "compound") {
                                    const childSchema = nodeToNBTSchema(child, options);
                                    if (childSchema && childSchema.properties) {
                                        for (const [k, v] of Object.entries(childSchema.properties)) {
                                            if (!out.properties[k]) {
                                                out.properties[k] = v;
                                                if (v.description && !v.description.includes("(May not exist)")) {
                                                    out.required ??= [];
                                                    out.required.push(k);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            else {
                                out.properties[child.name] = nodeToNBTSchema(child, options);
                                if (child.description && !child.description.includes("(May not exist)")) {
                                    out.required ??= [];
                                    out.required.push(child.name);
                                }
                            }
                        }
                        if (!out.properties || Object.keys(out.properties).length === 0) {
                            delete out.properties;
                            if (out.allOf && out.allOf.length === 1 && typeof out.allOf[0] === "object" && out.allOf[0]?.$ref) {
                                out.$ref = out.allOf[0].$ref;
                                delete out.allOf;
                            }
                        }
                        return Utils.Misc.fixNBTSchemaPropertyOrder(out);
                    }
                    const fallback = { type: node.type };
                    if (node.description)
                        fallback.markdownDescription = node.description;
                    return Utils.Misc.fixNBTSchemaPropertyOrder(fallback);
                }
                /**
                 * Default reference name resolver for {@link wikiNBTToNBTSchema}.
                 *
                 * @see {@link WikiNBTToNBTSchemaOptions.refNameResolver}
                 *
                 * @param schemaName The name of the schema (ex. "Item Stack", "Abilities", or "timer").
                 * @param schemaCategory The category of the schema. (ex. "component" or "item")
                 * @returns The ID to use for the schema `$ref`.
                 */
                function defaultRefNameResolver(schemaName, schemaCategory) {
                    let resolvedSchemaName;
                    switch (true) {
                        case schemaName === "Structuretemplate_<''name''>":
                            resolvedSchemaName = "StructureTemplate";
                            break;
                        case schemaName === "Entity" && (schemaCategory === "entity" || schemaCategory === "others"):
                            return "ActorPrefix";
                        case schemaName === "Block Entity" && schemaCategory === "block":
                            return "BlockEntity";
                        default:
                            resolvedSchemaName = wikiToMarkdown(schemaName
                                .replaceAll(/[,]/g, "_")
                                .replaceAll("_[0-9a-f\\-]+", "")
                                .replaceAll(/(?<!^)\(([^)]*?)\)(?!$)/g, "_$1_")
                                .replaceAll(/(?<!^)\(([^)]*?)\)$/g, "_$1")
                                .replaceAll(/^\(([^)]*?)\)(?!$)/g, "$1_")
                                .replaceAll(/^\(([^)]*?)\)$/g, "$1"))
                                .split(" ")
                                .map((s) => (s.length > 0 ? s[0].toUpperCase() + s.slice(1) : s))
                                .join("");
                    }
                    switch (schemaCategory) {
                        case "block":
                            return `Block_${resolvedSchemaName}`;
                        case "component":
                            return `Component_${resolvedSchemaName}`;
                        case "entity":
                            return `Entity_${resolvedSchemaName}`;
                        case "item":
                            return `Item_${resolvedSchemaName}`;
                        case "others":
                            return `${resolvedSchemaName}`;
                    }
                }
                FromMinecraftWikiData.defaultRefNameResolver = defaultRefNameResolver;
                /**
                 * Converts raw Minecraft Wiki data into an NBT schema.
                 *
                 * To find the data to input into this, go on the Minecraft Wiki and look for NBT/Level Format documentation,
                 * then find the data structure you want to convert and click "Edit Source", then copy the text in between
                 * `<div class="treeview">` and `</div>`, all the lines should begin with an asterisk.
                 *
                 * @example Convert map format to an NBT schema.
                 * ```typescript
                 * const data = `*{{nbt|compound}}: The root tag.
                 * **{{nbt|long|mapId}}: The Unique ID of the map.
                 * **{{nbt|long|parentMapId}}: The Unique ID's of the parent maps.
                 * **{{nbt|byte|dimension}}: 0 = The [[Overworld]], 1 = [[The Nether]], 2 = [[The End]], any other value = a static image with no player pin.
                 * **{{nbt|byte|fullyExplored}}: 1 if the map is full explored.
                 * **{{nbt|byte|mapLocked}}: 1 if the map has been locked in a [[cartography table]].
                 * **{{nbt|byte|scale}}: How zoomed in the map is, and must be a number between 0 and 4 (inclusive) that represent the level. Default 0. If this is changed in an [[anvil]] or a [[cartography table]], the Unique ID of the map changes.
                 * **{{nbt|byte|unlimitedTracking}}: Unknown. Default 0.
                 * **{{nbt|short|height}}: The height of the map. Is associated with the scale level.
                 * **{{nbt|short|width}} The width of the map. Is associated with the scale level.
                 * **{{nbt|int|xCenter}}: Center of the map according to real world by X.
                 * **{{nbt|int|zCenter}}: Center of the map according to real world by Z.
                 * **{{nbt|list|decorations}}: A list of optional icons to display on the map.
                 * ***{{nbt|compound}}: An individual decoration.
                 * ****{{nbt|compound|data}}
                 * *****{{nbt|int|rot}}: The rotation of the symbol, ranging from 0 to 15. South = 0, West = 4, North = 8, East = 12.
                 * *****{{nbt|int|type}}: The ID of the [[Map icons.png|map icon]] to display.
                 * *****{{nbt|int|x}}: The horizontal column (x) where the decoration is located on the map (per pixel).
                 * *****{{nbt|int|y}}: The vertical column (y) where the decoration is located on the map (per pixel).
                 * ****{{nbt|compound|key}}
                 * *****{{nbt|int|blockX}}: The world x-position of the decoration.
                 * *****{{nbt|int|blockY}}: The world y-position of the decoration.
                 * *****{{nbt|int|blockZ}}: The world z-position of the decoration.
                 * *****{{nbt|int|type}}: Unknown.
                 * **{{nbt|byte-array|colors}}: An array of bytes that represent color values ('''65536 entries''' for a default 128×128 map).`;
                 *
                 * writeFileSync(path.join(import.meta.dirname, "./nbtSchema.json"), JSON.stringify(NBTSchemas.Utils.Conversion.FromMinecraftWikiData.wikiNBTToNBTSchema(data), null, 4));
                 * ```
                 */
                function wikiNBTToNBTSchema(input, fragment = "auto", options = {}) {
                    const parsed = parseWikiLines(input, options);
                    // console.log(JSON.stringify(parsed, null, 4));
                    let isFragment = fragment !== "auto" ? fragment : false;
                    if (fragment === "auto" && parsed[0]?.description === "Parent tag.") {
                        isFragment = true;
                        delete parsed[0]?.description;
                    }
                    if (parsed.length === 1 && parsed[0] && (isFragment || parsed[0].type === "compound") && !parsed[0].name) {
                        // console.log(JSON.stringify(parsed, null, 4));
                        let root;
                        if (isFragment && parsed[0].children.length === 1 && parsed[0].children[0] && !parsed[0].children[0].name) {
                            root = nodeToNBTSchema(parsed[0].children[0], options);
                        }
                        else {
                            root = nodeToNBTSchema(parsed[0], options);
                        }
                        // console.log(JSON.stringify(root, null, 4));
                        return Utils.Misc.fixNBTSchemaPropertyOrder({ ...root, $fragment: isFragment });
                    }
                    const root = { id: "", type: "compound", properties: {} };
                    for (const node of parsed) {
                        if (!node.name) {
                            if (node.type === "compound") {
                                const merged = nodeToNBTSchema(node, options);
                                if (merged && merged.properties) {
                                    for (const [k, v] of Object.entries(merged.properties)) {
                                        if (!root.properties[k]) {
                                            root.properties[k] = v;
                                        }
                                    }
                                }
                            }
                        }
                        else {
                            root.properties[node.name] = nodeToNBTSchema(node, options);
                        }
                    }
                    return Utils.Misc.fixNBTSchemaPropertyOrder({ ...root, $fragment: isFragment });
                }
                FromMinecraftWikiData.wikiNBTToNBTSchema = wikiNBTToNBTSchema;
                /**
                 * Extracts NBT schemas from a full Minecraft Wiki page's source contents.
                 *
                 * @param input The full Minecraft Wiki page's source contents.
                 * @param options Options for the extraction.
                 * @returns An array of NBT schemas.
                 */
                function extractNBTSchemasFromFullWikiNBTPageData(input, options = {}) {
                    input = input.replaceAll(/^\{\{in\|bedrock\}\}/gm, "In [[Bedrock Edition]]").replaceAll(/\{\{in\|bedrock\}\}/g, "in [[Bedrock Edition]]");
                    const containers = input.match(/(?<=(^|\n)<div class="treeview">\s*).+?\n(?=<\/div>($|\n))/gs);
                    if (!containers)
                        return [];
                    const schemas = [];
                    for (const container of containers) {
                        // console.log(1.792, container);
                        if (!/(?<=(^|\n)===? (?<header>[^\n]+?) ===?\s*?\n(?:(?<description>(?:\w|\[)[^\n]*?)\n{1,2})?)(?<schema>\*[^\n]+?(?:\n\*[^\n]+?|\n\w[^\n]+?)+?)(?=\n+?(?:===? [^\n]+? ===?\n)*?===? [^\n]+? ===?\s*?\n(?:\w[^\n]*?\n)?|\s*?$)/.test(container))
                            continue;
                        // console.log(2.792);
                        const schemaSubContainers = container.matchAll(/(?<=(^|\n)===? (?<header>[^\n]+?) ===?\s*?\n(?:(?<description>(?:\w|\[)[^\n]*?)\n{1,2})?)(?<schema>\*[^\n]+?(?:\n\*[^\n]+?|\n\w[^\n]+?)+?)(?=\n+?(?:===? [^\n]+? ===?\n)*?===? [^\n]+? ===?\s*?\n(?:\w[^\n]*?\n)?|\s*?$)/g);
                        for (const schemaSubContainer of schemaSubContainers) {
                            // console.log(3.792, schemaSubContainer);
                            const header = schemaSubContainer.groups.header;
                            const schema = wikiNBTToNBTSchema(schemaSubContainer.groups.schema, "auto", options);
                            let result = { ...schema };
                            if (options.generateIDs ?? true) {
                                result = {
                                    ...{ id: void 0, title: void 0, description: void 0, type: void 0, required: void 0, properties: void 0 }, // Moves these properties to this position in this order.
                                    ...result,
                                    id: (options.refNameResolver ?? defaultRefNameResolver)(header, options.category ?? "others"), // Set the ID here to override any value in the result variable .
                                };
                            }
                            if (schemaSubContainer.groups.description &&
                                (!result.markdownDescription || (options.replaceSchemaRootTagDescriptionsWithDescriptionText ?? true)))
                                result.markdownDescription = wikiToMarkdown(schemaSubContainer.groups.description.replace(/:$/, "."));
                            for (const prop of ["id", "title", "description", "markdownDescription", "type", "required", "properties"]) {
                                if (prop in result && result[prop] === undefined)
                                    delete result[prop];
                            }
                            schemas.push(result);
                        }
                    }
                    return schemas;
                }
                FromMinecraftWikiData.extractNBTSchemasFromFullWikiNBTPageData = extractNBTSchemasFromFullWikiNBTPageData;
            })(FromMinecraftWikiData = Conversion.FromMinecraftWikiData || (Conversion.FromMinecraftWikiData = {}));
        })(Conversion = Utils.Conversion || (Utils.Conversion = {}));
        /**
         * Miscellaneous utilities for working with NBT schemas.
         */
        let Misc;
        (function (Misc) {
            /**
             * Fixes the order of properties in an NBT schema, schema fragment, or sub-schema.
             *
             * This is mainly for consistency when stringifying (ex. using {@link JSON.stringify}).
             *
             * @param schema The NBT schema to fix.
             * @returns The fixed NBT schema.
             */
            function fixNBTSchemaPropertyOrder(schema) {
                let result = {
                    ...{ id: void 0, title: void 0, description: void 0, markdownDescription: void 0, type: void 0, required: void 0, properties: void 0 }, // Moves these properties to this position in this order.
                    ...schema,
                };
                for (const prop of ["id", "title", "description", "markdownDescription", "type", "required", "properties"]) {
                    if (prop in result && !(prop in schema))
                        delete result[prop];
                }
                return result;
            }
            Misc.fixNBTSchemaPropertyOrder = fixNBTSchemaPropertyOrder;
        })(Misc = Utils.Misc || (Utils.Misc = {}));
    })(Utils = NBTSchemas.Utils || (NBTSchemas.Utils = {}));
})(NBTSchemas || (NBTSchemas = {}));
//# sourceMappingURL=nbtSchemas.js.map