import NBT, { type Compound } from "prismarine-nbt";
import type { OmitNeverValueKeys, VerifyConstraint } from "./types.js";
/**
 * The type of an SNBT parse error.
 */
export type SNBTParseErrorType = NonNullable<Extract<SNBTParseErrorCauseStackItem, {
    /**
     * @ignore
     */
    error?: any;
}>["error"]>["type"] | "ExpectedEndOfInput" | "ExpectedCompoundOrList";
/**
 * Maps SNBT parse error types to error codes.
 */
export declare const SNBTParseErrorTypeToCode: {
    /**
     * An error that occurred because a disallowed type was found in a typed array.
     */
    readonly DisallowedTypeInTypedArray: "disallowed-type-in-typed-array";
    /**
     * An error that occurred because an expected compound or list was not found.
     */
    readonly ExpectedCompoundOrList: "expected-compound-or-list";
    /**
     * An error that occurred because an argument to a function was invalid.
     */
    readonly InvalidArgumentToFunction: "invalid-argument-to-function";
    /**
     * An error that occurred because an SNBT key was invalid.
     */
    readonly InvalidSNBTKey: "invalid-snbt-key";
    /**
     * An error that occurred because an SNBT string was invalid.
     */
    readonly InvalidSNBTString: "invalid-snbt-string";
    /**
     * An error that occurred because a UUID was invalid.
     */
    readonly InvalidUUID: "invalid-uuid";
    /**
     * An error that occurred because an unsupported function was called.
     */
    readonly UnsupportedFunction: "unsupported-function";
    /**
     * An error that occurred because an unsupported SNBT primitive was found.
     */
    readonly UnsupportedSNBTPrimitive: "unsupported-snbt-primitive";
    /**
     * An error that occurred because a list contained multiple types.
     */
    readonly MixedListTypesNotAllowed: "mixed-list-types-not-allowed";
    /**
     * An error that occurred because an unsupported type was found in a typed array.
     */
    readonly UnsupportedTypeInTypedArray: "unsupported-type-in-typed-array";
    /**
     * An error that occurred because the end of the input was expected.
     */
    readonly ExpectedEndOfInput: "expected-end-of-input";
};
/**
 * The namespace of SNBT parse errors.
 */
export declare const SNBTParseErrorDisplayNamespace = "mcbe-leveldb";
/**
 * A stack item in an SNBT parse error.
 */
export type SNBTParseErrorCauseStackItem = {
    /**
     * The position of the error in the input.
     */
    positionInInput: number;
    /**
     * The input.
     */
    input: any;
    /**
     * The function associated with this stack item.
     */
    function: "parseSNBTPrimitive";
    /**
     * The error associated with this stack item.
     */
    error?: {
        /**
         * The type of this error.
         */
        type: "InvalidArgumentToFunction";
        /**
         * The name of the function.
         */
        functionName: "bool" | "uuid";
        /**
         * The argument that caused this error.
         */
        argument: string;
    } | {
        /**
         * The type of this error.
         */
        type: "UnsupportedFunction";
        /**
         * The name of the unsupported function.
         */
        functionName: string;
    } | {
        /**
         * The type of this error.
         */
        type: "UnsupportedSNBTPrimitive";
        /**
         * The raw SNBT primitive value that caused this error.
         */
        raw: any;
    } | {
        /**
         * The type of this error.
         */
        type: "InvalidSNBTString";
        /**
         * The raw SNBT string value that caused this error.
         */
        raw: any;
    };
} | {
    /**
     * The position of the error in the input.
     */
    positionInInput: number;
    /**
     * The input.
     */
    input: string;
    /**
     * The function associated with this stack item.
     */
    function: "uuidToIntArray";
    /**
     * The error associated with this stack item.
     */
    error: {
        /**
         * The type of this error.
         */
        type: "InvalidUUID";
        /**
         * The invalid UUID that caused this error.
         */
        uuid: string;
    };
} | {
    /**
     * The position of the error in the input item.
     */
    positionInInputItem: number;
    /**
     * The input items (the items in the typed array).
     */
    inputItems: string[];
    /**
     * The input item associated with this stack item.
     */
    inputItem: string;
    /**
     * The index of the input item associated with this stack item.
     */
    inputItemIndex: number;
    /**
     * The type of the typed array associated with this stack item.
     */
    arrayType: `${TypedArrayLetterTypes.B | TypedArrayLetterTypes.S | TypedArrayLetterTypes.I | TypedArrayLetterTypes.L}`;
    /**
     * The function associated with this stack item.
     */
    function: "parseTypedArray";
    /**
     * The error associated with this stack item.
     */
    error?: {
        /**
         * The type of this error.
         */
        type: "DisallowedTypeInTypedArray";
        /**
         * The type of the item that caused this error.
         */
        itemType: `${TypedArrayLetterTypes.B | TypedArrayLetterTypes.S | TypedArrayLetterTypes.I | TypedArrayLetterTypes.L}`;
        /**
         * The allowed types.
         */
        allowedTypes: `${TypedArrayLetterTypes.B | TypedArrayLetterTypes.S | TypedArrayLetterTypes.I | TypedArrayLetterTypes.L}`[];
    } | {
        /**
         * The type of this error.
         */
        type: "UnsupportedTypeInTypedArray";
        /**
         * Should only be undefined if the item is unable to be parsed.
         */
        itemType?: `${NBT.TagType}` | undefined;
    };
} | {
    /**
     * The position of the error in the input item.
     */
    positionInInputItem: number;
    /**
     * The input items (the items in the list).
     */
    inputItems: string[];
    /**
     * The input item associated with this stack item.
     */
    inputItem: string;
    /**
     * The index of the input item associated with this stack item.
     */
    inputItemIndex: number;
    /**
     * The function associated with this stack item.
     */
    function: "parseList";
    /**
     * The error associated with this stack item.
     */
    error?: {
        /**
         * The type of this error.
         */
        type: "MixedListTypesNotAllowed";
        /**
         * The type of the item that caused this error.
         */
        itemType: `${NBT.TagType}`;
        /**
         * The detected type of the item that caused this error.
         */
        item: NBT.Tags[NBT.TagType];
        /**
         * The detected type of the list.
         */
        detectedArrayType: `${NBT.TagType}`;
    };
} | {
    /**
     * The position of the error in the input.
     */
    positionInInput: number;
    /**
     * The input.
     */
    input: string;
    /**
     * The property key associated with this stack item.
     */
    key?: string;
    /**
     * The function associated with this stack item.
     */
    function: "extractSNBT" | "parseSNBTCompoundString";
    /**
     * The error associated with this stack item.
     */
    error?: {
        /**
         * The type of this error.
         */
        type: "InvalidSNBTKey";
        /**
         * The raw SNBT key value that caused this error.
         */
        raw: any;
    };
};
/**
 * The cause of an SNBT parse error.
 */
export interface SNBTParseErrorCause {
    /**
     * The position of the error in the input.
     */
    position: number;
    /**
     * The stack trace of the error.
     */
    stack: [initialError: SNBTParseErrorCauseStackItem, ...outerStack: SNBTParseErrorCauseStackItem[]];
}
/**
 * Represents an error that occurred while parsing SNBT.
 *
 * @template T Whether the error's full stack has been resolved.
 */
export interface SNBTParseError<T extends boolean = boolean> extends Error {
    /**
     * The cause of the error.
     */
    cause: SNBTParseErrorCause;
    /**
     * Whether the error's full stack has been resolved.
     */
    isResolved: T;
    /**
     * The original input that caused the error.
     */
    originalInput: T extends true ? string : null;
    /**
     * Gets the position of the error in the input.
     *
     * @returns The position of the error in the input.
     */
    getErrorPosition(): T extends true ? [line: number, column: number] : null;
    /**
     * Gets the end position of the error in the input.
     *
     * @returns The end position of the error in the input.
     */
    getErrorEndPosition(): T extends true ? [line: number, column: number] : null;
    /**
     * Gets the position of the error in the input with an offset.
     *
     * @param offset The offset to add to the error position.
     * @returns The position of the error in the input.
     */
    getErrorPositionWithOffset(offset: number): T extends true ? [line: number, column: number] : null;
    /**
     * Gets the position of the error in the input for a stack item.
     *
     * @param stackItem The stack item to get the error position for.
     * @returns The position of the error in the input.
     */
    getErrorPositionForStackItem(stackItem: SNBTParseErrorCauseStackItem): [line: number, column: number];
}
/**
 * The options for an SNBT parse error.
 */
export interface SNBTParseErrorOptions extends ErrorOptions {
    /**
     * The cause of the error.
     */
    cause: SNBTParseErrorCause;
    /**
     * Whether the error's full stack has been resolved.
     *
     * Only set this to true if this was from a function that was not called by another SNBT parser function, if the SNBT parser has more to the stack, this should be false.
     *
     * @default false
     */
    resolved?: boolean | undefined;
    /**
     * Only set this if {@link resolved} is also true, this is the original input of the SNBT parser function.
     */
    originalInput?: string | undefined;
}
/**
 * The constructor for an SNBT parse error.
 */
export interface SNBTParseErrorConstructor extends Omit<ErrorConstructor, "prototype"> {
    /**
     * Creates a new SNBTParseError.
     *
     * @param message The message of the error.
     * @param options The options for the error.
     * @returns A new SNBTParseError.
     */
    new (message: string, options: SNBTParseErrorOptions): SNBTParseError;
    /**
     * Creates a new SNBTParseError.
     *
     * @param message The message of the error.
     * @param options The options for the error.
     * @returns A new SNBTParseError.
     */
    (message: string, options: SNBTParseErrorOptions): SNBTParseError;
    /**
     * The prototype of an SNBTParseError.
     */
    prototype: SNBTParseError;
}
/**
 * An SNBT parse error.
 */
export declare var SNBTParseError: SNBTParseErrorConstructor;
/**
 * The letter types of typed arrays.
 *
 * @internal
 */
declare enum TypedArrayLetterTypes {
    /**
     * A byte array.
     */
    B = "byte",
    /**
     * A short array.
     */
    S = "short",
    /**
     * An integer array.
     */
    I = "int",
    /**
     * A long array.
     */
    L = "long"
}
/**
 * Options for parsing SNBT.
 */
export interface ParseSNBTBaseOptions {
    /**
     * Whether to allow lists of mixed types.
     *
     * @default true
     */
    mixedListsAllowed?: boolean | undefined;
    /**
     * Whether to convert lists of mixed types to compound lists.
     *
     * @default true
     */
    convertMixedListsToCompoundLists?: boolean | undefined;
    /**
     * Whether the function is being called from within an inner stack of a parent SNBT parser function.
     *
     * This is internal only and should not be specified by users.
     *
     * @internal
     * @ignore
     *
     * @default false
     */
    isInnerStack?: boolean | undefined;
    /**
     * Whether to keep parsing the SNBT string even if there are errors.
     *
     * It will cause the function to return an object containing the errors, as well as the parts of the value that were able to be extracted.
     *
     * @default false
     */
    keepGoingAfterError?: boolean | undefined;
    /**
     * Whether to stop parsing the SNBT string at a negative depth.
     *
     * @default true
     */
    stopAtNegativeDepth?: boolean | undefined;
}
/**
 * The result of the {@link parseSNBTCompoundString} function when {@link ParseSNBTBaseOptions.keepGoingAfterError} is `true`.
 */
export type ParseSNBTCompoundStringResultWithErrors = {
    /**
     * The parsed SNBT compound.
     */
    value: Compound;
    /**
     * The errors that occurred while parsing the SNBT compound.
     */
    errors: SNBTParseError[];
};
/**
 * Parse an SNBT compound string into Prismarine-NBT JSON.
 *
 * @param input The SNBT compound string to parse.
 * @param options Options for parsing the SNBT compound string.
 * @returns The parsed SNBT compound.
 */
export declare function parseSNBTCompoundString(input: string, options: ParseSNBTBaseOptions & {
    keepGoingAfterError: true;
}): ParseSNBTCompoundStringResultWithErrors;
export declare function parseSNBTCompoundString(input: string, options?: ParseSNBTBaseOptions & {
    keepGoingAfterError?: false | undefined;
}): Compound;
export declare function parseSNBTCompoundString(input: string, options?: ParseSNBTBaseOptions): Compound | ParseSNBTCompoundStringResultWithErrors;
/**
 * The result of the {@link extractSNBT} function when {@link ParseSNBTBaseOptions.keepGoingAfterError} is `false` or not provided.
 */
export interface ExtractSNBTResult {
    /**
     * The parsed value.
     */
    value: Compound | NBT.List<NBT.TagType>;
    /**
     * The start position of the parsed value in the input string.
     */
    startPos: number;
    /**
     * The end position of the parsed value in the input string.
     */
    endPos: number;
    /**
     * The remaining text after the parsed value.
     */
    remaining: string;
}
/**
 * The result of the {@link extractSNBT} function when {@link ParseSNBTBaseOptions.keepGoingAfterError} is `true`.
 */
export interface ExtractSNBTResultWithErrors extends ExtractSNBTResult {
    /**
     * The errors that occurred while parsing the input string.
     */
    errors: SNBTParseError[];
}
/**
 * Parses an SNBT string into Prismarine-NBT JSON.
 *
 * @param input The SNBT string to parse.
 * @param options The options to use when parsing the SNBT string.
 * @returns An object containing the parsed value, start position, end position, remaining text, and errors.
 */
export declare function extractSNBT(input: string, options: ParseSNBTBaseOptions & {
    keepGoingAfterError: true;
}): ExtractSNBTResultWithErrors;
export declare function extractSNBT(input: string, options?: ParseSNBTBaseOptions & {
    keepGoingAfterError?: false | undefined;
}): ExtractSNBTResult;
export declare function extractSNBT(input: string, options?: ParseSNBTBaseOptions): ExtractSNBTResult | ExtractSNBTResultWithErrors;
/**
 * Converts SNBT-like JSON into Prismarine-NBT JSON.
 *
 * @param snbt The SNBT-like JSON to convert.
 * @returns The Prismarine-NBT JSON.
 */
export declare function snbtToPrismarine(snbt: any): Compound;
/**
 * The tag types of SNBT-like JSON.
 */
export declare enum SNBTLikeJSONTagType {
    /**
     * A byte.
     */
    Byte = "byte",
    /**
     * A short.
     */
    Short = "short",
    /**
     * An integer.
     */
    Int = "int",
    /**
     * A long.
     */
    Long = "long",
    /**
     * A float.
     */
    Float = "float",
    /**
     * A double.
     */
    Double = "double",
    /**
     * A string.
     */
    String = "string",
    /**
     * A list.
     */
    List = "list",
    /**
     * A compound.
     */
    Compound = "compound",
    /**
     * An array of bytes.
     */
    ByteArray = "byteArray",
    /**
     * An array of shorts.
     */
    ShortArray = "shortArray",
    /**
     * An array of integers.
     */
    IntArray = "intArray",
    /**
     * An array of longs.
     */
    LongArray = "longArray"
}
/**
 * The types of tag types of SNBT-like JSON.
 */
export type SNBTLikeJSONTags = {
    /**
     * A byte.
     */
    [SNBTLikeJSONTagType.Byte]: `${bigint}${"b" | "B"}`;
    /**
     * A short.
     */
    [SNBTLikeJSONTagType.Short]: `${bigint}${"s" | "S"}`;
    /**
     * An integer.
     */
    [SNBTLikeJSONTagType.Int]: `${bigint}${"" | "i" | "I"}`;
    /**
     * A long.
     */
    [SNBTLikeJSONTagType.Long]: `${bigint}${"l" | "L"}`;
    /**
     * A float.
     */
    [SNBTLikeJSONTagType.Float]: `${number}${"f" | "F"}`;
    /**
     * A double.
     */
    [SNBTLikeJSONTagType.Double]: `${number}${"d" | "D"}`;
    /**
     * A string.
     */
    [SNBTLikeJSONTagType.String]: `"${string}"` | `'${string}'` | `${string}`;
    /**
     * A list.
     */
    [SNBTLikeJSONTagType.List]: SNBTLikeJSONList<SNBTLikeJSONTagType>;
    /**
     * A compound.
     */
    [SNBTLikeJSONTagType.Compound]: SNBTLikeJSONCompound;
    /**
     * An array of bytes.
     */
    [SNBTLikeJSONTagType.ByteArray]: SNBTLikeJSONTypedArray<TypedArrayLetterTypes.B>;
    /**
     * An array of shorts.
     */
    [SNBTLikeJSONTagType.ShortArray]: SNBTLikeJSONTypedArray<TypedArrayLetterTypes.S>;
    /**
     * An array of integers.
     */
    [SNBTLikeJSONTagType.IntArray]: SNBTLikeJSONTypedArray<TypedArrayLetterTypes.I>;
    /**
     * An array of longs.
     */
    [SNBTLikeJSONTagType.LongArray]: SNBTLikeJSONTypedArray<TypedArrayLetterTypes.L>;
};
/**
 * A list tag of SNBT-like JSON.
 */
export type SNBTLikeJSONList<T extends SNBTLikeJSONTagType> = SNBTLikeJSONTags[T][];
/**
 * A typed array tag of SNBT-like JSON.
 */
export type SNBTLikeJSONTypedArray<T extends TypedArrayLetterTypes> = {
    /**
     * The type of the typed array.
     */
    __typed: keyof OmitNeverValueKeys<{
        [key in keyof typeof TypedArrayLetterTypes]: (typeof TypedArrayLetterTypes)[key] extends T ? key : never;
    }>;
    /**
     * The values of the typed array.
     */
    value: SNBTLikeJSONTags[VerifyConstraint<T, `${SNBTLikeJSONTagType}`>][];
};
/**
 * A compound tag of SNBT-like JSON.
 */
export type SNBTLikeJSONCompound = {
    [key: string]: SNBTLikeJSONTag<SNBTLikeJSONTagType>;
};
/**
 * An SNBT-like JSON tag.
 */
export type SNBTLikeJSONTag<T extends `${SNBTLikeJSONTagType}` | SNBTLikeJSONTagType> = {
    [key in SNBTLikeJSONTagType as `${key}`]: SNBTLikeJSONTags[key];
}[T];
/**
 * Converts Prismarine-NBT JSON to SNBT-like JSON.
 *
 * @param nbt The Prismarine-NBT JSON to convert.
 * @returns The resulting SNBT-like JSON.
 */
export declare function prismarineToSNBT<T extends NBT.Tags[NBT.TagType]>(nbt: T): SNBTLikeJSONTag<T["type"]>;
/**
 * Converts a long in bigint format to tuple form of two signed 32-bit integers.
 *
 * @param longVal The long as a bigint.
 * @returns The long as a tuple.
 */
export declare function toLongParts(longVal: bigint): [high: number, low: number];
/**
 * Converts a long as a string to a tuple of two signed 32-bit integers.
 *
 * The string would be formatted like `"0n"`.
 *
 * @param literal A long as a string.
 * @returns The long as a tuple.
 */
export declare function parseLong(literal: string): [high: number, low: number];
/**
 * Converts a long in tuple form (two signed 32-bit integers) to bigint form.
 *
 * @param param0 The long as a tuple.
 * @returns The long as a bigint.
 */
export declare function toLong([high, low]: [high: number, low: number]): bigint;
/**
 * Options for {@link prettyPrintSNBT}.
 */
export interface PrettyPrintOptions {
    /**
     * Number of spaces to indent.
     *
     * @default 2
     */
    indent?: number | undefined;
    /**
     * Whether to inline arrays if possible.
     *
     * @default true
     */
    inlineArrays?: boolean | undefined;
    /**
     * Maximum length of an inline array.
     *
     * @default 40
     */
    maxInlineLength?: number | undefined;
}
/**
 * Pretty-prints SNBT.
 *
 * @param obj The SNBT-like JSON to pretty-print.
 * @param options The options to use.
 * @returns The pretty-printed SNBT.
 *
 * @example
 * ```typescript
 * prettyPrintSNBT(prismarineToSNBT({
 *     type: "compound",
 *     value: {
 *         enabled: {
 *             type: "byte",
 *             value: 1
 *         }
 *     }
 * }))
 * ```
 */
export declare function prettyPrintSNBT(obj: any, options?: PrettyPrintOptions): string;
export {};
