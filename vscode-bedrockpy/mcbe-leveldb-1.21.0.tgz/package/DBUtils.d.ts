import type { LevelDB } from "@8crafter/leveldb-zlib";
import { type DBEntryContentType } from "./LevelUtils.ts";
import NBT from "prismarine-nbt";
/**
 * Gets the keys from the LevelDB with a specific content type.
 *
 * @template T The content type to look for.
 * @param db The LevelDB. Should match the type of the {@link LevelDB} class from the {@link https://www.npmjs.com/package/@8crafter/leveldb-zlib | @8crafter/leveldb-zlib} package. It does not have to be the one from that package, as long as the types match.
 * @param type The {@link DBEntryContentType | content type} to look for.
 * @returns The keys from the LevelDB with the specified content type, the keys are in Buffer format, this is because some keys contain binary data like chunk indices.
 */
export declare function getKeysOfType<T extends DBEntryContentType>(db: LevelDB, type: T): Promise<Buffer<ArrayBuffer>[]>;
/**
 * Gets the keys from the list of LevelDB keys with a specific content type.
 *
 * @template T The content type to look for.
 * @template TArrayBuffer The type of the buffers.
 * @param dbKeys The LevelDB keys. Should be an array of Buffers.
 * @param type The {@link DBEntryContentType | content type} to look for.
 * @returns The keys from the provided LevelDB keys array with the specified content type, the keys are in Buffer format, this is because some keys contain binary data like chunk indices.
 */
export declare function getKeysOfType<T extends DBEntryContentType, TArrayBuffer extends ArrayBufferLike = ArrayBufferLike>(dbKeys: Buffer<TArrayBuffer>[], type: T): Buffer<TArrayBuffer>[];
/**
 * Gets the keys from the LevelDB with one of the specified content types.
 *
 * @template T The content types to look for.
 * @param db The LevelDB. Should match the type of the {@link LevelDB} class from the {@link https://www.npmjs.com/package/@8crafter/leveldb-zlib | @8crafter/leveldb-zlib} package. It does not have to be the one from that package, as long as the types match.
 * @param types The {@link DBEntryContentType | content types} to look for.
 * @returns An object mapping each of the specified content types to the keys from the LevelDB with that content type, the keys are in Buffer format, this is because some keys contain binary data like chunk indices.
 */
export declare function getKeysOfTypes<T extends DBEntryContentType[] | readonly DBEntryContentType[]>(db: LevelDB, types: T): Promise<{
    [key in T[number]]: Buffer<ArrayBuffer>[];
}>;
/**
 * Gets the keys from the list of LevelDB keys with one of the specified content types.
 *
 * @template T The content types to look for.
 * @template TArrayBuffer The type of the buffers.
 * @param dbKeys The LevelDB keys. Should be an array of Buffers.
 * @param types The {@link DBEntryContentType | content types} to look for.
 * @returns An object mapping each of the specified content types to the keys from the provided LevelDB keys array with that content type, the keys are in Buffer format, this is because some keys contain binary data like chunk indices.
 */
export declare function getKeysOfTypes<T extends DBEntryContentType[] | readonly DBEntryContentType[], TArrayBuffer extends ArrayBufferLike>(dbKeys: Buffer<TArrayBuffer>[], types: T): {
    [key in T[number]]: Buffer<TArrayBuffer>[];
};
/**
 * Gets the keys from the LevelDB with one of the specified content types.
 *
 * @template T The content types to look for.
 * @param db The LevelDB. Should match the type of the {@link LevelDB} class from the {@link https://www.npmjs.com/package/@8crafter/leveldb-zlib | @8crafter/leveldb-zlib} package. It does not have to be the one from that package, as long as the types match.
 * @param types The {@link DBEntryContentType | content types} to look for.
 * @returns An object mapping each of the specified content types to the keys from the LevelDB with that content type, the keys are in Buffer format, this is because some keys contain binary data like chunk indices.
 */
export declare function getKeysOfTypesG<T extends DBEntryContentType[] | readonly DBEntryContentType[]>(db: LevelDB, types: T): AsyncGenerator<{
    count: number;
    results: {
        [key in T[number]]: Buffer<ArrayBuffer>[];
    };
}, {
    [key in T[number]]: Buffer<ArrayBuffer>[];
}>;
/**
 * Gets the keys from the list of LevelDB keys with one of the specified content types.
 *
 * @template T The content types to look for.
 * @template TArrayBuffer The type of the buffers.
 * @param dbKeys The LevelDB keys. Should be an array of Buffers.
 * @param types The {@link DBEntryContentType | content types} to look for.
 * @returns An object mapping each of the specified content types to the keys from the provided LevelDB keys array with that content type, the keys are in Buffer format, this is because some keys contain binary data like chunk indices.
 */
export declare function getKeysOfTypesG<T extends DBEntryContentType[] | readonly DBEntryContentType[], TArrayBuffer extends ArrayBufferLike>(dbKeys: Buffer<TArrayBuffer>[], types: T): Generator<{
    count: number;
    results: {
        [key in T[number]]: Buffer<TArrayBuffer>[];
    };
}, {
    [key in T[number]]: Buffer<TArrayBuffer>[];
}>;
/**
 * Gets a player's name from their UUID.
 *
 * Only works if the player's name was stored in an add-on's dynamic properties with their ID linked to it, and it only works for a hardcoded list of add-ons,
 * if you have your own add-on that you would like this to be able to read the player's names from, {@link https://www.8crafter.com/main/contact | contact 8Crafter},
 * or make a pull request.
 *
 * @param db The LevelDB. Should match the type of the {@link LevelDB} class from the {@link https://www.npmjs.com/package/@8crafter/leveldb-zlib | @8crafter/leveldb-zlib} package. It does not have to be the one from that package, as long as the types match.
 * @param uuid The UUID of the play to get the name of.
 * @returns The name of the player, or `null` if the player's name cannot be found or the world has no dynamic properties.
 *
 * @throws {any} If there was an error reading the DynamicProperties from the DB.
 */
export declare function getPlayerNameFromUUID(db: LevelDB, uuid: string | bigint): Promise<string | null>;
/**
 * Gets a player's name from their UUID using the provided dynamic properties data.
 *
 * Only works if the player's name was stored in an add-on's dynamic properties with their ID linked to it, and it only works for a hardcoded list of add-ons,
 * if you have your own add-on that you would like this to be able to read the player's names from, {@link https://www.8crafter.com/main/contact | contact 8Crafter},
 * or make a pull request.
 *
 * @param dynamicProperties The dynamic properties data, should be the data from the `DynamicProperties` LevelDB key.
 * @param uuid The UUID of the play to get the name of.
 * @returns The name of the player, or `null` if the player's name cannot be found .
 */
export declare function getPlayerNameFromUUIDSync(dynamicProperties: NBT.NBT, uuid: string | bigint): string | null;
/**
 * A function that can be used to get a player's name from their UUID from the dynamic properties.
 */
interface PlayerUUIDToNameDynamicPropertyParser {
    /**
     * A function that can be used to get a player's name from their UUID from the dynamic properties.
     *
     * @param dynamicProperties The dynamic properties data, should be the data from the `DynamicProperties` LevelDB key.
     * @param uuid The UUID of the player to get the name of.
     * @returns The name of the player, or `null` if the player's name cannot be found.
     */
    (dynamicProperties: NBT.NBT, uuid: string): string | null;
}
/**
 * The list of functions that can be used to get a player's name from their UUID from the dynamic properties.
 *
 * These will be called in order until one of them returns a non-null value.
 */
export declare const playerUUIDToNameDynamicPropertyParsers: PlayerUUIDToNameDynamicPropertyParser[];
export {};
